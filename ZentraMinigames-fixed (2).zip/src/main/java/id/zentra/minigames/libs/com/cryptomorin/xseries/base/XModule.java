/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Experimental
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.base;

import id.zentra.minigames.libs.com.cryptomorin.xseries.base.XBase;
import id.zentra.minigames.libs.com.cryptomorin.xseries.base.XRegistry;
import java.util.Arrays;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class XModule<XForm extends XModule<XForm, BukkitForm>, BukkitForm>
implements XBase<XForm, BukkitForm> {
    private final BukkitForm bukkitForm;
    private final String[] names;

    @ApiStatus.Internal
    protected XModule(BukkitForm bukkitForm, String[] names) {
        this.bukkitForm = bukkitForm;
        this.names = names;
    }

    @Override
    @NotNull
    public final String name() {
        return this.names[0];
    }

    @ApiStatus.Experimental
    protected void setEnumName(XRegistry<XForm, BukkitForm> registry, String enumName) {
        if (this.names[0] != null) {
            throw new IllegalStateException("Enum name already set " + enumName + " -> " + Arrays.toString(this.names));
        }
        this.names[0] = enumName;
        BukkitForm newForm = registry.getBukkit(this.names);
        if (this.bukkitForm != newForm) {
            registry.std((XForm)this);
        }
    }

    @Override
    @ApiStatus.Internal
    public String[] getNames() {
        return this.names;
    }

    @Override
    @Nullable
    public final BukkitForm get() {
        return this.bukkitForm;
    }

    public final String toString() {
        return (this.isSupported() ? "" : "!") + this.getClass().getSimpleName() + '(' + this.name() + ')';
    }

    public final int hashCode() {
        return super.hashCode();
    }

    @Deprecated
    public final boolean equals(Object obj) {
        return super.equals(obj);
    }
}

