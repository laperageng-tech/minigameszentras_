/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Mob
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.TNTPrimed
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockExplodeEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDeathEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.EntityTargetLivingEntityEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.player.PlayerBucketEmptyEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.projectiles.ProjectileSource
 */
package id.zentra.minigames;

import id.zentra.minigames.DuelGame;
import id.zentra.minigames.Game;
import id.zentra.minigames.GameManager;
import id.zentra.minigames.Kit;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ParkourRaceGame;
import id.zentra.minigames.PracticeGame;
import id.zentra.minigames.ZentraMinigames;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;

public final class GameListener
implements Listener {
    private final ZentraMinigames plugin;
    private final GameManager mgr;

    public GameListener(ZentraMinigames zentraMinigames, GameManager gameManager) {
        this.plugin = zentraMinigames;
        this.mgr = gameManager;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        Game game = this.mgr.of(victim);
        if (game == null) {
            return;
        }
        Player attacker = null;
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            Entity damager = byEntity.getDamager();
            if (damager instanceof TNTPrimed && this.mgr.gameAt(damager.getLocation()) != null) {
                event.setCancelled(true);
                return;
            }
            if (damager instanceof Player direct) {
                attacker = direct;
            } else if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
                attacker = shooter;
            }
        }
        // Pemukul dari luar game ini tidak boleh melukai pemain di dalam game.
        if (attacker != null && this.mgr.of(attacker) != game) {
            event.setCancelled(true);
            return;
        }
        if (event.isCancelled()) {
            // Multiverse (PvP world = false) / WorldGuard / skript lain membatalkan damage.
            // Selama game berjalan dan pemain masih hidup, aturan GAME yang menentukan, bukan plugin lain.
            if (game.state != Game.State.RUNNING || !game.alive.contains(victim.getUniqueId())) {
                return;
            }
            event.setCancelled(false);
        }
        if (attacker != null && attacker.equals(victim)) {
            attacker = null;
        }
        game.onDamage(event, victim, attacker);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent playerDeathEvent) {
        Player player = playerDeathEvent.getEntity();
        if (this.mgr.of(player) == null) {
            return;
        }
        playerDeathEvent.setKeepInventory(true);
        playerDeathEvent.setKeepLevel(true);
        playerDeathEvent.getDrops().clear();
        playerDeathEvent.setDroppedExp(0);
        playerDeathEvent.deathMessage(null);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> player.spigot().respawn());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent playerRespawnEvent) {
        Player player = playerRespawnEvent.getPlayer();
        Game game = this.mgr.of(player);
        if (game == null) {
            return;
        }
        playerRespawnEvent.setRespawnLocation(game.specSpawn());
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> game.playerDied(player), 2L);
    }

    @EventHandler
    public void onTarget(EntityTargetLivingEntityEvent entityTargetLivingEntityEvent) {
        PracticeGame practiceGame;
        if (!(entityTargetLivingEntityEvent.getEntity() instanceof Mob)) {
            return;
        }
        Game game = this.mgr.gameAt(entityTargetLivingEntityEvent.getEntity().getLocation());
        if (game instanceof PracticeGame && !(practiceGame = (PracticeGame)game).allowTarget(entityTargetLivingEntityEvent.getEntity(), entityTargetLivingEntityEvent.getTarget())) {
            entityTargetLivingEntityEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent entityDeathEvent) {
        if (entityDeathEvent.getEntity() instanceof Player) {
            return;
        }
        Game game = this.mgr.gameAt(entityDeathEvent.getEntity().getLocation());
        if (game instanceof PracticeGame) {
            PracticeGame practiceGame = (PracticeGame)game;
            practiceGame.onBotDeath(entityDeathEvent);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent playerQuitEvent) {
        this.mgr.leave(playerQuitEvent.getPlayer());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent blockBreakEvent) {
        Game game = this.mgr.of(blockBreakEvent.getPlayer());
        if (game == null) {
            return;
        }
        // Aturan game yang menentukan (plugin proteksi lain tidak boleh menghalangi block buatan pemain).
        blockBreakEvent.setCancelled(!game.allowBreak(blockBreakEvent.getBlock(), blockBreakEvent.getPlayer()));
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent blockPlaceEvent) {
        Game game = this.mgr.of(blockPlaceEvent.getPlayer());
        if (game == null) {
            return;
        }
        // Aturan game yang menentukan: kalau game mengizinkan, batalkan pembatalan dari plugin/skript lain.
        boolean allowed = game.allowPlace(blockPlaceEvent.getBlock(), blockPlaceEvent.getPlayer());
        blockPlaceEvent.setCancelled(!allowed);
        if (allowed) {
            // canBuild=false (diset plugin proteksi) juga membatalkan pemasangan block, jadi paksa true.
            blockPlaceEvent.setBuild(true);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onBucket(PlayerBucketEmptyEvent playerBucketEmptyEvent) {
        Game game = this.mgr.of(playerBucketEmptyEvent.getPlayer());
        if (game != null && !game.canBuild()) {
            playerBucketEmptyEvent.setCancelled(true);
        }
        if (game != null && game.allowBuildBlocks && game.state == Game.State.RUNNING) {
            // buckets allowed for building games
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        Player player = playerInteractEvent.getPlayer();
        Game game = this.mgr.of(player);
        if (game == null || playerInteractEvent.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = playerInteractEvent.getAction();
        if (action == Action.PHYSICAL) {
            return;
        }
        ItemStack itemStack = playerInteractEvent.getItem();
        String string = this.plugin.itemId(itemStack);
        if (string != null) {
            playerInteractEvent.setCancelled(true);
            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                game.lobbyAction(player, string);
            }
            return;
        }
        if (game.canBuild() && game.state == Game.State.RUNNING && itemStack != null
                && (playerInteractEvent.useItemInHand() == Event.Result.DENY || playerInteractEvent.useInteractedBlock() == Event.Result.DENY)) {
            // Plugin lain membatalkan klik kanan: tanpa ini block tidak bisa dipasang / ender pearl tidak bisa dilempar.
            playerInteractEvent.setCancelled(false);
        }
        game.onInteract(playerInteractEvent);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent foodLevelChangeEvent) {
        Player player;
        HumanEntity humanEntity = foodLevelChangeEvent.getEntity();
        if (humanEntity instanceof Player && this.mgr.of(player = (Player)humanEntity) != null) {
            foodLevelChangeEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent playerDropItemEvent) {
        Game game = this.mgr.of(playerDropItemEvent.getPlayer());
        if (game != null && !game.canBuild()) {
            playerDropItemEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent entityPickupItemEvent) {
        Player player;
        Object object = entityPickupItemEvent.getEntity();
        if (object instanceof Player && (object = this.mgr.of(player = (Player)object)) != null && !((Game)object).canBuild()) {
            entityPickupItemEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent playerSwapHandItemsEvent) {
        Game game = this.mgr.of(playerSwapHandItemsEvent.getPlayer());
        if (game != null && game.lockInv()) {
            playerSwapHandItemsEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent inventoryClickEvent) {
        Player player;
        Object object = inventoryClickEvent.getInventory().getHolder();
        if (object instanceof GameManager.MenuHolder) {
            Object object2;
            GameManager.MenuHolder menuHolder = (GameManager.MenuHolder)object;
            inventoryClickEvent.setCancelled(true);
            if (inventoryClickEvent.getClickedInventory() != inventoryClickEvent.getInventory()) {
                return;
            }
            object = menuHolder.keys.get(inventoryClickEvent.getSlot());
            if (object == null || ((String)object).equals("_info") || !((object2 = inventoryClickEvent.getWhoClicked()) instanceof Player)) {
                return;
            }
            Player player2 = (Player)object2;
            if (inventoryClickEvent.isRightClick() && this.mgr.list((String)object) != null) {
                player2.closeInventory();
                this.mgr.showRules(player2, (String)object);
                return;
            }
            player2.closeInventory();
            if (((String)object).equals("_leave")) {
                if (this.mgr.leave(player2)) {
                    Msg.send(player2, "&7Kamu keluar dari game.");
                }
            } else if (((String)object).equals("_back")) {
                this.mgr.openMenu(player2);
            } else if (((String)object).equals("parkour:select")) {
                this.mgr.openParkourSelect(player2);
            } else if (((String)object).equals("parkour:race")) {
                this.mgr.join(player2, "parkourrace");
            } else if (((String)object).startsWith("race:map:") || ((String)object).startsWith("race:mode:")) {
                Game game = this.mgr.of(player2);
                if (game instanceof ParkourRaceGame) {
                    object2 = (ParkourRaceGame)game;
                    ((ParkourRaceGame)object2).vote(player2, ((String)object).startsWith("race:map:"), ((String)object).substring(((String)object).lastIndexOf(58) + 1));
                    if (((ParkourRaceGame)object2).canVote(player2)) {
                        this.mgr.openRaceVote(player2, (ParkourRaceGame)object2);
                    }
                }
            } else if (((String)object).equals("parkour:maps")) {
                this.mgr.openParkourMaps(player2);
            } else if (((String)object).startsWith("parkour:map:")) {
                this.mgr.openParkourModes(player2, ((String)object).substring(12));
            } else if (((String)object).startsWith("parkour:play:")) {
                String[] parts = ((String)object).split(":");
                if (parts.length == 4) {
                    this.mgr.joinParkour(player2, parts[2], parts[3]);
                }
            } else if (((String)object).equals("_bot")) {
                this.mgr.cycleBot(player2);
                this.mgr.openKitMenu(player2);
            } else if (((String)object).startsWith("invitepage:")) {
                this.mgr.openInvites(player2, Integer.parseInt(((String)object).substring(11)));
            } else if (((String)object).startsWith("invite:")) {
                this.mgr.invite(player2, UUID.fromString(((String)object).substring(7)));
            } else if (((String)object).startsWith("vote:")) {
                Game game = this.mgr.of(player2);
                if (game instanceof DuelGame) {
                    object2 = (DuelGame)game;
                    ((DuelGame)object2).voteKit(player2, ((String)object).substring(5));
                    this.mgr.openDuelVote(player2, (DuelGame)object2);
                }
            } else if (((String)object).startsWith("kit:")) {
                try {
                    this.mgr.pickKit(player2, Kit.valueOf(((String)object).substring(4)));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    Msg.send(player2, "&cKit tidak dikenal.");
                }
            } else {
                this.mgr.join(player2, (String)object);
            }
            return;
        }
        object = inventoryClickEvent.getWhoClicked();
        if (object instanceof Player && (object = this.mgr.of(player = (Player)object)) != null && ((Game)object).lockInv()) {
            inventoryClickEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent inventoryDragEvent) {
        Player player;
        if (inventoryDragEvent.getInventory().getHolder() instanceof GameManager.MenuHolder) {
            inventoryDragEvent.setCancelled(true);
            return;
        }
        Object object = inventoryDragEvent.getWhoClicked();
        if (object instanceof Player && (object = this.mgr.of(player = (Player)object)) != null && ((Game)object).lockInv()) {
            inventoryDragEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent entityExplodeEvent) {
        Game game = this.mgr.gameAt(entityExplodeEvent.getLocation());
        if (game == null) {
            return;
        }
        if (entityExplodeEvent.getEntity() instanceof TNTPrimed) {
            entityExplodeEvent.setCancelled(true);
        } else {
            game.onExplode(entityExplodeEvent);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onBlockExplode(BlockExplodeEvent blockExplodeEvent) {
        if (this.mgr.gameAt(blockExplodeEvent.getBlock().getLocation()) != null) {
            blockExplodeEvent.blockList().clear();
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onCommand(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        Player player = playerCommandPreprocessEvent.getPlayer();
        if (this.mgr.of(player) == null || player.hasPermission("zentra.minigames.admin")) {
            return;
        }
        String string = playerCommandPreprocessEvent.getMessage().toLowerCase();
        String string2 = string.startsWith("/") ? string.substring(1) : string;
        if ((string2 = string2.split(" ")[0]).contains(":")) {
            string2 = string2.substring(string2.indexOf(58) + 1);
        }
        if (string2.equals("zm") || string2.equals("minigames") || string2.equals("zminigames") || this.plugin.getConfig().getStringList("allowed-commands").contains(string2)) {
            return;
        }
        playerCommandPreprocessEvent.setCancelled(true);
        Msg.send(player, "&cTidak bisa memakai command itu saat bermain. Pakai &e/zm leave &cuntuk keluar.");
    }

    /** Tolak perubahan gamemode dari plugin lain (Multiverse dll) selama pemain di dalam game. */
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onGameModeChange(PlayerGameModeChangeEvent event) {
        Game game = this.mgr.of(event.getPlayer());
        if (game == null) {
            return;
        }
        GameMode forced = game.forcedMode(event.getPlayer().getUniqueId());
        if (forced != null && event.getNewGameMode() != forced) {
            event.setCancelled(true);
        }
    }

    /** Setelah pindah world: pasang ulang gamemode/item (plugin inventory bisa menimpa), atau lepas pemain yang dipindah keluar. */
    @EventHandler
    public void onChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (this.mgr.of(player) == null) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            Game game = this.mgr.of(player);
            if (game == null || !player.isOnline()) {
                return;
            }
            World world = this.mgr.world();
            if (world != null && player.getWorld().equals(world)) {
                game.onWorldArrive(player);
            } else {
                this.mgr.leaveNoTeleport(player);
            }
        }, 2L);
    }

    /** Pemain yang logout di dalam arena (restart/crash) dipindah ke spawn supaya tidak tersangkut di void. */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        World world = this.mgr.world();
        if (world == null || !player.getWorld().equals(world) || this.mgr.of(player) != null) {
            return;
        }
        if (this.mgr.gameAt(player.getLocation()) == null || player.hasPermission("zentra.minigames.admin")) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (player.isOnline() && this.mgr.of(player) == null && player.getWorld().equals(world)) {
                this.mgr.sendToSafety(player);
            }
        }, 10L);
    }

    /** Bot Practice di-spawn plugin (reason CUSTOM); Multiverse bisa membatalkannya kalau world melarang monster. */
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (!event.isCancelled() || event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM) {
            return;
        }
        if (this.mgr.gameAt(event.getLocation()) instanceof PracticeGame) {
            event.setCancelled(false);
        }
    }
}
