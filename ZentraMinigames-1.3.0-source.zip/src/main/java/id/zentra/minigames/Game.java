/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.FireworkEffect$Type
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.boss.BarColor
 *  org.bukkit.boss.BarFlag
 *  org.bukkit.boss.BarStyle
 *  org.bukkit.boss.BossBar
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Display$Billboard
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.TextDisplay
 *  org.bukkit.entity.TextDisplay$TextAlignment
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.FireworkMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.util.Vector
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.DuelGame;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ParkourRaceGame;
import id.zentra.minigames.Sidebar;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;

public abstract class Game {
    static final int LOBBY_UP = 50;
    private static final String[] DOTS = new String[]{"", ".", "..", "..."};
    private static final String[] SPIN = new String[]{"&b\u25aa&3\u25aa\u25aa", "&3\u25aa&b\u25aa&3\u25aa", "&3\u25aa\u25aa&b\u25aa", "&3\u25aa&b\u25aa&3\u25aa"};
    private static final String[] TIPS = new String[]{"Klik &fPanggil Teman &7untuk mengajak pemain lain", "Di Duel, pilih kit melalui &fVote Kit", "Klik &fAturan Main &7untuk membaca cara bermain", "Makin ramai makin seru, ajak temanmu!", "Ketik &f/zm leave &7kapan saja untuk keluar"};
    protected final ZentraMinigames plugin;
    protected final World world;
    public final String key;
    public final String name;
    public final Material icon;
    public final int instance;
    public final int cx;
    public final int by;
    public final int cz;
    public final List<String> rules;
    public int min;
    public int max;
    public State state = State.RESETTING;
    public boolean open = true;
    protected boolean pvp;
    protected boolean envDamage;
    protected boolean fallDamage;
    protected boolean canBuild;
    protected boolean allowBuildBlocks;
    protected final java.util.Set<org.bukkit.block.Block> placedBlocks = new java.util.HashSet<>();
    protected boolean gamerulesApplied;
    protected boolean lockInv = true;
    protected boolean continuous;
    protected int voidY;
    protected int countdown;
    protected int cdFull;
    protected int runSecs;
    public final Set<UUID> players = new LinkedHashSet<UUID>();
    public final Set<UUID> alive = new LinkedHashSet<UUID>();
    protected final Map<UUID, UUID> lastHit = new HashMap<UUID, UUID>();
    protected final Map<UUID, Long> lastHitAt = new HashMap<UUID, Long>();
    private final Map<UUID, Saved> saved = new HashMap<UUID, Saved>();
    /** Gamemode yang WAJIB dipakai pemain selama di game (melawan Multiverse / plugin lain yang menimpa gamemode). */
    private final Map<UUID, GameMode> forcedMode = new HashMap<UUID, GameMode>();
    protected final Random rnd = new Random();
    protected final BossBar bar;
    protected long ticks;
    private BukkitTask task;
    private final Map<UUID, Sidebar> boards = new HashMap<UUID, Sidebar>();
    private final Map<UUID, Scoreboard> prevBoards = new HashMap<UUID, Scoreboard>();
    private final Set<UUID> votes = new HashSet<UUID>();
    private final Map<UUID, Long> inviteCd = new HashMap<UUID, Long>();
    private TextDisplay holo;

    protected Game(ZentraMinigames zentraMinigames, String string, String string2, Material material, int n, int n2, int n3, int n4, int n5, int n6, List<String> list) {
        this.plugin = zentraMinigames;
        this.world = zentraMinigames.manager().world();
        this.key = string;
        this.name = string2;
        this.icon = material;
        this.instance = n;
        this.cx = n2;
        this.by = n3;
        this.cz = n4;
        this.min = n5;
        this.max = n6;
        this.rules = list;
        this.voidY = n3 - 15;
        this.bar = Bukkit.createBossBar((String)"", (BarColor)BarColor.BLUE, (BarStyle)BarStyle.SOLID, (BarFlag[])new BarFlag[0]);
    }

    protected abstract void buildArena(Blueprint var1);

    protected abstract void onStart();

    protected void onSecond() {
    }

    protected void onFast() {
    }

    protected void onEnd() {
    }

    protected void onReset() {
    }

    protected void onLeave(Player player, boolean bl) {
    }

    protected void onHit(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setCancelled(true);
    }

    protected String barText() {
        return "&b" + this.name + " &8| &fHidup: &a" + this.alive.size();
    }

    public void onInteract(PlayerInteractEvent playerInteractEvent) {
    }

    public boolean allowBreak(Block block, Player player) {
        if (state != State.RUNNING) return false;
        return placedBlocks.remove(block);
    }

    public boolean allowPlace(Block block, Player player) {
        if (state != State.RUNNING || !allowBuildBlocks) return false;
        if (block.getY() < by - 20 || block.getY() > by + 60) return false;
        if (Math.abs(block.getX() - cx) > 60 || Math.abs(block.getZ() - cz) > 60) return false;
        placedBlocks.add(block);
        return true;
    }

    protected void clearPlacedBlocks() {
        for (Block b : new java.util.ArrayList<>(placedBlocks)) {
            if (b.getType() != Material.AIR) b.setType(Material.AIR, false);
        }
        placedBlocks.clear();
    }

    protected void applyGameRules() {
        if (gamerulesApplied || world == null) return;
        gamerulesApplied = true;
        try {
            world.setGameRule(GameRule.DO_FIRE_TICK, false);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            world.setGameRule(GameRule.MOB_GRIEFING, false);
            world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            world.setGameRule(GameRule.KEEP_INVENTORY, true);
            world.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        } catch (Exception ignored) {}
    }

    public void onExplode(EntityExplodeEvent entityExplodeEvent) {
        entityExplodeEvent.blockList().clear();
    }

    public String id() {
        return this.key + "-" + this.instance;
    }

    public boolean canBuild() {
        return this.canBuild;
    }

    public boolean lockInv() {
        return this.lockInv;
    }

    public boolean joinable() {
        return this.open && (this.state == State.WAITING || this.state == State.COUNTDOWN) && this.players.size() < this.max;
    }

    protected boolean hasLobby() {
        return true;
    }

    public Location lobby() {
        return new Location(this.world, (double)this.cx + 0.5, (double)(this.by + 50 + 1), (double)this.cz + 0.5);
    }

    public Location specSpawn() {
        return new Location(this.world, (double)this.cx + 0.5, (double)(this.by + 30), (double)this.cz + 0.5);
    }

    public void activate() {
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::loop, 20L, 5L);
    }

    public void shutdown() {
        if (this.task != null) {
            this.task.cancel();
        }
        for (UUID uUID : new ArrayList<UUID>(this.players)) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) continue;
            this.restore(player);
        }
        this.players.clear();
        this.alive.clear();
        this.bar.removeAll();
        if (this.holo != null && this.holo.isValid()) {
            this.holo.remove();
        }
    }

    public void build(Runnable runnable) {
        this.build(false, runnable);
    }

    public void build(boolean bl, Runnable runnable) {
        applyGameRules();
        this.state = State.RESETTING;
        Blueprint blueprint = new Blueprint();
        if (bl) {
            Material material = Compat.mat("AIR");
            blueprint.fill(this.cx - 70, Math.max(this.world.getMinHeight(), this.by - 30), this.cz - 70, this.cx + 70, Math.min(this.world.getMaxHeight() - 1, this.by + 70), this.cz + 70, material);
        }
        if (this.hasLobby()) {
            this.buildLobby(blueprint);
        }
        this.buildArena(blueprint);
        this.buildScenery(blueprint);
        blueprint.build(this.plugin, this.world, () -> !bl || this.world.getPlayers().stream().noneMatch(player -> Math.abs(player.getLocation().getX() - (double)this.cx) <= 71.0 && Math.abs(player.getLocation().getZ() - (double)this.cz) <= 71.0), () -> {
            this.ensureHolo();
            if (runnable != null) {
                runnable.run();
            }
        });
    }

    /*
     * WARNING - void declaration
     */
    private void buildLobby(Blueprint blueprint) {
        int object;
        int n = this.by + 50;
        blueprint.cone(this.cx, n - 1, this.cz, 9, 9, Material.DEEPSLATE);
        blueprint.disc(this.cx, n, this.cz, 8, Material.WHITE_CONCRETE);
        blueprint.ring(this.cx, n, this.cz, 5, 6, Material.LIGHT_BLUE_CONCRETE);
        blueprint.disc(this.cx, n, this.cz, 2, Material.SEA_LANTERN);
        for (object = 1; object <= 3; object++) {
            blueprint.ring(this.cx, n + object, this.cz, 7, 8, Material.LIGHT_BLUE_STAINED_GLASS);
        }
        for (int[] nArray : new int[][]{{7, 0}, {-7, 0}, {0, 7}, {0, -7}}) {
            blueprint.fill(this.cx + nArray[0], n + 1, this.cz + nArray[1], this.cx + nArray[0], n + 4, this.cz + nArray[1], Material.QUARTZ_PILLAR);
            blueprint.set(this.cx + nArray[0], n + 5, this.cz + nArray[1], Material.SEA_LANTERN);
        }
        Material material = Compat.mat("QUARTZ_BLOCK");
        Material material2 = Compat.mat("GOLD_BLOCK");
        Material material3 = Compat.mat("SEA_LANTERN");
        blueprint.ring(this.cx, n - 1, this.cz, 9, 12, material);
        blueprint.ring(this.cx, n - 2, this.cz, 10, 11, material2);
        for (int[] nArray : new int[][]{{10, 10}, {-10, 10}, {10, -10}, {-10, -10}}) {
            blueprint.fill(this.cx + nArray[0], n - 4, this.cz + nArray[1], this.cx + nArray[0], n + 8, this.cz + nArray[1], material);
            blueprint.set(this.cx + nArray[0], n + 9, this.cz + nArray[1], material3);
            blueprint.ring(this.cx + nArray[0], n + 7, this.cz + nArray[1], 1, 2, material2);
            blueprint.cone(this.cx + nArray[0], n + 12, this.cz + nArray[1], 2, 3, material);
            blueprint.set(this.cx + nArray[0], n + 13, this.cz + nArray[1], material3);
        }
    }

    private void buildScenery(Blueprint blueprint) {
        Material material = Compat.mat("POLISHED_DEEPSLATE");
        Material material2 = Compat.mat("QUARTZ_BLOCK");
        Material material3 = Compat.mat("SEA_LANTERN");
        Material material4 = Compat.mat("GOLD_BLOCK");
        for (int[] nArray : new int[][]{{-60, -60}, {-60, 60}, {60, -60}, {60, 60}}) {
            int n = this.cx + nArray[0];
            int n2 = this.cz + nArray[1];
            blueprint.cone(n, this.by + 5, n2, 9, 12, material);
            blueprint.disc(n, this.by + 6, n2, 9, material2);
            blueprint.ring(n, this.by + 6, n2, 7, 8, material4);
            blueprint.cylinder(n, this.by + 7, this.by + 34, n2, 3, material);
            for (int n4 : new int[]{12, 22, 32}) {
                blueprint.ring(n, this.by + n4, n2, 3, 4, material2);
                for (int[] nArray2 : new int[][]{{3, 0}, {-3, 0}, {0, 3}, {0, -3}}) {
                    blueprint.set(n + nArray2[0], this.by + n4 + 1, n2 + nArray2[1], material3);
                }
            }
            blueprint.disc(n, this.by + 35, n2, 6, material2);
            blueprint.ring(n, this.by + 36, n2, 4, 6, material4);
            blueprint.cone(n, this.by + 42, n2, 5, 6, material2);
            blueprint.set(n, this.by + 43, n2, material3);
            blueprint.ring(n, this.by + 8, n2, 5, 7, material2);
            blueprint.ring(n, this.by + 9, n2, 5, 6, material4);
            for (int[] nArray3 : new int[][]{{5, 0}, {-5, 0}, {0, 5}, {0, -5}}) {
                blueprint.fill(n + nArray3[0], this.by + 10, n2 + nArray3[1], n + nArray3[0], this.by + 18, n2 + nArray3[1], material2);
                blueprint.set(n + nArray3[0], this.by + 19, n2 + nArray3[1], material3);
            }
        }
    }

    private void loop() {
        ++this.ticks;
        if (this.state == State.RESETTING) {
            return;
        }
        if (this.ticks % 4L == 0L) {
            this.second();
        }
        if (this.state == State.WAITING || this.state == State.COUNTDOWN) {
            this.lobbyAnim();
        }
        if (this.state == State.RUNNING) {
            this.onFast();
        }
        for (UUID uUID : new ArrayList<UUID>(this.players)) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) continue;
            GameMode forced = this.forcedMode.get(uUID);
            if (forced != null && player.getGameMode() != forced) {
                player.setGameMode(forced);
            }
            if (player.getGameMode() != GameMode.SPECTATOR && player.getAllowFlight()) {
                player.setFlying(false);
                player.setAllowFlight(false);
            }
            double d = player.getLocation().getY();
            if (this.state == State.WAITING || this.state == State.COUNTDOWN) {
                if (this.continuous || !(d < (double)(this.by + 50 - 8))) continue;
                player.teleport(this.lobby());
                continue;
            }
            if (!(d < (double)this.voidY)) continue;
            if (this.state == State.RUNNING && this.alive.contains(uUID)) {
                this.onOut(player, this.lastHitter(player), "jatuh ke void");
                continue;
            }
            player.teleport(this.specSpawn());
        }
    }

    private int voteNeed() {
        return Math.max(1, (int)Math.ceil((double)this.players.size() / 2.0));
    }

    private void lobbyAnim() {
        if (this.players.isEmpty()) {
            return;
        }
        long l = this.ticks;
        int n = this.players.size();
        boolean bl = l / 16L % 3L == 2L;
        for (Player player : this.online()) {
            if (this.state == State.COUNTDOWN) {
                Msg.bar(player, "&a\u2714 &7Pemain cukup! Mulai dalam &e" + this.countdown + "s &8| &7Vote: &f" + this.votes.size() + "&7/&f" + this.voteNeed());
                continue;
            }
            if (bl) {
                Msg.bar(player, "&e\u00bb &7" + TIPS[(int)(l / 48L % (long)TIPS.length)]);
                continue;
            }
            if (n == 1 && this.min > 1) {
                Msg.bar(player, SPIN[(int)(l % 4L)] + " &7Belum ada lawan, ajak teman lewat &bPanggil Teman &8" + DOTS[(int)(l % 4L)]);
                continue;
            }
            Msg.bar(player, SPIN[(int)(l % 4L)] + " &7Menunggu pemain &f" + n + "&7/&f" + this.min + " &8" + DOTS[(int)(l % 4L)]);
        }
        if (!this.hasLobby()) {
            return;
        }
        Location location = this.lobby();
        double d = (double)l * 0.4;
        for (int i = 0; i < 3; ++i) {
            double d2 = d + (double)i * 2.094;
            this.world.spawnParticle(Particle.END_ROD, location.getX() + Math.cos(d2) * 6.5, location.getY() + 0.4 + Math.sin((double)l * 0.3 + (double)i) * 0.4, location.getZ() + Math.sin(d2) * 6.5, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    protected String sidebarTitle() {
        return (this.ticks / 4L % 2L == 0L ? "&b&l" : "&3&l") + this.name.toUpperCase();
    }

    protected List<String> sideExtra() {
        return List.of();
    }

    protected List<String> sidebar(Player player) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("&8" + this.id());
        arrayList.add(" ");
        if (this.state == State.WAITING || this.state == State.COUNTDOWN) {
            arrayList.add("&fPemain &8\u00bb &a" + this.players.size() + "&7/&f" + this.max);
            arrayList.add("&fMinimal &8\u00bb &e" + this.min);
            arrayList.add(" ");
            arrayList.add((String)(this.state == State.COUNTDOWN ? "&fMulai &8\u00bb &e" + this.countdown + "s" : "&fStatus &8\u00bb &7menunggu"));
            arrayList.add("&fVote &8\u00bb &a" + this.votes.size() + "&7/&f" + this.voteNeed());
        } else if (this.state == State.RUNNING) {
            arrayList.add("&fHidup &8\u00bb &a" + this.alive.size() + "&7/&f" + this.players.size());
            arrayList.add("&fWaktu &8\u00bb &e" + Game.fmtTime(this.runSecs));
            List<String> list = this.sideExtra();
            if (!list.isEmpty()) {
                arrayList.add(" ");
                arrayList.addAll(list);
            }
        } else {
            arrayList.add("&6Game selesai!");
        }
        arrayList.add(" ");
        arrayList.add("&b/zm leave &7= keluar");
        return arrayList;
    }

    protected static String fmtTime(int n) {
        return String.format("%d:%02d", n / 60, n % 60);
    }

    private void updateBoards() {
        for (Player player : this.online()) {
            Sidebar sidebar = this.boards.get(player.getUniqueId());
            if (sidebar == null) continue;
            sidebar.set(this.sidebarTitle(), this.sidebar(player));
        }
    }

    protected void attachBoard(Player player) {
        UUID uUID = player.getUniqueId();
        this.prevBoards.put(uUID, player.getScoreboard());
        Sidebar sidebar = new Sidebar();
        this.boards.put(uUID, sidebar);
        sidebar.show(player);
    }

    private void detachBoard(Player player) {
        UUID uUID = player.getUniqueId();
        this.boards.remove(uUID);
        Scoreboard scoreboard = this.prevBoards.remove(uUID);
        player.setScoreboard(scoreboard != null ? scoreboard : Bukkit.getScoreboardManager().getMainScoreboard());
    }

    protected Location holoLoc() {
        return this.hasLobby() ? this.lobby().add(0.0, 3.6, 0.0) : null;
    }

    protected Component holoText() {
        String string = switch (this.state.ordinal()) {
            case 0 -> "&7Menunggu pemain...";
            case 1 -> "&eMulai dalam &f" + this.countdown + "s";
            case 2 -> "&cSedang berjalan";
            default -> "&7Menyiapkan arena...";
        };
        return Msg.c("&b&l" + this.name.toUpperCase() + "\n&8&m               \n" + string + "\n&a" + this.players.size() + "&7/&f" + this.max + " &8pemain");
    }

    protected void ensureHolo() {
        if (this.holo != null && this.holo.isValid()) {
            return;
        }
        Location location = this.holoLoc();
        if (location == null) {
            return;
        }
        location.getChunk().load();
        this.holo = (TextDisplay)this.world.spawn(location, TextDisplay.class, textDisplay -> {
            textDisplay.setBillboard(Display.Billboard.CENTER);
            textDisplay.setPersistent(false);
            textDisplay.setAlignment(TextDisplay.TextAlignment.CENTER);
            textDisplay.setBackgroundColor(Color.fromARGB((int)110, (int)0, (int)0, (int)0));
            textDisplay.text(this.holoText());
        });
    }

    private void updateHolo() {
        if (this.players.isEmpty() && (this.holo == null || !this.holo.isValid())) {
            return;
        }
        this.ensureHolo();
        if (this.holo != null && this.holo.isValid()) {
            this.holo.text(this.holoText());
        }
    }

    private void second() {
        if (this.continuous && this.state == State.WAITING) {
            this.state = State.RUNNING;
            this.runSecs = 0;
        }
        this.updateBoards();
        this.updateHolo();
        if (this.state == State.WAITING) {
            int n = this.players.size();
            if (n >= this.min) {
                this.state = State.COUNTDOWN;
                this.cdFull = Math.max(5, this.plugin.getConfig().getInt("countdown", 20));
                if (this instanceof ParkourRaceGame || this instanceof DuelGame) {
                    this.cdFull = Math.max(15, this.cdFull);
                }
                this.countdown = this.cdFull;
                for (Player player : this.online()) {
                    Msg.title(player, "&a&lSIAP-SIAP!", "&7Pemain sudah cukup, game segera mulai", 0, 30, 10);
                    player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.3f);
                }
                this.checkVotes();
            } else if (n > 0) {
                int n2 = this.min - n;
                this.setBar("&b&lMENUNGGU PEMAIN &8\u00bb &f" + n + "&7/&f" + this.min + " &8(butuh &e" + n2 + " &8lagi)", (double)n / (double)this.min, n * 2 < this.min ? BarColor.RED : BarColor.YELLOW);
            }
        } else if (this.state == State.COUNTDOWN) {
            if (this.players.size() < this.min) {
                this.state = State.WAITING;
                this.bc("&cPemain kurang, hitung mundur dibatalkan.");
                this.sound(Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.6f);
                return;
            }
            this.checkVotes();
            if (!(this instanceof ParkourRaceGame) && !(this instanceof DuelGame) && this.players.size() >= this.max && this.countdown > 5) {
                this.countdown = 5;
            }
            if (this.countdown <= 0) {
                this.begin();
                return;
            }
            this.setBar("&a&lMULAI DALAM &f" + this.countdown + "s &8(" + this.players.size() + "/" + this.max + ")", (double)this.countdown / (double)this.cdFull, this.countdown > 10 ? BarColor.GREEN : (this.countdown > 5 ? BarColor.YELLOW : BarColor.RED));
            if (this.countdown == this.cdFull || this.countdown == 15 || this.countdown == 10) {
                this.bc("&7Game dimulai dalam &e" + this.countdown + " &7detik");
            }
            if (this.countdown <= 5) {
                String string = this.countdown >= 4 ? "&e" : (this.countdown == 3 ? "&6" : (this.countdown == 2 ? "&c" : "&4"));
                for (Player player : this.online()) {
                    Msg.title(player, string + "&l" + this.countdown, "&7Bersiaplah!", 0, 20, 5);
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 0.8f + (float)(5 - this.countdown) * 0.15f);
                }
            }
            --this.countdown;
        } else if (this.state == State.RUNNING) {
            ++this.runSecs;
            this.setBar(this.barText(), 1.0, BarColor.BLUE);
            this.onSecond();
        }
    }

    public void forceStart() {
        if (!(this.state != State.WAITING && this.state != State.COUNTDOWN || this.players.isEmpty())) {
            this.begin();
        }
    }

    private void begin() {
        this.state = State.RUNNING;
        this.runSecs = 0;
        this.votes.clear();
        this.alive.clear();
        this.alive.addAll(this.players);
        this.lastHit.clear();
        this.lastHitAt.clear();
        for (Player player : this.online()) {
            this.resetPlayer(player, this.canBuild ? GameMode.SURVIVAL : GameMode.ADVENTURE);
            Msg.title(player, "&b&l" + this.name.toUpperCase(), "&7" + this.rules.get(0), 5, 50, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f, 1.2f);
            Msg.send(player, "&bPertandingan dimulai! &7Semoga berhasil.");
        }
        this.onStart();
    }

    public void lobbyAction(Player player, String string) {
        switch (string) {
            case "leave": {
                if (!this.plugin.manager().leave(player)) break;
                Msg.send(player, "&7Kamu keluar dari game.");
                break;
            }
            case "rules": {
                this.showRules(player);
                break;
            }
            case "invite": {
                this.plugin.manager().openInvites(player, 0);
                break;
            }
            case "vote": {
                Game game = this;
                if (game instanceof DuelGame) {
                    DuelGame duelGame = (DuelGame)game;
                    this.plugin.manager().openDuelVote(player, duelGame);
                    break;
                }
                game = this;
                if (!(game instanceof ParkourRaceGame)) break;
                ParkourRaceGame parkourRaceGame = (ParkourRaceGame)game;
                this.plugin.manager().openRaceVote(player, parkourRaceGame);
                break;
            }
        }
    }

    public void showRules(Player player) {
        Msg.line(player);
        player.sendMessage(Msg.c(" &b&l" + this.name.toUpperCase() + " &8- &7Cara Bermain"));
        int n = 1;
        for (String string : this.rules) {
            player.sendMessage(Msg.c(" &b" + n++ + ". &f" + string));
        }
        Msg.line(player);
        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1.0f, 1.0f);
    }

    private void toggleVote(Player player) {
        if (this.state != State.WAITING && this.state != State.COUNTDOWN) {
            return;
        }
        UUID uUID = player.getUniqueId();
        if (this.votes.remove(uUID)) {
            Msg.send(player, "&7Vote mulai cepat dibatalkan.");
        } else {
            this.votes.add(uUID);
            this.bc("&a" + player.getName() + " &7vote mulai cepat &8(" + this.votes.size() + "/" + this.voteNeed() + ")");
        }
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.4f);
        this.checkVotes();
    }

    private void checkVotes() {
        if (this.state == State.COUNTDOWN && this.votes.size() >= this.voteNeed() && this.countdown > 10) {
            this.countdown = 10;
            this.bc("&aMayoritas pemain setuju, hitung mundur dipercepat!");
        }
    }

    public void invite(Player player, Player player2) {
        if (!this.joinable()) {
            return;
        }
        if (player2 == null || player2.equals((Object)player) || this.plugin.manager().of(player2) != null) {
            Msg.send(player, "&cPemain tidak tersedia.");
            return;
        }
        long l = System.currentTimeMillis();
        Long l2 = this.inviteCd.get(player.getUniqueId());
        if (l2 != null && l - l2 < 30000L) {
            Msg.send(player, "&cTunggu &f" + ((30000L - (l - l2)) / 1000L + 1L) + " detik &clagi sebelum mengajak lagi.");
            return;
        }
        this.inviteCd.put(player.getUniqueId(), l);
        this.plugin.manager().recordInvite(player2, player);
        Component component = Msg.c("&a&l[GABUNG]").clickEvent(ClickEvent.runCommand((String)("/zm accept " + String.valueOf(player.getUniqueId())))).hoverEvent((HoverEventSource)HoverEvent.showText((Component)Msg.c("&7Klik untuk bergabung ke &b" + this.name)));
        Component component2 = Msg.c("&8[&bZentra&3Minigames&8] &7&e" + player.getName() + " &7mengajak main &b" + this.name + " &8(" + this.players.size() + "/" + this.max + ") ").append(component);
        player2.sendMessage(component2);
        player2.playSound(player2.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        Msg.send(player, "&aUndangan terkirim ke &f" + player2.getName() + "&a.");
        player.playSound(player.getLocation(), Sound.BLOCK_BELL_USE, 1.0f, 1.2f);
    }

    private void giveLobbyItems(Player player) {
        player.getInventory().setItem(0, this.plugin.lobbyItem(Material.BOOK, "&e&lAturan Main &7(klik kanan)", "rules", "&7Baca cara bermain"));
        player.getInventory().setItem(1, this.plugin.lobbyItem(Material.BELL, "&b&lPanggil Teman &7(klik kanan)", "invite", "&7Pilih pemain online untuk diundang"));
        if (this instanceof DuelGame) {
            player.getInventory().setItem(4, this.plugin.lobbyItem(Material.CLOCK, "&a&lVote Kit &7(klik kanan)", "vote", "&7Pilih kit duel dengan suara terbanyak"));
        }
        if (this instanceof ParkourRaceGame) {
            player.getInventory().setItem(4, this.plugin.lobbyItem(Material.CLOCK, "&a&lVote Map & Mode &7(klik kanan)", "vote", "&7Pilih map dan mode setelah lawan ditemukan"));
        }
        player.getInventory().setItem(8, this.plugin.leaveItem());
    }

    protected void snapshot(Player player) {
        ItemStack[] itemStackArray = (ItemStack[])player.getInventory().getContents().clone();
        for (int i = 0; i < itemStackArray.length; ++i) {
            if (itemStackArray[i] == null) continue;
            itemStackArray[i] = itemStackArray[i].clone();
        }
        this.saved.put(player.getUniqueId(), new Saved(itemStackArray, player.getLocation().clone(), player.getGameMode(), player.getHealth(), player.getFoodLevel(), player.getSaturation(), player.getExp(), player.getLevel(), new ArrayList<PotionEffect>(player.getActivePotionEffects()), player.getAllowFlight()));
    }

    public boolean join(Player player) {
        if (!this.joinable()) {
            return false;
        }
        this.snapshot(player);
        this.players.add(player.getUniqueId());
        player.leaveVehicle();
        this.resetPlayer(player, GameMode.ADVENTURE);
        player.teleport(this.lobby());
        this.giveLobbyItems(player);
        this.bar.addPlayer(player);
        this.attachBoard(player);
        this.ensureHolo();
        this.bc("&a" + player.getName() + " &7bergabung &8(" + this.players.size() + "/" + this.max + ")");
        Msg.title(player, "&b&l" + this.name.toUpperCase(), "&7Menunggu pemain lain...", 5, 50, 10);
        Msg.line(player);
        player.sendMessage(Msg.c(" &b&l" + this.name.toUpperCase()));
        player.sendMessage(Msg.c(" &7" + this.rules.get(0)));
        player.sendMessage(Msg.c(" "));
        player.sendMessage(Msg.c(" &8\u00bb &fKlik &eAturan Main &funtuk membaca cara bermain"));
        if (this instanceof DuelGame) {
            player.sendMessage(Msg.c(" &8\u00bb &fKlik &aVote Kit &funtuk memilih kit duel"));
        }
        player.sendMessage(Msg.c(" &8\u00bb &fKlik &bPanggil Teman &funtuk mengajak pemain lain"));
        Msg.line(player);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
        this.world.spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0.0, 1.0, 0.0), 20, 0.4, 0.6, 0.4, 0.0);
        for (Player player2 : this.online()) {
            if (player2.equals((Object)player)) continue;
            player2.playSound(player2.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        }
        return true;
    }

    public void leave(Player player) {
        this.leave(player, true);
    }

    public void leave(Player player, boolean teleportBack) {
        UUID uUID = player.getUniqueId();
        if (!this.players.remove(uUID)) {
            return;
        }
        boolean bl = this.alive.remove(uUID);
        this.lastHit.remove(uUID);
        this.lastHitAt.remove(uUID);
        this.votes.remove(uUID);
        Game game = this;
        if (game instanceof DuelGame) {
            DuelGame duelGame = (DuelGame)game;
            duelGame.clearVote(uUID);
        }
        this.restore(player, teleportBack);
        if (this.state == State.ENDING || this.state == State.RESETTING) {
            return;
        }
        this.bc("&c" + player.getName() + " &7keluar &8(" + this.players.size() + ")");
        if (this.state == State.RUNNING) {
            this.onLeave(player, bl);
            this.checkWin();
        } else if (this.state == State.COUNTDOWN && this.players.size() < this.min) {
            this.state = State.WAITING;
        }
    }

    public void playerDied(Player player) {
        if (this.state == State.RUNNING && this.alive.contains(player.getUniqueId())) {
            this.onOut(player, this.lastHitter(player), "tewas");
        } else {
            player.teleport(this.state == State.WAITING || this.state == State.COUNTDOWN ? this.lobby() : this.specSpawn());
        }
    }

    /** Set gamemode dan KUNCI: plugin lain (Multiverse dll) tidak bisa mengubahnya selama pemain di game ini. */
    protected void setMode(Player player, GameMode gameMode) {
        this.forcedMode.put(player.getUniqueId(), gameMode);
        if (player.getGameMode() != gameMode) {
            player.setGameMode(gameMode);
        }
    }

    public GameMode forcedMode(UUID id) {
        return this.forcedMode.get(id);
    }

    /** Set gamemode lalu set ulang beberapa tick kemudian (Multiverse menimpa gamemode setelah pindah world). */
    protected void reassertMode(Player player, GameMode gameMode) {
        this.setMode(player, gameMode);
        UUID id = player.getUniqueId();
        for (long delay : new long[]{1L, 5L, 20L, 60L}) {
            Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
                Player p = Bukkit.getPlayer(id);
                GameMode want = this.forcedMode.get(id);
                if (p != null && p.isOnline() && this.players.contains(id) && want != null && p.getGameMode() != want) {
                    p.setGameMode(want);
                }
            }, delay);
        }
    }

    /** Dipanggil beberapa tick setelah pemain tiba di world game (plugin inventory/gamemode world bisa menimpa item & mode). */
    public void onWorldArrive(Player player) {
        GameMode want = this.forcedMode.get(player.getUniqueId());
        if (want != null && player.getGameMode() != want) {
            player.setGameMode(want);
        }
        if (this.hasLobby() && (this.state == State.WAITING || this.state == State.COUNTDOWN)) {
            player.getInventory().clear();
            this.giveLobbyItems(player);
        }
    }

    protected void resetPlayer(Player player, GameMode gameMode) {
        player.getInventory().clear();
        this.reassertMode(player, gameMode);
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            player.removePotionEffect(potionEffect.getType());
        }
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20.0f);
        player.setExp(0.0f);
        player.setLevel(0);
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
        player.setAllowFlight(false);
    }

    protected void restore(Player player) {
        this.restore(player, true);
    }

    protected void restore(Player player, boolean teleportBack) {
        this.forcedMode.remove(player.getUniqueId());
        Saved saved = this.saved.remove(player.getUniqueId());
        this.bar.removePlayer(player);
        this.detachBoard(player);
        this.votes.remove(player.getUniqueId());
        this.plugin.setScale(player, 1.0);
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            player.removePotionEffect(potionEffect.getType());
        }
        player.closeInventory();
        player.setItemOnCursor(null);
        player.getInventory().clear();
        if (saved == null) {
            player.setGameMode(GameMode.SURVIVAL);
            if (teleportBack) {
                player.teleport(((World)Bukkit.getWorlds().get(0)).getSpawnLocation());
            }
            return;
        }
        if (teleportBack) {
            player.teleport(saved.loc());
        }
        player.setGameMode(saved.gm());
        player.getInventory().setContents(saved.inv());
        player.setHealth(Math.max(1.0, Math.min(saved.hp(), player.getMaxHealth())));
        player.setFoodLevel(saved.food());
        player.setSaturation(saved.sat());
        player.setExp(saved.exp());
        player.setLevel(saved.lvl());
        for (PotionEffect potionEffect : saved.fx()) {
            player.addPotionEffect(potionEffect);
        }
        player.setAllowFlight(saved.fly() || saved.gm() == GameMode.CREATIVE || saved.gm() == GameMode.SPECTATOR);
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
    }

    public void onDamage(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        UUID uUID = player.getUniqueId();
        if (this.state != State.RUNNING || !this.alive.contains(uUID)) {
            entityDamageEvent.setCancelled(true);
            return;
        }
        EntityDamageEvent.DamageCause damageCause = entityDamageEvent.getCause();
        if (damageCause == EntityDamageEvent.DamageCause.VOID) {
            entityDamageEvent.setCancelled(true);
            this.onOut(player, this.lastHitter(player), "jatuh ke void");
            return;
        }
        if (damageCause == EntityDamageEvent.DamageCause.FALL && !this.fallDamage) {
            entityDamageEvent.setCancelled(true);
            return;
        }
        if (player2 != null) {
            if (!this.alive.contains(player2.getUniqueId())) {
                entityDamageEvent.setCancelled(true);
                return;
            }
            this.lastHit.put(uUID, player2.getUniqueId());
            this.lastHitAt.put(uUID, System.currentTimeMillis());
            if (!this.pvp) {
                this.onHit(entityDamageEvent, player, player2);
                return;
            }
        } else if (!this.envDamage && !this.pvp && damageCause != EntityDamageEvent.DamageCause.FALL) {
            entityDamageEvent.setCancelled(true);
            return;
        }
        if (!entityDamageEvent.isCancelled() && player.getHealth() - entityDamageEvent.getFinalDamage() <= 0.0) {
            entityDamageEvent.setCancelled(true);
            this.onOut(player, this.lastHitter(player), "tewas");
        }
    }

    protected Player lastHitter(Player player) {
        UUID uUID = this.lastHit.get(player.getUniqueId());
        Long l = this.lastHitAt.get(player.getUniqueId());
        if (uUID == null || l == null || System.currentTimeMillis() - l > 12000L) {
            return null;
        }
        Player player2 = Bukkit.getPlayer((UUID)uUID);
        return player2 != null && this.players.contains(uUID) ? player2 : null;
    }

    protected void onOut(Player player, Player player2, String string) {
        this.eliminate(player, player2, string);
    }

    protected void eliminate(Player player, Player player2, String string) {
        if (!this.alive.remove(player.getUniqueId())) {
            return;
        }
        String string2 = player2 != null ? "&c" + player.getName() + " &7dikalahkan oleh &e" + player2.getName() : "&c" + player.getName() + " &7" + string;
        this.bc(string2 + " &8(" + this.alive.size() + " tersisa)");
        player.getInventory().clear();
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            player.removePotionEffect(potionEffect.getType());
        }
        player.teleport(this.specSpawn());
        this.setMode(player, GameMode.SPECTATOR);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1.0f, 1.0f);
        Msg.title(player, "&c&lTERSINGKIR", "&7Posisi #" + (this.alive.size() + 1), 5, 40, 10);
        this.checkWin();
    }

    protected void checkWin() {
        if (this.state != State.RUNNING) {
            return;
        }
        if (this.alive.size() <= 1) {
            this.end(this.alivePlayers());
        }
    }

    protected void end(List<Player> list) {
        if (this.state == State.ENDING || this.state == State.RESETTING) {
            return;
        }
        this.state = State.ENDING;
        this.onEnd();
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Player object : list) { arrayList.add(object.getName()); }
        String object2 = arrayList.isEmpty() ? "Tidak ada" : String.join((CharSequence)"&7, &a", arrayList);
        if (!arrayList.isEmpty()) {
            this.plugin.announceWin(String.join((CharSequence)", ", arrayList), this.name + " " + this.instance);
        }
        for (Player object4 : this.online()) {
            boolean bl = list.contains(object4);
            Msg.title((Player)object4, bl ? "&6&lKEMENANGAN!" : "&b&lPERMAINAN SELESAI", "&a" + (String)object2, 5, 80, 20);
            Msg.line((Player)object4);
            object4.sendMessage(Msg.c("  &6&l\u2605 PEMENANG \u2605"));
            object4.sendMessage(Msg.c("  &a" + (String)object2));
            object4.sendMessage(Msg.c("  &7Game: &f" + this.name + " &8| &7Durasi: &f" + Game.fmtTime(this.runSecs)));
            object4.sendMessage(Msg.c("  &7Terima kasih sudah bermain!"));
            Msg.line((Player)object4);
            object4.playSound(object4.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            if (!bl) continue;
            Compat.sound("ENTITY_PLAYER_LEVELUP", (Entity)object4);
        }
        List<String> object = this.plugin.getConfig().getStringList("rewards.win");
        for (Player player : list) {
            this.setMode(player, GameMode.ADVENTURE);
            for (int i = 0; i < 4; ++i) {
                Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
                    if (player.isOnline()) {
                        this.fireworkAt(player.getLocation());
                    }
                }, (long)i * 15L);
            }
            Iterator iterator = object.iterator();
            while (iterator.hasNext()) {
                String string = (String)iterator.next();
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)string.replace("%player%", player.getName()));
            }
        }
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, this::finish, 140L);
    }

    private void finish() {
        for (Player object : this.online()) {
            this.restore(object);
        }
        for (UUID uUID : this.players) {
            this.plugin.manager().forget(uUID);
        }
        this.players.clear();
        this.alive.clear();
        this.saved.clear();
        this.forcedMode.clear();
        this.votes.clear();
        this.bar.removeAll();
        this.state = State.RESETTING;
        this.clearPlacedBlocks();
        this.onReset();
        for (Entity entity : this.world.getNearbyEntities(new Location(this.world, (double)this.cx, (double)(this.by + 20), (double)this.cz), 130.0, 120.0, 130.0)) {
            if (entity instanceof Player) continue;
            entity.remove();
        }
        this.build(() -> {
            this.state = State.WAITING;
        });
    }

    protected void bc(String string) {
        for (Player player : this.online()) {
            player.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7" + string));
        }
    }

    protected void setBar(String string, double d, BarColor barColor) {
        this.bar.setTitle(ChatColor.translateAlternateColorCodes((char)'&', (String)string));
        this.bar.setProgress(Math.max(0.0, Math.min(1.0, d)));
        this.bar.setColor(barColor);
    }

    protected List<Player> online() {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (UUID uUID : this.players) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) continue;
            arrayList.add(player);
        }
        return arrayList;
    }

    protected List<Player> alivePlayers() {
        return this.aliveWhere(uUID -> true);
    }

    protected List<Player> aliveWhere(Predicate<UUID> predicate) {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (UUID uUID : this.alive) {
            Player player;
            if (!predicate.test(uUID) || (player = Bukkit.getPlayer((UUID)uUID)) == null) continue;
            arrayList.add(player);
        }
        return arrayList;
    }

    protected void spreadRing(List<Player> list, double d, double d2) {
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            double d3 = Math.PI * 2 * (double)i / (double)Math.max(1, n);
            double d4 = (double)this.cx + 0.5 + Math.cos(d3) * d;
            double d5 = (double)this.cz + 0.5 + Math.sin(d3) * d;
            Location location = new Location(this.world, d4, d2, d5);
            location.setDirection(new Vector((double)this.cx + 0.5 - d4, 0.0, (double)this.cz + 0.5 - d5));
            list.get(i).teleport(location);
        }
    }

    protected ItemStack item(Material material, int n, String string, String ... stringArray) {
        ItemStack itemStack = new ItemStack(material, n);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.displayName(Msg.c(string));
        if (stringArray.length > 0) {
            ArrayList<Component> arrayList = new ArrayList<Component>();
            for (String string2 : stringArray) {
                arrayList.add(Msg.c(string2));
            }
            itemMeta.lore(arrayList);
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    protected void fireworkAt(Location location) {
        Firework firework = (Firework)this.world.spawnEntity(location, EntityType.FIREWORK_ROCKET);
        FireworkMeta fireworkMeta = firework.getFireworkMeta();
        fireworkMeta.addEffect(FireworkEffect.builder().withColor(new Color[]{Color.AQUA, Color.WHITE, Color.YELLOW}).with(FireworkEffect.Type.BALL_LARGE).withFlicker().build());
        fireworkMeta.setPower(1);
        firework.setFireworkMeta(fireworkMeta);
    }

    protected void sound(Sound sound, float f, float f2) {
        for (Player player : this.online()) {
            player.playSound(player.getLocation(), sound, f, f2);
        }
    }

    public static enum State {
        WAITING,
        COUNTDOWN,
        RUNNING,
        ENDING,
        RESETTING;

    }

    private record Saved(ItemStack[] inv, Location loc, GameMode gm, double hp, int food, float sat, float exp, int lvl, List<PotionEffect> fx, boolean fly) {
    }
}

