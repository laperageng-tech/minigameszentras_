/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package id.zentra.minigames;

import id.zentra.minigames.Game;
import id.zentra.minigames.GameManager;
import id.zentra.minigames.Kit;
import id.zentra.minigames.Msg;
import id.zentra.minigames.PracticeGame;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class MinigamesCommand
implements CommandExecutor,
TabCompleter {
    private final ZentraMinigames plugin;
    private final GameManager mgr;

    public MinigamesCommand(ZentraMinigames zentraMinigames, GameManager gameManager) {
        this.plugin = zentraMinigames;
        this.mgr = gameManager;
    }

    /** Terjemahkan argumen pemain: nama pemain atau selector (@p, @a, @a[distance=..5]) untuk command block. */
    private List<Player> targets(CommandSender sender, String arg) {
        ArrayList<Player> out = new ArrayList<Player>();
        try {
            if (arg.startsWith("@")) {
                for (org.bukkit.entity.Entity entity : Bukkit.selectEntities(sender, arg)) {
                    if (entity instanceof Player p) {
                        out.add(p);
                    }
                }
            } else {
                Player p = Bukkit.getPlayerExact(arg);
                if (p != null) {
                    out.add(p);
                }
            }
        }
        catch (IllegalArgumentException ignored) {
        }
        return out;
    }

    private boolean admin(CommandSender commandSender) {
        return commandSender.hasPermission("zentra.minigames.admin");
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        Player player = commandSender instanceof Player ? (Player)commandSender : null;
        String object;
        if (stringArray.length == 0) {
            if (player != null) {
                this.mgr.openMenu(player);
            } else {
                commandSender.sendMessage("Perintah ini untuk pemain.");
            }
            return true;
        }
        switch (object = stringArray[0].toLowerCase()) {
            case "join": {
                if (stringArray.length >= 3) {
                    // /zm join <game> <pemain|@p|@a[...]>  -> untuk command block / console / admin
                    if (!this.admin(commandSender)) {
                        commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cKamu tidak punya izin."));
                        return true;
                    }
                    List<Player> targets = this.targets(commandSender, stringArray[2]);
                    if (targets.isEmpty()) {
                        commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cPemain tidak ditemukan: " + stringArray[2]));
                        return true;
                    }
                    for (Player target : targets) {
                        this.mgr.join(target, stringArray[1].toLowerCase());
                    }
                    return true;
                }
                if (player == null) {
                    commandSender.sendMessage("Pakai: /zm join <game> <pemain|@p>");
                    return true;
                }
                if (stringArray.length < 2) {
                    this.mgr.openMenu(player);
                    break;
                }
                this.mgr.join(player, stringArray[1].toLowerCase());
                break;
            }
            case "accept": {
                if (player == null || stringArray.length < 2) {
                    return true;
                }
                try {
                    this.mgr.acceptInvite(player, UUID.fromString(stringArray[1]));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    Msg.send(player, "&cUndangan tidak valid.");
                }
                break;
            }
            case "practice": {
                Kit kit;
                if (stringArray.length >= 3) {
                    // /zm practice <kit> <pemain|@p>
                    if (!this.admin(commandSender)) {
                        commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cKamu tidak punya izin."));
                        return true;
                    }
                    Kit chosen = Kit.parse(stringArray[1]);
                    for (Player target : this.targets(commandSender, stringArray[2])) {
                        if (chosen == null) {
                            this.mgr.join(target, "practice");
                        } else {
                            this.mgr.pickKit(target, chosen);
                        }
                    }
                    return true;
                }
                if (player == null) {
                    commandSender.sendMessage("Pakai: /zm practice <kit> <pemain|@p>");
                    return true;
                }
                Kit kit2 = kit = stringArray.length >= 2 ? Kit.parse(stringArray[1]) : null;
                if (kit == null) {
                    this.mgr.join(player, "practice");
                    break;
                }
                this.mgr.pickKit(player, kit);
                break;
            }
            case "bot": {
                int n = -1;
                String string2;
                if (player == null) {
                    return true;
                }
                switch (string2 = stringArray.length >= 2 ? stringArray[1].toLowerCase() : "") {
                    case "off": 
                    case "mati": {
                        int n2 = 0;
                        break;
                    }
                    case "mudah": 
                    case "easy": {
                        n = 1;
                        break;
                    }
                    case "sedang": 
                    case "medium": {
                        n = 2;
                        break;
                    }
                    case "sulit": 
                    case "hard": {
                        n = 3;
                        break;
                    }
                    default: {
                        int n2 = n = -1;
                    }
                }
                if (n < 0) {
                    Msg.send(player, "&cPakai: /zm bot <mati|mudah|sedang|sulit>");
                    break;
                }
                this.mgr.setBot(player, n);
                if (this.mgr.of(player) instanceof PracticeGame) break;
                Msg.send(player, "&7Tingkat bot disimpan, aktif saat kamu masuk Practice PvP.");
                break;
            }
            case "leave": {
                if (stringArray.length >= 2) {
                    // /zm leave <pemain|@p>
                    if (!this.admin(commandSender)) {
                        commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cKamu tidak punya izin."));
                        return true;
                    }
                    for (Player target : this.targets(commandSender, stringArray[1])) {
                        if (this.mgr.leave(target)) {
                            Msg.send(target, "&7Kamu dikeluarkan dari game.");
                        }
                    }
                    return true;
                }
                if (player == null) {
                    commandSender.sendMessage("Pakai: /zm leave <pemain|@p>");
                    return true;
                }
                if (this.mgr.leave(player)) {
                    Msg.send(player, "&7Kamu keluar dari game.");
                    break;
                }
                Msg.send(player, "&cKamu tidak sedang berada di game.");
                break;
            }
            case "list": {
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&bDaftar game:"));
                for (String string3 : this.mgr.keys()) {
                    for (Game game : this.mgr.list(string3)) {
                        commandSender.sendMessage(Msg.c("&8 \u2022 &f" + game.id() + " &8- &e" + String.valueOf((Object)game.state) + " &8(&a" + game.players.size() + "&8/" + game.max + ")" + (game.open ? "" : " &c[ditutup]")));
                    }
                }
                break;
            }
            case "rules": {
                if (stringArray.length < 2 || this.mgr.list(stringArray[1].toLowerCase()) == null) {
                    commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cPakai: /zm rules <game>"));
                    return true;
                }
                Game game = this.mgr.list(stringArray[1].toLowerCase()).get(0);
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&b" + game.name + " &7- Aturan:"));
                for (String string4 : game.rules) {
                    commandSender.sendMessage(Msg.c("&8 \u2022 &f" + string4));
                }
                break;
            }
            case "menu": {
                // /zm menu [pemain|@p]
                if (stringArray.length >= 2) {
                    if (!this.admin(commandSender)) {
                        commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cKamu tidak punya izin."));
                        return true;
                    }
                    for (Player target : this.targets(commandSender, stringArray[1])) {
                        this.mgr.openMenu(target);
                    }
                } else if (player != null) {
                    this.mgr.openMenu(player);
                }
                break;
            }
            case "fix": 
            case "build": 
            case "forcestart": 
            case "open": 
            case "close": 
            case "reload": {
                if (!this.admin(commandSender)) {
                    commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cKamu tidak punya izin."));
                    return true;
                }
                this.adminCmd(commandSender, player, (String)object, stringArray);
                break;
            }
            default: {
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cPerintah tidak dikenal. /zm"));
            }
        }
        return true;
    }

    private void adminCmd(CommandSender commandSender, Player player, String string, String[] stringArray) {
        switch (string) {
            case "reload": {
                this.plugin.reloadConfig();
                this.plugin.refreshWorld();
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&aConfig dimuat ulang."));
                break;
            }
            case "fix": {
                this.plugin.refreshWorld();
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&aPengaturan world (PvP, difficulty, border, gamerule) diterapkan ulang."));
                break;
            }
            case "forcestart": {
                Game game;
                Game game2 = game = player == null ? null : this.mgr.of(player);
                if (game == null) {
                    commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cMasuk dulu ke sebuah game."));
                    break;
                }
                game.forceStart();
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&aGame dipaksa mulai."));
                break;
            }
            case "build": {
                if (stringArray.length < 2) {
                    commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cPakai: /zm build <game|all>"));
                    return;
                }
                this.mgr.rebuild(stringArray[1].toLowerCase());
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&aArena masuk antrean pembangunan (arena yang sedang dipakai dilewati)."));
                break;
            }
            default: {
                if (stringArray.length < 2 || this.mgr.list(stringArray[1].toLowerCase()) == null) {
                    commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&cPakai: /zm " + string + " <game>"));
                    return;
                }
                this.mgr.setOpen(stringArray[1].toLowerCase(), string.equals("open"));
                commandSender.sendMessage(Msg.c("&8[&bZentra&3Minigames&8] &7&a" + stringArray[1] + (string.equals("open") ? " dibuka." : " ditutup.")));
            }
        }
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (stringArray.length == 1) {
            arrayList.addAll(List.of("join", "leave", "list", "rules", "practice", "bot"));
            if (this.admin(commandSender)) {
                arrayList.addAll(List.of("build", "forcestart", "open", "close", "reload", "fix", "menu"));
            }
        } else if (stringArray.length == 3 && this.admin(commandSender) && List.of("join", "practice").contains(stringArray[0].toLowerCase())) {
            arrayList.add("@p");
            arrayList.add("@a");
            for (Player online : Bukkit.getOnlinePlayers()) {
                arrayList.add(online.getName());
            }
        } else if (stringArray.length == 2 && stringArray[0].equalsIgnoreCase("bot")) {
            arrayList.addAll(List.of("mati", "mudah", "sedang", "sulit"));
        } else if (stringArray.length == 2 && stringArray[0].equalsIgnoreCase("practice")) {
            for (Kit kit : Kit.values()) {
                arrayList.add(kit.name().toLowerCase());
            }
        } else if (stringArray.length == 2) {
            arrayList.addAll(this.mgr.keys());
            if (stringArray[0].equalsIgnoreCase("build")) {
                arrayList.add("all");
            }
        }
        String string3 = stringArray[stringArray.length - 1].toLowerCase();
        arrayList.removeIf(string2 -> !string2.startsWith(string3));
        return arrayList;
    }
}

