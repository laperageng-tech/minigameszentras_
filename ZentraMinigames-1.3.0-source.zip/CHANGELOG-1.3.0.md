# ZentraMinigames 1.3.0 - perbaikan untuk world Multiverse

## Masalah yang diperbaiki
- **PvP tidak bisa saling pukul**: world Multiverse dengan `pvp=false` membatalkan damage, dan listener lama langsung `return` kalau event sudah dibatalkan. Sekarang plugin memaksa `world.setPVP(true)` (dicek tiap 10 detik) dan, selama game RUNNING, aturan game mengalahkan pembatalan dari plugin lain (Multiverse/WorldGuard/skript).
- **Tidak bisa pasang block**: (1) gamemode Adventure dari Multiverse menimpa mode pemain -> sekarang gamemode DIKUNCI per game (`setMode`, event `PlayerGameModeChangeEvent` dari plugin lain dibatalkan, dan dicek ulang tiap 5 tick); (2) `BlockPlaceEvent.canBuild=false` dari plugin proteksi -> dipaksa true; (3) `PlayerInteractEvent` yang dibatalkan plugin lain di-uncancel saat game build berjalan; (4) `BlockBreakEvent` memakai prioritas HIGHEST.
- **Bot Practice tidak muncul**: spawn Husk yang dibatalkan Multiverse (monsters off) di-uncancel; difficulty PEACEFUL diubah ke NORMAL.
- **World border kecil**: kalau border world lebih kecil dari koordinat arena, border otomatis diperbesar (log warning).
- **Item/kit hilang setelah pindah world** (Multiverse-Inventories): kit/lobby item dipasang ulang 2 tick setelah tiba.
- **Pemain dipindah keluar lewat /mv tp, /spawn, dll** saat di game: otomatis dilepas dari game (inventory dikembalikan, tanpa teleport balik).
- **Pemain tersangkut di arena setelah restart/crash**: saat join otomatis dipindah ke spawn world utama (admin dikecualikan).
- Pemain luar game tidak bisa memukul pemain di dalam game.

## Dukungan command block / console
```
/zm join sumo @p
/zm join duel @a[distance=..3]
/zm practice crystal @p
/zm leave @p
/zm menu @p
```
`/zm join <game> <pemain|selector>` memerlukan izin `zentra.minigames.admin` (command block dan console otomatis punya). Game key: sumo, tnttag, crumble, colorrush, pillars, tinyhunt, duel, practice, practicebot, bridge, skyparkour, iceparkour, netherparkour, parkourrace.

## Command baru
- `/zm fix` - terapkan ulang pengaturan world (PvP, difficulty, border, gamerule) tanpa restart.
- `/zm reload` sekarang juga menerapkan ulang pengaturan world.

## Config baru
Bagian `world-fix` (force-pvp, force-difficulty, fix-border), semua default `true`.
