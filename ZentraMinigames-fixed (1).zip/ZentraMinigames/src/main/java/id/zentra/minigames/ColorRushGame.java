package id.zentra.minigames;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

/** Color Rush: berdiri di warna yang diminta, warna lain lenyap. */
public final class ColorRushGame extends Game {

    private static final String[] C = {"WHITE", "ORANGE", "MAGENTA", "LIGHT_BLUE", "YELLOW", "LIME", "PINK", "CYAN", "PURPLE", "BLUE", "GREEN", "RED"};
    private static final String[] N = {"Putih", "Oranye", "Magenta", "Biru Muda", "Kuning", "Hijau Muda", "Pink", "Sian", "Ungu", "Biru", "Hijau", "Merah"};
    private static final Material[] M = new Material[12];
    private static final int HALF = 18;
    private static final int TILE = 3;
    private static final int T = 12;

    static {
        for (int i = 0; i < T; i++) {
            M[i] = Material.valueOf(C[i] + "_CONCRETE");
        }
    }

    private final int[][] tiles = new int[T][T];
    private int phase;
    private int timer;
    private int round;
    private int target;

    public ColorRushGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "colorrush", "Color Rush", Material.LIME_CONCRETE, instance, cx, by, cz, 2, 16, List.of(
                "Berdiri di warna yang diminta sebelum musik berhenti!",
                "Tiap ronde sebuah warna ditampilkan di hotbar dan layarmu. Warna lain akan lenyap.",
                "Waktu berpikir makin singkat setiap ronde. Dorong lawan dari warna aman dengan pukulan!",
                "Yang jatuh ke void tersingkir. Bertahan sampai ronde ke-25 atau jadi satu-satunya."));
        this.voidY = by - 8;
    }

    private void randomTiles() {
        for (int i = 0; i < T; i++) {
            for (int j = 0; j < T; j++) {
                tiles[i][j] = rnd.nextInt(T);
            }
        }
    }

    @Override
    protected void buildArena(Blueprint bp) {
        randomTiles();
        bp.cone(cx, by - 16, cz, 19, 12, Material.AMETHYST_BLOCK);
        for (int i = 0; i < T; i++) {
            for (int j = 0; j < T; j++) {
                int x = cx - HALF + i * TILE;
                int z = cz - HALF + j * TILE;
                bp.fill(x, by, z, x + TILE - 1, by, z + TILE - 1, M[tiles[i][j]]);
            }
        }
        for (int[] d : new int[][]{{24, 24}, {-24, 24}, {24, -24}, {-24, -24}}) {
            int x = cx + d[0];
            int z = cz + d[1];
            bp.fill(x, by - 12, z, x, by + 8, z, Material.BLACK_CONCRETE);
            bp.set(x, by + 9, z, Material.NOTE_BLOCK);
            bp.set(x, by + 10, z, Material.SEA_LANTERN);
        }
    }

    private void paintFloor() {
        randomTiles();
        for (int i = 0; i < T; i++) {
            for (int j = 0; j < T; j++) {
                for (int k = 0; k < TILE; k++) {
                    for (int l = 0; l < TILE; l++) {
                        world.getBlockAt(cx - HALF + i * TILE + k, by, cz - HALF + j * TILE + l).setType(M[tiles[i][j]], false);
                    }
                }
            }
        }
    }

    private void clearOthers() {
        for (int i = 0; i < T; i++) {
            for (int j = 0; j < T; j++) {
                if (tiles[i][j] == target) {
                    continue;
                }
                for (int k = 0; k < TILE; k++) {
                    for (int l = 0; l < TILE; l++) {
                        world.getBlockAt(cx - HALF + i * TILE + k, by, cz - HALF + j * TILE + l).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    @Override
    protected void onStart() {
        round = 0;
        phase = 0;
        timer = 3;
        paintFloor();
        spreadRing(alivePlayers(), 12.0, by + 1);
    }

    @Override
    protected void onSecond() {
        timer--;
        if (phase == 0) {
            if (timer <= 0) {
                round++;
                target = tiles[rnd.nextInt(T)][rnd.nextInt(T)];
                phase = 1;
                timer = Math.max(2, 8 - round / 2);
                for (Player p : alivePlayers()) {
                    ItemStack stack = item(M[target], 1, "&f&lBerdiri di: " + N[target]);
                    for (int i = 0; i < 9; i++) {
                        p.getInventory().setItem(i, stack);
                    }
                    Msg.title(p, "&e&lRONDE " + round, "&fBerdiri di warna &b&l" + N[target], 0, 30, 5);
                }
                sound(Sound.BLOCK_NOTE_BLOCK_BIT, 1.0f, 1.2f);
            } else {
                for (Player p : alivePlayers()) {
                    Msg.bar(p, "&eBersiap...");
                }
            }
        } else if (phase == 1) {
            for (Player p : alivePlayers()) {
                Msg.bar(p, "&fBerdiri di &b&l" + N[target] + " &8| &c" + Math.max(0, timer) + "s");
                p.setLevel(Math.max(0, timer));
            }
            sound(Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 1.0f + (1.0f - timer / 8.0f));
            if (timer <= 0) {
                clearOthers();
                sound(Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1.5f);
                phase = 2;
                timer = 3;
            }
        } else if (timer <= 0) {
            if (round >= 25) {
                end(alivePlayers());
                return;
            }
            paintFloor();
            phase = 0;
            timer = 2;
            for (Player p : alivePlayers()) {
                p.getInventory().clear();
                p.setLevel(0);
            }
        }
    }

    @Override
    protected void onHit(EntityDamageEvent e, Player victim, Player attacker) {
        e.setDamage(0.0);
    }

    @Override
    protected String barText() {
        return "&dColor Rush &8| &fRonde &e" + round + " &8| &fHidup: &a" + alive.size();
    }

    @Override
    protected List<String> sideExtra() {
        return List.of("&fRonde &8\u00bb &e" + round + "&7/25", "&fHidup &8\u00bb &a" + alive.size());
    }

    @SuppressWarnings("unused")
    private static Location unused() {
        return null;
    }
}
