package id.zentra.minigames;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/** Crumble Run: lantai 5 lapis hancur di bawah kaki pemain. */
public final class CrumbleRunGame extends Game {

    private static final Material[] L = {Material.RED_TERRACOTTA, Material.ORANGE_TERRACOTTA, Material.YELLOW_TERRACOTTA,
            Material.LIME_TERRACOTTA, Material.WHITE_TERRACOTTA};

    private final Map<Block, Integer> pending = new HashMap<>();

    public CrumbleRunGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "crumble", "Crumble Run", Material.ORANGE_TERRACOTTA, instance, cx, by, cz, 2, 14, List.of(
                "Terus bergerak! Lantai hancur di bawah kakimu!",
                "Ada 5 lapis lantai. Jatuh ke lapis bawah masih boleh, jatuh ke void berarti tersingkir.",
                "Kamu punya 3 Bulu Dash: klik kanan untuk melesat ke depan dan melompati celah.",
                "Pemain terakhir yang masih hidup menang."));
        this.voidY = by - 24 - 6;
    }

    private boolean isLayer(Material m) {
        for (Material l : L) {
            if (l == m) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 26, cz, 15, 12, Material.SMOOTH_BASALT);
        for (int i = 0; i < 5; i++) {
            bp.disc(cx, by - 6 * i, cz, 16, L[i]);
            bp.ring(cx, by - 6 * i, cz, 15, 16, Material.RED_TERRACOTTA);
        }
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8.0;
            int x = cx + (int) Math.round(Math.cos(a) * 19.0);
            int z = cz + (int) Math.round(Math.sin(a) * 19.0);
            bp.fill(x, by - 26, z, x, by + 8, z, Material.CRYING_OBSIDIAN);
            bp.set(x, by + 9, z, Material.SHROOMLIGHT);
        }
    }

    @Override
    protected void onStart() {
        pending.clear();
        for (Player p : alivePlayers()) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double r = rnd.nextDouble() * 12.0;
            p.teleport(new Location(world, cx + 0.5 + Math.cos(a) * r, by + 1, cz + 0.5 + Math.sin(a) * r));
            p.getInventory().setItem(0, item(Material.FEATHER, 3, "&b&lBulu Dash", "&7Klik kanan untuk melesat!"));
        }
        bc("&eLantai mulai hancur saat kamu menginjaknya. Lari!");
    }

    @Override
    protected void onFast() {
        for (Player p : alivePlayers()) {
            Location loc = p.getLocation();
            for (double dx : new double[]{-0.3, 0.3}) {
                for (double dz : new double[]{-0.3, 0.3}) {
                    Block b = world.getBlockAt((int) Math.floor(loc.getX() + dx), (int) Math.floor(loc.getY() - 0.1),
                            (int) Math.floor(loc.getZ() + dz));
                    if (isLayer(b.getType()) && !pending.containsKey(b)) {
                        pending.put(b, 8);
                    }
                }
            }
        }
        Iterator<Map.Entry<Block, Integer>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Block, Integer> en = it.next();
            en.setValue(en.getValue() - 1);
            if (en.getValue() > 0) {
                continue;
            }
            Block b = en.getKey();
            b.setType(Material.AIR, false);
            world.spawnParticle(Particle.CLOUD, b.getLocation().add(0.5, 0.8, 0.5), 2, 0.2, 0.1, 0.2, 0.01);
            it.remove();
        }
    }

    @Override
    protected void onInteract(PlayerInteractEvent e) {
        if (state != State.RUNNING) {
            return;
        }
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack stack = e.getItem();
        if (stack == null || stack.getType() != Material.FEATHER) {
            return;
        }
        Player p = e.getPlayer();
        if (!alive.contains(p.getUniqueId())) {
            return;
        }
        e.setCancelled(true);
        stack.setAmount(stack.getAmount() - 1);
        p.setVelocity(p.getLocation().getDirection().multiply(0.9).setY(0.75));
        p.playSound(p.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.3f);
    }

    @Override
    protected void onReset() {
        pending.clear();
    }

    @Override
    protected String barText() {
        return "&6Crumble Run &8| &fHidup: &a" + alive.size();
    }

    @Override
    protected List<String> sideExtra() {
        return List.of("&fHidup &8\u00bb &a" + alive.size(), "&fWaktu &8\u00bb &e" + fmtTime(runSecs));
    }
}
