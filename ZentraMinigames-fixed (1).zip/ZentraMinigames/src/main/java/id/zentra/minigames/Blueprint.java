package id.zentra.minigames;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Collects a list of solid fills and then places them over several ticks so that
 * large arenas never freeze the server.
 */
public final class Blueprint {

    private record Fill(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        long volume() {
            return (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        }
    }

    private final List<Fill> fills = new ArrayList<>();

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        fills.add(new Fill(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), material));
    }

    public void set(int x, int y, int z, Material material) {
        fill(x, y, z, x, y, z, material);
    }

    /** Solid cone: widest disc at {@code y}, tapering downward {@code h} layers. */
    public void cone(int cx, int y, int cz, int r, int h, Material material) {
        for (int i = 0; i < h; i++) {
            int rr = Math.max(1, r * (h - i) / h);
            disc(cx, y - i, cz, rr, material);
        }
    }

    /** Ring between inner and outer radius (inclusive). inner &lt; 0 makes a full disc. */
    public void ring(int cx, int y, int cz, int inner, int outer, Material material) {
        int lo = inner < 0 ? -1 : inner * inner;
        int hi = outer * outer;
        for (int x = cx - outer; x <= cx + outer; x++) {
            for (int z = cz - outer; z <= cz + outer; z++) {
                int dx = x - cx;
                int dz = z - cz;
                int d2 = dx * dx + dz * dz;
                if (d2 <= hi && d2 >= lo) {
                    set(x, y, z, material);
                }
            }
        }
    }

    /** Hollow box: only the four walls between y1..y2 (no floor, no roof). */
    public void box(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        int ax = Math.min(x1, x2), bx = Math.max(x1, x2);
        int az = Math.min(z1, z2), bz = Math.max(z1, z2);
        fill(ax, y1, az, bx, y2, az, material);
        fill(ax, y1, bz, bx, y2, bz, material);
        fill(ax, y1, az, ax, y2, bz, material);
        fill(bx, y1, az, bx, y2, bz, material);
    }

    /** True when (dx,dz) lies between inner and outer radius (inner &lt; 0 means a full disc). */
    public static boolean inRing(int dx, int dz, int inner, int outer) {
        int d2 = dx * dx + dz * dz;
        int lo = inner < 0 ? -1 : inner * inner;
        return d2 <= outer * outer && d2 >= lo;
    }

    public void disc(int cx, int y, int cz, int r, Material material) {
        ring(cx, y, cz, -1, r, material);
    }

    public void cylinder(int cx, int y1, int y2, int cz, int r, Material material) {
        for (int y = y1; y <= y2; y++) {
            disc(cx, y, cz, r, material);
        }
    }

    public boolean isEmpty() {
        return fills.isEmpty();
    }

    /**
     * Places all fills, a few thousand blocks per tick.
     *
     * @param canStart    checked before each tick; when false the build pauses.
     * @param onComplete  called on the main thread once every block was placed.
     */
    public void build(JavaPlugin plugin, World world, int blocksPerTick, BooleanSupplier canStart, Runnable onComplete) {
        final List<Fill> list = new ArrayList<>(fills);
        final int perTick = Math.max(500, blocksPerTick);
        new BukkitRunnable() {
            int fillIndex = 0;
            long offset = 0;

            @Override
            public void run() {
                if (canStart != null && !canStart.getAsBoolean()) {
                    return;
                }
                int budget = perTick;
                while (budget > 0 && fillIndex < list.size()) {
                    Fill f = list.get(fillIndex);
                    long vol = f.volume();
                    if (offset >= vol) {
                        fillIndex++;
                        offset = 0;
                        continue;
                    }
                    int w = f.x2() - f.x1() + 1;
                    int d = f.z2() - f.z1() + 1;
                    int h = f.y2() - f.y1() + 1;
                    int lx = (int) (offset % w);
                    int lz = (int) ((offset / w) % d);
                    int ly = (int) (offset / ((long) w * d));
                    Block block = world.getBlockAt(f.x1() + lx, f.y1() + ly, f.z1() + lz);
                    if (block.getType() != f.material()) {
                        block.setType(f.material(), false);
                    }
                    offset++;
                    budget--;
                    if (ly >= h) {
                        offset = vol;
                    }
                }
                if (fillIndex >= list.size()) {
                    cancel();
                    if (onComplete != null) {
                        onComplete.run();
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
