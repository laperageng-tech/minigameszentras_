package id.zentra.minigames;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

/** Creates every arena, keeps track of who is where and builds all the menus. */
public final class GameManager {

    /** Inventory holder that marks one of our menus; {@code keys} maps slot -> action id. */
    public static final class MenuHolder implements InventoryHolder {
        public final Map<Integer, String> keys = new HashMap<>();
        private Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    public static final List<String> KEYS = List.of("sumo", "tnttag", "crumble", "colorrush", "pillars", "tinyhunt",
            "duel", "practice", "bridge", "skyparkour", "iceparkour", "netherparkour", "parkourrace");

    private static final Map<String, String> CATEGORY = Map.of(
            "sumo", "Battle", "tnttag", "Party", "crumble", "Lari", "colorrush", "Refleks",
            "pillars", "Survival", "tinyhunt", "Petak Umpet", "duel", "Duel 1v1", "practice", "PvP Bebas",
            "bridge", "Bridge");

    private final ZentraMinigames plugin;
    private World world;
    private final Map<String, List<Game>> games = new LinkedHashMap<>();
    private final Map<UUID, Game> inGame = new HashMap<>();
    private final Map<UUID, Integer> botPref = new HashMap<>();
    private final Map<UUID, UUID> invitations = new HashMap<>();
    private final Deque<Game> buildQueue = new ArrayDeque<>();
    private final Set<Game> needClear = new HashSet<>();
    private boolean busy;

    public GameManager(ZentraMinigames plugin) {
        this.plugin = plugin;
    }

    /* ------------------------------------------------------------------ */
    /* lifecycle                                                           */
    /* ------------------------------------------------------------------ */

    public void init(World w) {
        this.world = w;
        FileConfiguration c = plugin.getConfig();
        int ax = c.getInt("arena.x", 30000);
        int ay = c.getInt("arena.y", 150);
        int az = c.getInt("arena.z", 30000);
        int version = c.getInt("build-version", 4);
        int group = 0;
        for (String key : KEYS) {
            int idx = group++;
            if (!c.getBoolean("games." + key + ".enabled", true)) {
                continue;
            }
            int count = Math.max(1, c.getInt("games." + key + ".instances", key.equals("practice") ? 1 : 2));
            List<Game> list = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                Game game = create(key, i + 1, ax + idx * 400, ay, az + i * 400);
                if (game == null) {
                    continue;
                }
                list.add(game);
                game.activate();
                if (plugin.data().getInt("built." + game.id(), -1) == version) {
                    game.state = Game.State.WAITING;
                } else {
                    needClear.add(game);
                    buildQueue.add(game);
                }
            }
            if (!list.isEmpty()) {
                games.put(key, list);
            }
        }
        new BukkitRunnable() {
            @Override
            public void run() {
                pump();
            }
        }.runTaskTimer(plugin, 40L, 20L);
        plugin.getLogger().info("ZentraMinigames: " + games.size() + " jenis game dimuat, " + buildQueue.size() + " arena antre dibangun.");
    }

    /** Builds one arena at a time so the server never lags. */
    private int pumpTicks;

    private void pump() {
        if (world != null && ++pumpTicks % 10 == 0) {
            plugin.enforceWorld(world);
        }
        if (busy || buildQueue.isEmpty()) {
            return;
        }
        Game g = buildQueue.poll();
        busy = true;
        boolean clear = needClear.remove(g);
        plugin.getLogger().info("Membangun arena " + g.id() + (clear ? " (penuh)" : " (perbaikan)") + "...");
        g.build(clear, () -> {
            plugin.data().set("built." + g.id(), plugin.getConfig().getInt("build-version", 4));
            plugin.saveData();
            g.state = Game.State.WAITING;
            busy = false;
            plugin.getLogger().info("Arena " + g.id() + " siap.");
        });
    }

    public void shutdown() {
        for (List<Game> list : games.values()) {
            for (Game g : list) {
                g.shutdown();
            }
        }
        inGame.clear();
        buildQueue.clear();
    }

    private Game create(String key, int i, int x, int y, int z) {
        return switch (key) {
            case "sumo" -> new SumoGame(plugin, this, i, x, y, z);
            case "tnttag" -> new TntTagGame(plugin, this, i, x, y, z);
            case "crumble" -> new CrumbleRunGame(plugin, this, i, x, y, z);
            case "colorrush" -> new ColorRushGame(plugin, this, i, x, y, z);
            case "pillars" -> new PillarsGame(plugin, this, i, x, y, z);
            case "tinyhunt" -> new TinyHuntGame(plugin, this, i, x, y, z);
            case "duel" -> new DuelGame(plugin, this, i, x, y, z);
            case "practice" -> new PracticeGame(plugin, this, i, x, y, z);
            case "bridge" -> new BridgeGame(plugin, this, i, x, y, z);
            case "skyparkour" -> new ParkourGame(plugin, this, "skyparkour", "Sky Parkour", 0, i, x, y, z);
            case "iceparkour" -> new ParkourGame(plugin, this, "iceparkour", "Ice Parkour", 1, i, x, y, z);
            case "netherparkour" -> new ParkourGame(plugin, this, "netherparkour", "Nether Parkour", 2, i, x, y, z);
            case "parkourrace" -> new ParkourRaceGame(plugin, this, i, x, y, z);
            default -> null;
        };
    }

    /** Re-applies the arena blocks of one game (or "all"). Returns the number of arenas queued. */
    public int rebuild(String key) {
        int n = 0;
        for (Map.Entry<String, List<Game>> e : games.entrySet()) {
            if (!key.equalsIgnoreCase("all") && !e.getKey().equalsIgnoreCase(key)) {
                continue;
            }
            for (Game g : e.getValue()) {
                for (Player p : g.online()) {
                    leave(p);
                }
                g.state = Game.State.RESETTING;
                if (!buildQueue.contains(g)) {
                    buildQueue.add(g);
                }
                n++;
            }
        }
        return n;
    }

    /* ------------------------------------------------------------------ */
    /* lookup                                                              */
    /* ------------------------------------------------------------------ */

    public Game of(Player p) {
        return inGame.get(p.getUniqueId());
    }

    public void forget(UUID id) {
        inGame.remove(id);
    }

    public List<Game> list(String key) {
        return games.get(key.toLowerCase(java.util.Locale.ROOT));
    }

    public Set<String> keys() {
        return games.keySet();
    }

    public Game gameAt(Location loc) {
        for (List<Game> list : games.values()) {
            for (Game g : list) {
                if (Math.abs(loc.getX() - g.cx) < 140 && Math.abs(loc.getZ() - g.cz) < 140) {
                    return g;
                }
            }
        }
        return null;
    }

    public int setOpen(String key, boolean open) {
        int n = 0;
        for (Map.Entry<String, List<Game>> e : games.entrySet()) {
            if (!key.equalsIgnoreCase("all") && !e.getKey().equalsIgnoreCase(key)) {
                continue;
            }
            for (Game g : e.getValue()) {
                g.open = open;
                n++;
            }
        }
        return n;
    }

    /* ------------------------------------------------------------------ */
    /* join / leave                                                        */
    /* ------------------------------------------------------------------ */

    public void join(Player p, String key) {
        if (world == null) {
            Msg.send(p, "&cMinigames sedang disiapkan, coba lagi sebentar.");
            return;
        }
        if (inGame.containsKey(p.getUniqueId())) {
            Msg.send(p, "&cKamu sudah berada di dalam game. Pakai &f/zm leave &cuntuk keluar.");
            return;
        }
        key = key.toLowerCase(java.util.Locale.ROOT);
        if (key.equals("practice")) {
            openKitMenu(p);
            return;
        }
        List<Game> list = games.get(key);
        if (list == null) {
            Msg.send(p, "&cGame tidak ditemukan. Lihat &f/zm list");
            return;
        }
        Game best = null;
        boolean preparing = false;
        for (Game g : list) {
            if (g.state == Game.State.RESETTING) {
                preparing = true;
            }
            if (g.joinable() && (best == null || g.players.size() > best.players.size())) {
                best = g;
            }
        }
        if (best == null) {
            Msg.send(p, preparing ? "&eArena sedang disiapkan, coba lagi sebentar..." : "&cSemua arena sedang berjalan atau penuh.");
            return;
        }
        if (best.join(p)) {
            inGame.put(p.getUniqueId(), best);
        }
    }

    public boolean leave(Player p) {
        Game g = inGame.remove(p.getUniqueId());
        if (g == null) {
            return false;
        }
        g.leave(p);
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* practice bot preference                                             */
    /* ------------------------------------------------------------------ */

    public int botLevel(UUID id) {
        return botPref.getOrDefault(id, 0);
    }

    /** Sets the bot level (0 = off). Works at any time, also while inside Practice PvP. */
    public void setBot(Player p, int level) {
        botPref.put(p.getUniqueId(), Math.max(0, Math.min(3, level)));
        if (of(p) instanceof PracticeGame pg) {
            pg.applyBot(p);
        }
    }

    public int cycleBot(Player p) {
        int next = (botLevel(p.getUniqueId()) + 1) % 4;
        setBot(p, next);
        return next;
    }

    public static String botName(int level) {
        return switch (level) {
            case 1 -> "&aMudah";
            case 2 -> "&eSedang";
            case 3 -> "&cSulit";
            default -> "&7Mati";
        };
    }

    /* ------------------------------------------------------------------ */
    /* invitations                                                         */
    /* ------------------------------------------------------------------ */

    public void recordInvite(Player target, Player inviter) {
        invitations.put(target.getUniqueId(), inviter.getUniqueId());
    }

    public void invite(Player inviter, UUID targetId) {
        Game g = of(inviter);
        if (g == null) {
            Msg.send(inviter, "&cKamu tidak sedang berada di game.");
            return;
        }
        g.invite(inviter, Bukkit.getPlayer(targetId));
    }

    public void acceptInvite(Player p, UUID inviterId) {
        UUID expected = invitations.get(p.getUniqueId());
        if (expected == null || !expected.equals(inviterId)) {
            Msg.send(p, "&cUndangan tidak valid atau sudah kedaluwarsa.");
            return;
        }
        invitations.remove(p.getUniqueId());
        if (inGame.containsKey(p.getUniqueId())) {
            Msg.send(p, "&cKamu sudah berada di dalam game.");
            return;
        }
        Game g = inGame.get(inviterId);
        if (g == null || !g.joinable()) {
            Msg.send(p, "&cGame itu sudah penuh atau sudah berjalan.");
            return;
        }
        if (g.join(p)) {
            inGame.put(p.getUniqueId(), g);
        }
    }

    /* ------------------------------------------------------------------ */
    /* menu helpers                                                        */
    /* ------------------------------------------------------------------ */

    static String[] wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : text.split(" ")) {
            if (cur.length() + word.length() + 1 > width && cur.length() > 0) {
                lines.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) {
                cur.append(' ');
            }
            cur.append(word);
        }
        if (cur.length() > 0) {
            lines.add(cur.toString());
        }
        return lines.toArray(new String[0]);
    }

    static ItemStack named(ItemStack base, String name, List<String> lore, boolean glint) {
        ItemStack it = base.clone();
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.c(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(Msg.c(s));
        }
        meta.lore(l);
        meta.addItemFlags(ItemFlag.values());
        if (glint) {
            meta.setEnchantmentGlintOverride(true);
        }
        it.setItemMeta(meta);
        return it;
    }

    static ItemStack named(Material m, String name, List<String> lore, boolean glint) {
        return named(new ItemStack(m), name, lore, glint);
    }

    private static void frame(Inventory inv, int rows) {
        int size = rows * 9;
        for (int i = 0; i < size; i++) {
            int row = i / 9;
            int col = i % 9;
            boolean border = row == 0 || row == rows - 1 || col == 0 || col == 8;
            Material m = border
                    ? ((row + col) % 2 == 0 ? Material.BLACK_STAINED_GLASS_PANE : Material.CYAN_STAINED_GLASS_PANE)
                    : Material.GRAY_STAINED_GLASS_PANE;
            inv.setItem(i, named(m, " ", List.of(), false));
        }
    }

    private MenuHolder holder(String title, int rows) {
        MenuHolder h = new MenuHolder();
        h.inv = Bukkit.createInventory(h, rows * 9, Msg.c(title));
        frame(h.inv, rows);
        return h;
    }

    private static void put(MenuHolder h, int slot, ItemStack item, String key) {
        h.inv.setItem(slot, item);
        h.keys.put(slot, key);
    }

    private int countPlayers(List<Game> list) {
        int n = 0;
        for (Game g : list) {
            n += g.players.size();
        }
        return n;
    }

    /* ------------------------------------------------------------------ */
    /* menus                                                               */
    /* ------------------------------------------------------------------ */

    public void openMenu(Player p) {
        MenuHolder h = holder("&b&lZentra &3&lMinigames", 6);
        int total = 0;
        for (List<Game> l : games.values()) {
            total += countPlayers(l);
        }
        put(h, 4, named(Material.NETHER_STAR, "&b&lZENTRA MINIGAMES",
                List.of("&7Pilih game lalu klik untuk masuk.", "&7Klik kanan sebuah game untuk", "&7membaca aturan mainnya.", " ",
                        "&fSedang bermain: &a" + total), true), "_info");

        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int si = 0;
        for (Map.Entry<String, List<Game>> e : games.entrySet()) {
            String key = e.getKey();
            if (key.equals("practice") || key.endsWith("parkour") || key.equals("parkourrace")) {
                continue;
            }
            if (si >= slots.length) {
                break;
            }
            List<Game> list = e.getValue();
            Game g0 = list.get(0);
            int open = 0;
            for (Game g : list) {
                if (g.joinable()) {
                    open++;
                }
            }
            List<String> lore = new ArrayList<>();
            lore.add("&8" + CATEGORY.getOrDefault(key, "Minigame"));
            lore.add(" ");
            lore.add("&7Pemain: &f" + g0.min + "-" + g0.max);
            for (String line : wrap(g0.rules.isEmpty() ? "" : g0.rules.get(0), 34)) {
                lore.add("&7" + line);
            }
            lore.add(" ");
            lore.add("&fBermain sekarang: &a" + countPlayers(list));
            lore.add("&fArena tersedia: " + (open > 0 ? "&a" : "&c") + open + "&7/" + list.size());
            lore.add(" ");
            lore.add(open > 0 ? "&a&l\u25b6 Klik kiri untuk bermain" : "&c&l\u2716 Semua arena penuh/berjalan");
            lore.add("&e\u25b6 Klik kanan untuk aturan");
            put(h, slots[si++], named(g0.icon, "&b&l" + g0.name, lore, open > 0), key);
        }
        boolean hasParkour = games.containsKey("skyparkour") || games.containsKey("iceparkour")
                || games.containsKey("netherparkour") || games.containsKey("parkourrace");
        if (hasParkour && si < slots.length) {
            int pc = 0;
            for (String k : List.of("skyparkour", "iceparkour", "netherparkour", "parkourrace")) {
                if (games.containsKey(k)) {
                    pc += countPlayers(games.get(k));
                }
            }
            put(h, slots[si], named(Material.FEATHER, "&a&lParkour",
                    List.of("&8Lari", " ", "&7Solo: Sky, Ice dan Nether dengan", "&7mode Classic / Speedrun / Hardcore.",
                            "&7Atau balapan 1v1 melawan temanmu.", " ", "&fBermain sekarang: &a" + pc, " ",
                            "&a&l\u25b6 Klik untuk memilih"), true), "parkour:select");
        }
        if (games.containsKey("practice")) {
            List<String> lore = new ArrayList<>();
            lore.add("&8PvP Bebas");
            lore.add(" ");
            lore.add("&7Latihan PvP tanpa henti, respawn instan.");
            lore.add("&7Pilih kit, lawan pemain lain atau bot.");
            lore.add(" ");
            for (Kit k : Kit.values()) {
                lore.add("&8\u2022 " + k.color + k.display);
            }
            lore.add(" ");
            lore.add("&fBermain sekarang: &a" + countPlayers(games.get("practice")));
            lore.add(" ");
            lore.add("&a&l\u25b6 Klik untuk memilih kit");
            put(h, 40, named(Material.END_CRYSTAL, "&d&lPractice PvP", lore, true), "practice");
        }
        put(h, 38, named(Material.BOOK, "&e&lCara Bermain",
                List.of("&7Masuk game, tunggu pemain cukup,", "&7hitung mundur lalu bertanding.", " ",
                        "&7Item di hotbar saat menunggu:", "&8\u2022 &fBuku &7= aturan", "&8\u2022 &fLonceng &7= undang pemain",
                        "&8\u2022 &fPewarna merah &7= keluar"), false), "_info");
        if (of(p) != null) {
            put(h, 49, named(Material.BARRIER, "&c&lKeluar dari game", List.of("&7Kembali ke tempat semula."), false), "_leave");
        }
        p.openInventory(h.inv);
    }

    public void openParkourSelect(Player p) {
        MenuHolder h = holder("&b&lParkour &8\u00bb &fPilih permainan", 3);
        put(h, 11, named(Material.FEATHER, "&a&lSolo", List.of("&7Pilih map dan mode,", "&7kejar waktu terbaikmu."), false), "parkour:maps");
        put(h, 15, named(Material.CLOCK, "&e&lBalapan 1v1", List.of("&7Lawan satu pemain,", "&7yang sampai finish duluan menang."), false), "parkour:race");
        put(h, 22, named(Material.ARROW, "&7Kembali", List.of(), false), "_back");
        p.openInventory(h.inv);
    }

    public void openRaceVote(Player p, ParkourRaceGame race) {
        if (!race.canVote(p)) {
            return;
        }
        MenuHolder h = holder("&b&lParkour 1v1 &8\u00bb &fVote", 3);
        String[] maps = {"Sky", "Ice", "Nether"};
        Material[] mapIcons = {Material.FEATHER, Material.ICE, Material.BLAZE_POWDER};
        for (int i = 0; i < maps.length; i++) {
            put(h, 10 + i, named(mapIcons[i], "&b&lMap: " + maps[i],
                    List.of("&7Suara: &f" + race.mapVotes(maps[i]), " ", "&a\u25b6 Klik untuk vote"), race.mapVotes(maps[i]) > 0),
                    "race:map:" + maps[i]);
        }
        String[] modes = {"CLASSIC", "SPEEDRUN", "HARDCORE"};
        for (int i = 0; i < modes.length; i++) {
            put(h, 14 + i, named(Material.CLOCK, "&e&lMode: " + modes[i],
                    List.of("&7Suara: &f" + race.modeVotes(modes[i]), " ", "&a\u25b6 Klik untuk vote"), race.modeVotes(modes[i]) > 0),
                    "race:mode:" + modes[i]);
        }
        p.openInventory(h.inv);
    }

    public void openParkourMaps(Player p) {
        MenuHolder h = holder("&b&lParkour &8\u00bb &fPilih map", 3);
        String[][] maps = {{"skyparkour", "Sky Parkour"}, {"iceparkour", "Ice Parkour"}, {"netherparkour", "Nether Parkour"}};
        Material[] icons = {Material.FEATHER, Material.ICE, Material.BLAZE_POWDER};
        int[] slots = {11, 13, 15};
        for (int i = 0; i < maps.length; i++) {
            List<Game> list = games.get(maps[i][0]);
            if (list == null) {
                continue;
            }
            put(h, slots[i], named(icons[i], "&b&l" + maps[i][1],
                    List.of("&7Bermain sekarang: &a" + countPlayers(list), " ", "&a\u25b6 Klik untuk memilih mode"), false),
                    "parkour:map:" + maps[i][0]);
        }
        put(h, 22, named(Material.ARROW, "&7Kembali", List.of(), false), "_back");
        p.openInventory(h.inv);
    }

    public void openParkourModes(Player p, String key) {
        MenuHolder h = holder("&b&lParkour &8\u00bb &fPilih mode", 3);
        put(h, 11, named(Material.LIME_DYE, "&a&lCLASSIC", List.of("&7Ada checkpoint.", "&7Jatuh kembali ke checkpoint terakhir."), false),
                "parkour:play:" + key + ":CLASSIC");
        put(h, 13, named(Material.CLOCK, "&e&lSPEEDRUN", List.of("&7Tanpa checkpoint, waktu terus jalan.", "&7Jatuh kembali ke awal."), false),
                "parkour:play:" + key + ":SPEEDRUN");
        put(h, 15, named(Material.BLAZE_POWDER, "&c&lHARDCORE", List.of("&7Jatuh = lintasan dan waktu diulang."), false),
                "parkour:play:" + key + ":HARDCORE");
        put(h, 22, named(Material.ARROW, "&7Kembali", List.of(), false), "parkour:maps");
        p.openInventory(h.inv);
    }

    public void joinParkour(Player p, String key, ParkourGame.Mode mode) {
        if (inGame.containsKey(p.getUniqueId())) {
            Msg.send(p, "&cKamu sudah berada di dalam game.");
            return;
        }
        List<Game> list = games.get(key);
        if (list == null) {
            Msg.send(p, "&cMap tidak ditemukan.");
            return;
        }
        for (Game g : list) {
            if (g instanceof ParkourGame pg && pg.joinable() && pg.joinWith(p, mode)) {
                inGame.put(p.getUniqueId(), pg);
                return;
            }
        }
        Msg.send(p, "&eMap sedang disiapkan atau penuh, coba lagi sebentar.");
    }

    public void openInvites(Player p, int page) {
        Game g = of(p);
        if (g == null || !g.joinable()) {
            Msg.send(p, "&cGame ini tidak bisa menerima undangan sekarang.");
            return;
        }
        List<Player> targets = new ArrayList<>();
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (!t.equals(p) && !inGame.containsKey(t.getUniqueId())) {
                targets.add(t);
            }
        }
        targets.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int pages = Math.max(1, (targets.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        MenuHolder h = holder("&b&lUndang Pemain &8(" + (page + 1) + "/" + pages + ")", 6);
        for (int i = 0; i < 45; i++) {
            h.inv.setItem(i, null);
        }
        for (int i = 0; i < 45 && page * 45 + i < targets.size(); i++) {
            Player t = targets.get(page * 45 + i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(t);
            meta.displayName(Msg.c("&e" + t.getName()));
            meta.lore(List.of(Msg.c("&a\u25b6 Klik untuk mengundang")));
            head.setItemMeta(meta);
            h.inv.setItem(i, head);
            h.keys.put(i, "invite:" + t.getUniqueId());
        }
        if (targets.isEmpty()) {
            h.inv.setItem(22, named(Material.BARRIER, "&cTidak ada pemain lain online", List.of(), false));
        }
        if (page > 0) {
            put(h, 45, named(Material.ARROW, "&7Halaman sebelumnya", List.of(), false), "invitepage:" + (page - 1));
        }
        if (page < pages - 1) {
            put(h, 53, named(Material.ARROW, "&7Halaman berikutnya", List.of(), false), "invitepage:" + (page + 1));
        }
        p.openInventory(h.inv);
    }

    public void openDuelVote(Player p, DuelGame duel) {
        MenuHolder h = holder("&b&lDuel &8\u00bb &fVote Kit", 3);
        Kit[] kits = {Kit.SWORD, Kit.MACE, Kit.NODEBUFF, Kit.CRYSTAL};
        int[] slots = {10, 12, 14, 16};
        for (int i = 0; i < kits.length; i++) {
            put(h, slots[i], named(kits[i].icon(), kits[i].label(),
                    List.of("&7Suara: &f" + duel.votesFor(kits[i]), " ", "&a\u25b6 Klik untuk vote"), duel.votesFor(kits[i]) > 0),
                    "vote:" + kits[i].name());
        }
        p.openInventory(h.inv);
    }

    public void openKitMenu(Player p) {
        if (!games.containsKey("practice")) {
            Msg.send(p, "&cPractice PvP tidak aktif.");
            return;
        }
        MenuHolder h = holder("&d&lPractice PvP &8\u00bb &fPilih Kit", 3);
        int level = botLevel(p.getUniqueId());
        put(h, 4, named(Material.NETHER_STAR, "&d&lPractice PvP",
                List.of("&7Pilih kit untuk masuk.", "&7Bot lawan: " + botName(level)), false), "_info");
        int[] slots = {10, 12, 14, 16};
        Kit[] kits = Kit.values();
        for (int i = 0; i < kits.length && i < slots.length; i++) {
            put(h, slots[i], named(kits[i].icon(), kits[i].label(), List.of("&a\u25b6 Klik untuk memakai kit ini"), false),
                    "kit:" + kits[i].name());
        }
        put(h, 22, named(Material.ZOMBIE_HEAD, "&c&lBot Lawan: " + botName(level),
                List.of("&7Bot menyerangmu di arena yang sama.", "&7Klik untuk ganti tingkat:", "&8Mati \u2192 Mudah \u2192 Sedang \u2192 Sulit",
                        " ", "&7Bisa diganti kapan saja, juga saat bermain."), level > 0), "_bot");
        put(h, 20, named(Material.ARROW, "&7Kembali", List.of(), false), "_back");
        if (level > 0) {
            put(h, 24, named(Material.RED_DYE, "&c&lKeluar dari Mode Bot",
                    List.of("&7Matikan bot lawan dan", "&7kembali ke arena global.", " ", "&a\u25b6 Klik untuk keluar"), false), "_botoff");
        }
        p.openInventory(h.inv);
    }

    public void pickKit(Player p, Kit kit) {
        Game cur = of(p);
        if (cur instanceof PracticeGame pg) {
            pg.changeKit(p, kit);
            return;
        }
        if (cur != null) {
            Msg.send(p, "&cKeluar dulu dari game yang sedang kamu mainkan.");
            return;
        }
        List<Game> list = games.get("practice");
        if (list == null) {
            return;
        }
        for (Game g : list) {
            if (g instanceof PracticeGame pg && pg.joinable() && pg.joinWith(p, kit)) {
                inGame.put(p.getUniqueId(), pg);
                return;
            }
        }
        Msg.send(p, "&eArena Practice sedang disiapkan atau penuh.");
    }

    public void showRules(Player p, String key) {
        List<Game> list = list(key);
        if (list != null && !list.isEmpty()) {
            Msg.raw(p, "&b&l" + list.get(0).name);
            list.get(0).showRules(p);
        }
    }
}
