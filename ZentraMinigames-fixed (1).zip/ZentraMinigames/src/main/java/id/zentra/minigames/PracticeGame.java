package id.zentra.minigames;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Husk;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Practice PvP: arena terbuka tanpa henti, pilih kit, respawn instan.
 * Bot lawan (Husk) muncul di arena yang sama dan bisa diaktifkan/dimatikan kapan saja lewat menu atau /zm bot.
 */
public final class PracticeGame extends Game {

    private static final double[] BOT_HP = {0, 20, 30, 40};
    private static final double[] BOT_DMG = {0, 4, 7, 10};
    private static final double[] BOT_SPEED = {0, 0.21, 0.26, 0.30};

    private final Map<UUID, Kit> kits = new HashMap<>();
    private final Map<UUID, int[]> stats = new HashMap<>(); // 0 kill, 1 mati, 2 streak, 3 streak terbaik
    private final Map<UUID, Long> shield = new HashMap<>();
    private final Map<UUID, Husk> bots = new HashMap<>();
    private final Map<Block, Long> expiry = new HashMap<>();
    private final Map<Block, BlockData> ground = new HashMap<>();
    private long restoreAt;

    public PracticeGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "practice", "Practice PvP", Material.END_CRYSTAL, instance, cx, by, cz, 1,
                Math.max(2, plugin.getConfig().getInt("games.practice.max", 40)), List.of(
                        "Arena PvP bebas tanpa henti: pilih kit, bertarung, mati langsung respawn.",
                        "Kit: Crystal PvP, Mace, Sword, NoDebuff. Ganti kit kapan saja dengan Bintang di hotbar.",
                        "Aktifkan Bot Lawan lewat menu atau /zm bot; tombol Keluar Mode Bot di menu kit mematikan bot dan kembali ke arena global.",
                        "Blok yang kamu pasang hilang sendiri setelah 20 detik. Lantai yang rusak karena crystal dipulihkan."));
        this.continuous = true;
        this.voidY = by - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
    }

    /* ---------------- arena ---------------- */

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 16, cz, 38, 14, Material.BLACKSTONE);
        bp.disc(cx, by, cz, 36, Material.DEEPSLATE_TILES);
        bp.ring(cx, by, cz, 24, 25, Material.POLISHED_BLACKSTONE_BRICKS);
        bp.ring(cx, by, cz, 35, 36, Material.GILDED_BLACKSTONE);
        bp.disc(cx, by, cz, 4, Material.CRYING_OBSIDIAN);
        for (int[] d : new int[][]{{20, 0}, {-20, 0}, {0, 20}, {0, -20}}) {
            bp.fill(cx + d[0] - 1, by + 1, cz + d[1] - 1, cx + d[0] + 1, by + 3, cz + d[1] + 1, Material.BLACKSTONE);
        }
        for (int[] d : new int[][]{{30, 0}, {-30, 0}, {0, 30}, {0, -30}, {21, 21}, {-21, 21}, {21, -21}, {-21, -21}}) {
            bp.fill(cx + d[0], by + 1, cz + d[1], cx + d[0], by + 8, cz + d[1], Material.CRYING_OBSIDIAN);
            bp.set(cx + d[0], by + 9, cz + d[1], Material.SEA_LANTERN);
        }
    }

    @Override
    protected boolean hasLobby() {
        return false;
    }

    @Override
    public Location specSpawn() {
        return randomSpawn();
    }

    private Location randomSpawn() {
        double a = rnd.nextDouble() * Math.PI * 2;
        double r = 8 + rnd.nextDouble() * 20;
        Location l = new Location(world, cx + 0.5 + Math.cos(a) * r, by + 1, cz + 0.5 + Math.sin(a) * r);
        l.setYaw(rnd.nextFloat() * 360f);
        return l;
    }

    /* ---------------- join / kit ---------------- */

    @Override
    public boolean joinable() {
        return open && (state == State.WAITING || state == State.RUNNING) && players.size() < max;
    }

    @Override
    public void forceStart() {
    }

    @Override
    protected void checkWin() {
    }

    @Override
    protected void onStart() {
    }

    @Override
    public boolean join(Player player) {
        return joinWith(player, Kit.SWORD);
    }

    public boolean joinWith(Player p, Kit kit) {
        UUID id = p.getUniqueId();
        if (!joinable() || players.contains(id)) {
            return false;
        }
        if (state == State.WAITING) {
            state = State.RUNNING;
            runSecs = 0;
        }
        saved.put(id, snapshot(p));
        players.add(id);
        alive.add(id);
        kits.put(id, kit);
        stats.put(id, new int[4]);
        p.leaveVehicle();
        bar.addPlayer(p);
        plugin.sidebar(p, this);
        spawnWithKit(p);
        Msg.send(p, "&aKamu masuk Practice PvP dengan kit " + kit.label() + "&a. Ganti kit dengan Bintang di hotbar.");
        return true;
    }

    public void changeKit(Player p, Kit kit) {
        if (!players.contains(p.getUniqueId())) {
            return;
        }
        kits.put(p.getUniqueId(), kit);
        spawnWithKit(p);
        Msg.send(p, "&aKit diganti: " + kit.label());
    }

    private void spawnWithKit(Player p) {
        UUID id = p.getUniqueId();
        resetPlayer(p, GameMode.SURVIVAL);
        Kit kit = kits.getOrDefault(id, Kit.SWORD);
        kit.give(p);
        giveActionItem(p);
        p.getInventory().setItem(8, plugin.leaveItem());
        p.getInventory().setHeldItemSlot(0);
        p.teleport(randomSpawn());
        int secs = plugin.getConfig().getInt("games.practice.respawn-protection", 3);
        shield.put(id, System.currentTimeMillis() + secs * 1000L);
        Msg.bar(p, "&bPerlindungan respawn " + secs + "s");
        respawnBot(p);
    }

    private void giveActionItem(Player p) {
        p.getInventory().setItem(7, plugin.lobbyItem(Material.NETHER_STAR, "&d&lGanti Kit", "kit",
                "&7Klik kanan: pilih kit &8/ &7keluar dari mode bot"));
    }

    @Override
    public void lobbyAction(Player player, String action) {
        if (action.equals("kit")) {
            manager.openKitMenu(player);
        } else {
            super.lobbyAction(player, action);
        }
    }

    /* ---------------- bot ---------------- */

    /** Dipanggil saat tingkat bot diubah; menghidupkan/mematikan bot di arena yang sama. */
    public void applyBot(Player p) {
        if (!players.contains(p.getUniqueId())) {
            return;
        }
        respawnBot(p);
        giveActionItem(p);
        int level = manager.botLevel(p.getUniqueId());
        Msg.bar(p, "&7Bot lawan: " + GameManager.botName(level));
    }

    private void removeBot(UUID id) {
        Husk old = bots.remove(id);
        if (old != null && !old.isDead()) {
            old.remove();
        }
    }

    private static void setAttr(LivingEntity e, Attribute attr, double value) {
        AttributeInstance inst = e.getAttribute(attr);
        if (inst != null) {
            inst.setBaseValue(value);
        }
    }

    private Location botSpawn(Player p) {
        double a = rnd.nextDouble() * Math.PI * 2;
        double x = p.getLocation().getX() + Math.cos(a) * 9;
        double z = p.getLocation().getZ() + Math.sin(a) * 9;
        double dx = x - (cx + 0.5);
        double dz = z - (cz + 0.5);
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 30) {
            x = cx + 0.5 + dx / d * 30;
            z = cz + 0.5 + dz / d * 30;
        }
        return new Location(world, x, by + 1, z);
    }

    private void respawnBot(Player p) {
        UUID id = p.getUniqueId();
        removeBot(id);
        int level = manager.botLevel(id);
        if (level <= 0 || !players.contains(id) || !p.isOnline()) {
            return;
        }
        if (world.getDifficulty() == Difficulty.PEACEFUL) {
            Msg.send(p, "&cBot tidak bisa muncul karena difficulty Peaceful.");
            return;
        }
        Kit kit = kits.getOrDefault(id, Kit.SWORD);
        boolean netherite = kit == Kit.CRYSTAL || kit == Kit.MACE;
        Husk bot = world.spawn(botSpawn(p), Husk.class, h -> {
            h.setBaby(false);
            h.setPersistent(false);
            h.setCanPickupItems(false);
            h.setRemoveWhenFarAway(false);
            h.customName(Msg.c("&c&lBot &7[" + kit.display + "] " + GameManager.botName(level)));
            h.setCustomNameVisible(true);
            setAttr(h, Attribute.MAX_HEALTH, BOT_HP[level]);
            h.setHealth(BOT_HP[level]);
            setAttr(h, Attribute.ATTACK_DAMAGE, BOT_DMG[level]);
            setAttr(h, Attribute.MOVEMENT_SPEED, BOT_SPEED[level]);
            setAttr(h, Attribute.FOLLOW_RANGE, 48);
            setAttr(h, Attribute.SPAWN_REINFORCEMENTS, 0);
            EntityEquipment eq = h.getEquipment();
            if (eq != null) {
                eq.setHelmet(new ItemStack(netherite ? Material.NETHERITE_HELMET : Material.DIAMOND_HELMET));
                eq.setChestplate(new ItemStack(netherite ? Material.NETHERITE_CHESTPLATE : Material.DIAMOND_CHESTPLATE));
                eq.setLeggings(new ItemStack(netherite ? Material.NETHERITE_LEGGINGS : Material.DIAMOND_LEGGINGS));
                eq.setBoots(new ItemStack(netherite ? Material.NETHERITE_BOOTS : Material.DIAMOND_BOOTS));
                Material weapon = kit == Kit.MACE ? Material.MACE : (kit == Kit.CRYSTAL ? Material.NETHERITE_SWORD : Material.DIAMOND_SWORD);
                eq.setItemInMainHand(new ItemStack(weapon));
                for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                        EquipmentSlot.FEET, EquipmentSlot.HAND}) {
                    eq.setDropChance(s, 0f);
                }
            }
            h.setTarget(p);
        });
        bots.put(id, bot);
    }

    private UUID ownerOf(Entity ent) {
        for (Map.Entry<UUID, Husk> e : bots.entrySet()) {
            if (e.getValue().equals(ent)) {
                return e.getKey();
            }
        }
        return null;
    }

    /** Bot hanya boleh menargetkan pemiliknya. */
    public boolean allowTarget(Entity mob, LivingEntity target) {
        UUID owner = ownerOf(mob);
        return owner != null && target != null && target.getUniqueId().equals(owner);
    }

    public void onBotDeath(EntityDeathEvent e) {
        UUID owner = ownerOf(e.getEntity());
        if (owner == null) {
            return;
        }
        e.getDrops().clear();
        e.setDroppedExp(0);
        bots.remove(owner);
        Player p = Bukkit.getPlayer(owner);
        if (p != null && players.contains(owner)) {
            int[] s = stats.computeIfAbsent(owner, k -> new int[4]);
            s[0]++;
            s[2]++;
            s[3] = Math.max(s[3], s[2]);
            AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
            p.setHealth(mh == null ? 20.0 : mh.getValue());
            Msg.bar(p, "&aBot dikalahkan! &7Bot baru muncul sebentar lagi.");
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Player again = Bukkit.getPlayer(owner);
                if (again != null && players.contains(owner)) {
                    respawnBot(again);
                }
            }, 40L);
        }
    }

    /* ---------------- damage ---------------- */

    @Override
    public void onDamage(EntityDamageEvent e, Player victim, Player attacker) {
        UUID vid = victim.getUniqueId();
        if (state != State.RUNNING || !alive.contains(vid)) {
            e.setCancelled(true);
            return;
        }
        UUID botOwner = null;
        if (e instanceof EntityDamageByEntityEvent ev) {
            botOwner = ownerOf(ev.getDamager());
        }
        if (botOwner != null && !botOwner.equals(vid)) {
            e.setCancelled(true);
            return;
        }
        if (System.currentTimeMillis() < shield.getOrDefault(vid, 0L)) {
            e.setCancelled(true);
            return;
        }
        if (attacker != null && !attacker.equals(victim)) {
            shield.remove(attacker.getUniqueId());
        }
        if (botOwner != null) {
            if (victim.getHealth() - e.getFinalDamage() <= 0 && !hasTotem(victim)) {
                e.setCancelled(true);
                onOut(victim, null, "dikalahkan bot");
            }
            return;
        }
        super.onDamage(e, victim, attacker);
    }

    @Override
    protected void onOut(Player victim, Player killer, String reason) {
        UUID vid = victim.getUniqueId();
        int[] sv = stats.computeIfAbsent(vid, k -> new int[4]);
        sv[1]++;
        int lost = sv[2];
        sv[2] = 0;
        if (killer != null && !killer.equals(victim) && players.contains(killer.getUniqueId())) {
            UUID kid = killer.getUniqueId();
            int[] sk = stats.computeIfAbsent(kid, k -> new int[4]);
            sk[0]++;
            sk[2]++;
            sk[3] = Math.max(sk[3], sk[2]);
            AttributeInstance mh = killer.getAttribute(Attribute.MAX_HEALTH);
            killer.setHealth(mh == null ? 20.0 : mh.getValue());
            Msg.send(killer, "&aKamu mengalahkan &f" + victim.getName() + " &7(streak &e" + sk[2] + "&7)");
            Msg.send(victim, "&cKamu dikalahkan oleh &f" + killer.getName()
                    + (lost >= 3 ? " &7(streak " + lost + " putus)" : ""));
        } else {
            Msg.send(victim, "&cKamu " + reason + ".");
        }
        spawnWithKit(victim);
    }

    /* ---------------- blocks ---------------- */

    @Override
    public boolean allowPlace(Block b, Player p) {
        if (state != State.RUNNING) {
            return false;
        }
        if (b.getY() < by - 20 || b.getY() > by + 60 || Math.abs(b.getX() - cx) > 60 || Math.abs(b.getZ() - cz) > 60) {
            return false;
        }
        expiry.put(b, System.currentTimeMillis() + 20000L);
        return true;
    }

    @Override
    public boolean allowBreak(Block b, Player p) {
        return state == State.RUNNING && expiry.remove(b) != null;
    }

    @Override
    public void onExplode(EntityExplodeEvent e) {
        List<Block> list = new ArrayList<>(e.blockList());
        e.blockList().clear();
        boolean crystal = e.getEntity() instanceof EnderCrystal;
        Location c = e.getLocation();
        long now = System.currentTimeMillis();
        for (Block b : list) {
            if (expiry.remove(b) != null) {
                b.setType(Material.AIR, false);
                continue;
            }
            if (!crystal || b.getType().isAir()) {
                continue;
            }
            double dx = b.getX() + 0.5 - c.getX();
            double dy = b.getY() + 0.5 - c.getY();
            double dz = b.getZ() + 0.5 - c.getZ();
            double ox = b.getX() - cx;
            double oz = b.getZ() - cz;
            if (dx * dx + dy * dy + dz * dz <= 25.0 && b.getY() <= by && b.getY() >= by - 3 && ox * ox + oz * oz < 37.0 * 37.0) {
                ground.putIfAbsent(b, b.getBlockData());
                b.setType(Material.AIR, false);
                restoreAt = now + 10000L;
            }
        }
    }

    private void restoreGround() {
        for (Map.Entry<Block, BlockData> en : ground.entrySet()) {
            en.getKey().setBlockData(en.getValue(), false);
        }
        ground.clear();
    }

    /* ---------------- loop ---------------- */

    @Override
    protected void onSecond() {
        long now = System.currentTimeMillis();
        if (!ground.isEmpty() && now >= restoreAt) {
            restoreGround();
        }
        Iterator<Map.Entry<Block, Long>> it = expiry.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Block, Long> en = it.next();
            if (now >= en.getValue()) {
                en.getKey().setType(Material.AIR, false);
                it.remove();
            }
        }
        for (Map.Entry<UUID, Husk> en : bots.entrySet()) {
            Player owner = Bukkit.getPlayer(en.getKey());
            Husk bot = en.getValue();
            if (owner != null && bot.isValid() && bot.getTarget() == null) {
                bot.setTarget(owner);
            }
        }
        if (!players.isEmpty()) {
            Location center = new Location(world, cx + 0.5, by + 5, cz + 0.5);
            for (Entity en : world.getNearbyEntities(center, 40, 30, 40)) {
                if ((en instanceof Item || en instanceof EnderCrystal) && en.getTicksLived() > 1200) {
                    en.remove();
                }
            }
        }
    }

    /* ---------------- leave / reset ---------------- */

    @Override
    protected void onLeave(Player p) {
        UUID id = p.getUniqueId();
        kits.remove(id);
        stats.remove(id);
        shield.remove(id);
        removeBot(id);
        manager.setBot(p, 0); // keluar lalu masuk lagi = langsung arena global tanpa bot
    }

    @Override
    protected void onReset() {
        restoreGround();
        expiry.clear();
        for (UUID id : new ArrayList<>(bots.keySet())) {
            removeBot(id);
        }
    }

    @Override
    public void shutdown() {
        restoreGround();
        for (UUID id : new ArrayList<>(bots.keySet())) {
            removeBot(id);
        }
        for (Block b : new ArrayList<>(expiry.keySet())) {
            b.setType(Material.AIR, false);
        }
        expiry.clear();
        super.shutdown();
    }

    @Override
    protected String barText() {
        return "&dPractice PvP &8| &fPemain: &a" + players.size() + " &8| &7/zm leave untuk keluar";
    }

    @Override
    public List<String> sidebarLines(Player player) {
        UUID id = player.getUniqueId();
        int[] s = stats.getOrDefault(id, new int[4]);
        double kd = s[1] == 0 ? s[0] : s[0] / (double) s[1];
        Kit kit = kits.getOrDefault(id, Kit.SWORD);
        return List.of("&8" + id(), " ",
                "&fKit &8\u00bb " + kit.label(),
                "&fKill &8\u00bb &a" + s[0] + " &8| &fMati &8\u00bb &c" + s[1],
                "&fK/D &8\u00bb &e" + String.format(Locale.US, "%.2f", kd),
                "&fStreak &8\u00bb &6" + s[2] + " &8(&7terbaik " + s[3] + "&8)",
                "&fBot &8\u00bb " + GameManager.botName(manager.botLevel(id)),
                "&fPemain &8\u00bb &a" + players.size(),
                " ", "&b/zm leave &7= keluar");
    }
}
