package id.zentra.minigames;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Duel 1v1 dengan vote kit. */
public final class DuelGame extends Game {

    private static final Kit[] KITS = {Kit.SWORD, Kit.MACE, Kit.NODEBUFF, Kit.CRYSTAL};

    private final Map<UUID, Kit> kitVotes = new HashMap<>();
    private Kit current = Kit.SWORD;

    public DuelGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "duel", "Arena Duel", Material.DIAMOND_SWORD, instance, cx, by, cz, 2, 2, List.of(
                "Duel 1v1: kalahkan lawan sampai habis nyawa.",
                "Di ruang tunggu, klik item Vote Kit untuk memilih kit (Sword, Mace, NoDebuff, Crystal).",
                "Kit dengan suara terbanyak dipakai; jika seri dipilih acak.",
                "Kamu boleh memasang blok (obsidian/crystal untuk kit Crystal). Blok dibersihkan setelah ronde."));
        this.voidY = by - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 14, cz, 17, 12, Material.BLACKSTONE);
        bp.disc(cx, by, cz, 16, Material.DEEPSLATE_TILES);
        bp.ring(cx, by, cz, 14, 15, Material.POLISHED_BLACKSTONE_BRICKS);
        bp.ring(cx, by, cz, 15, 16, Material.GILDED_BLACKSTONE);
        bp.disc(cx, by, cz, 2, Material.CRYING_OBSIDIAN);
        for (int sx : new int[]{-7, 7}) {
            bp.fill(cx + sx, by + 1, cz - 2, cx + sx, by + 3, cz + 2, Material.BLACKSTONE);
        }
        for (int sz : new int[]{-8, 8}) {
            bp.fill(cx - 1, by + 1, cz + sz, cx + 1, by + 2, cz + sz, Material.POLISHED_BLACKSTONE_BRICKS);
        }
        for (int sx : new int[]{-13, 13}) {
            for (int sz : new int[]{-13, 13}) {
                bp.fill(cx + sx, by + 1, cz + sz, cx + sx, by + 5, cz + sz, Material.CRYING_OBSIDIAN);
                bp.set(cx + sx, by + 6, cz + sz, Material.SEA_LANTERN);
            }
        }
    }

    @Override
    protected void giveLobbyItems(Player player) {
        super.giveLobbyItems(player);
        player.getInventory().setItem(4, plugin.lobbyItem(Material.CLOCK, "&a&lVote Kit", "vote", "&7Klik kanan untuk memilih kit"));
    }

    @Override
    public void lobbyAction(Player player, String action) {
        if (action.equals("vote")) {
            manager.openDuelVote(player, this);
        } else {
            super.lobbyAction(player, action);
        }
    }

    public void voteKit(Player p, Kit kit) {
        if (!players.contains(p.getUniqueId()) || (state != State.WAITING && state != State.COUNTDOWN)) {
            return;
        }
        kitVotes.put(p.getUniqueId(), kit);
        Msg.send(p, "&aVote kit: " + kit.label());
    }

    public int votesFor(Kit kit) {
        int n = 0;
        for (Kit k : kitVotes.values()) {
            if (k == kit) {
                n++;
            }
        }
        return n;
    }

    public void clearVote(UUID id) {
        kitVotes.remove(id);
    }

    @Override
    protected void onLeave(Player player) {
        kitVotes.remove(player.getUniqueId());
    }

    @Override
    public void forceStart() {
        if (players.size() >= 2) {
            super.forceStart();
        }
    }

    @Override
    protected void onStart() {
        kitVotes.keySet().retainAll(players);
        Map<Kit, Integer> count = new EnumMap<>(Kit.class);
        for (Kit k : kitVotes.values()) {
            count.merge(k, 1, Integer::sum);
        }
        int best = 0;
        List<Kit> top = new ArrayList<>();
        for (Kit k : KITS) {
            int c = count.getOrDefault(k, 0);
            if (c > best) {
                best = c;
                top.clear();
            }
            if (c == best && c > 0) {
                top.add(k);
            }
        }
        current = top.isEmpty() ? Kit.SWORD : top.get(rnd.nextInt(top.size()));
        kitVotes.clear();
        List<Player> list = alivePlayers();
        spreadRing(list, 11.0, by + 1);
        for (Player p : list) {
            p.closeInventory();
            current.give(p);
            p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 9, false, false));
            Msg.title(p, "&c&lDUEL", current.label(), 5, 40, 10);
        }
        bc("&eKit: " + current.label());
    }

    @Override
    protected void onReset() {
        kitVotes.clear();
    }

    @Override
    protected String barText() {
        return "&cArena Duel &8| &fKit: " + current.label();
    }

    @Override
    protected List<String> sideExtra() {
        List<String> l = new ArrayList<>();
        if (state == State.RUNNING) {
            l.add("&fKit &8\u00bb " + current.label());
        } else {
            l.add("&fVote kit &8\u00bb &7item Jam");
        }
        return l;
    }

    @SuppressWarnings("unused")
    private static ItemStack unused() {
        return null;
    }
}
