package id.zentra.minigames;

import java.time.Duration;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

/** Small helper for coloured (legacy &-code) messages, titles and action bars. */
public final class Msg {

    public static final String PREFIX = "&8[&bZentra&3Minigames&8] &7";

    private static final LegacyComponentSerializer SER = LegacyComponentSerializer.legacyAmpersand();

    private Msg() {
    }

    public static Component c(String text) {
        return SER.deserialize(text == null ? "" : text).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(Player player, String text) {
        player.sendMessage(c(PREFIX + text));
    }

    public static void raw(Player player, String text) {
        player.sendMessage(c(text));
    }

    public static void title(Player player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        player.showTitle(Title.title(
                c(title),
                c(subtitle),
                Title.Times.times(
                        Duration.ofMillis(fadeIn * 50L),
                        Duration.ofMillis(stay * 50L),
                        Duration.ofMillis(fadeOut * 50L))));
    }

    public static void bar(Player player, String text) {
        player.sendActionBar(c(text));
    }

    public static String line() {
        return "&8&m" + " ".repeat(40);
    }
}
