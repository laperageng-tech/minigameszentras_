package id.zentra.minigames;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class MinigamesCommand implements CommandExecutor, TabCompleter {

    private final ZentraMinigames plugin;
    private final GameManager mgr;

    public MinigamesCommand(ZentraMinigames plugin, GameManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    private static boolean admin(CommandSender s) {
        return s.hasPermission("zentra.minigames.admin");
    }

    private static void say(CommandSender s, String text) {
        if (s instanceof Player p) {
            Msg.send(p, text);
        } else {
            s.sendMessage(text.replaceAll("&[0-9a-fk-or]", ""));
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) {
                mgr.openMenu(p);
            } else {
                say(sender, "Perintah ini untuk pemain. Pakai /zm list");
            }
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "join" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "Perintah ini untuk pemain.");
                    return true;
                }
                if (args.length < 2) {
                    mgr.openMenu(p);
                } else {
                    mgr.join(p, args[1]);
                }
            }
            case "accept" -> {
                if (!(sender instanceof Player p)) {
                    return true;
                }
                if (args.length < 2) {
                    say(p, "&cUndangan tidak valid.");
                    return true;
                }
                try {
                    mgr.acceptInvite(p, UUID.fromString(args[1]));
                } catch (IllegalArgumentException ex) {
                    say(p, "&cUndangan tidak valid.");
                }
            }
            case "leave" -> {
                if (!(sender instanceof Player p)) {
                    return true;
                }
                if (mgr.leave(p)) {
                    say(p, "&aKamu keluar dari game.");
                } else {
                    say(p, "&cKamu tidak sedang berada di game.");
                }
            }
            case "practice" -> {
                if (!(sender instanceof Player p)) {
                    return true;
                }
                if (args.length < 2) {
                    mgr.join(p, "practice");
                } else {
                    Kit kit = Kit.parse(args[1]);
                    if (kit == null) {
                        say(p, "&cKit tidak dikenal. Pilihan: crystal, mace, sword, nodebuff");
                    } else {
                        mgr.pickKit(p, kit);
                    }
                }
            }
            case "bot" -> {
                if (!(sender instanceof Player p)) {
                    return true;
                }
                if (args.length < 2) {
                    say(p, "&7Gunakan: &f/zm bot <mati|mudah|sedang|sulit>");
                    return true;
                }
                int level = switch (args[1].toLowerCase(Locale.ROOT)) {
                    case "off", "mati", "0" -> 0;
                    case "mudah", "easy", "1" -> 1;
                    case "sedang", "medium", "2" -> 2;
                    case "sulit", "hard", "3" -> 3;
                    default -> -1;
                };
                if (level < 0) {
                    say(p, "&7Gunakan: &f/zm bot <mati|mudah|sedang|sulit>");
                    return true;
                }
                mgr.setBot(p, level);
                say(p, mgr.of(p) instanceof PracticeGame
                        ? "&aBot lawan: " + GameManager.botName(level)
                        : "&aTingkat bot disimpan (" + GameManager.botName(level) + "&a), aktif saat kamu masuk Practice PvP.");
            }
            case "list" -> {
                say(sender, "&bDaftar arena:");
                for (String key : mgr.keys()) {
                    for (Game g : mgr.list(key)) {
                        say(sender, "&8 \u2022 &f" + g.id() + " &8- &e" + g.state + " &7(" + g.players.size() + "/" + g.max + ")"
                                + (g.open ? "" : " &c[ditutup]"));
                    }
                }
            }
            case "rules" -> {
                if (!(sender instanceof Player p)) {
                    return true;
                }
                if (args.length < 2) {
                    Game g = mgr.of(p);
                    if (g != null) {
                        g.showRules(p);
                    } else {
                        say(p, "&7Gunakan: &f/zm rules <game>");
                    }
                    return true;
                }
                if (mgr.list(args[1]) == null) {
                    say(p, "&cGame tidak ditemukan.");
                } else {
                    mgr.showRules(p, args[1]);
                }
            }
            case "build", "reload", "forcestart", "open", "close" -> adminCommand(sender, sub, args);
            default -> say(sender, "&cPerintah tidak dikenal. &7Ketik &f/zm &7untuk membuka menu.");
        }
        return true;
    }

    private void adminCommand(CommandSender sender, String sub, String[] args) {
        if (!admin(sender)) {
            say(sender, "&cKamu tidak punya izin.");
            return;
        }
        switch (sub) {
            case "build" -> {
                if (args.length < 2) {
                    say(sender, "&7Gunakan: &f/zm build <game|all>");
                    return;
                }
                int n = mgr.rebuild(args[1]);
                say(sender, n == 0 ? "&cGame tidak ditemukan." : "&a" + n + " arena dijadwalkan untuk dibangun ulang.");
            }
            case "reload" -> {
                plugin.reloadConfig();
                say(sender, "&aConfig dimuat ulang.");
            }
            case "forcestart" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "Perintah ini untuk pemain.");
                    return;
                }
                Game g = mgr.of(p);
                if (g == null) {
                    say(p, "&cKamu tidak sedang berada di game.");
                } else {
                    g.forceStart();
                    say(p, "&aGame dipaksa mulai.");
                }
            }
            default -> {
                if (args.length < 2) {
                    say(sender, "&7Gunakan: &f/zm " + sub + " <game|all>");
                    return;
                }
                int n = mgr.setOpen(args[1], sub.equals("open"));
                say(sender, n == 0 ? "&cGame tidak ditemukan." : "&aArena " + (sub.equals("open") ? "dibuka" : "ditutup") + ": " + n);
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(List.of("join", "leave", "list", "rules", "practice", "bot"));
            if (admin(sender)) {
                out.addAll(List.of("build", "reload", "forcestart", "open", "close"));
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "join", "rules" -> out.addAll(mgr.keys());
                case "practice" -> out.addAll(List.of("crystal", "mace", "sword", "nodebuff"));
                case "bot" -> out.addAll(List.of("mati", "mudah", "sedang", "sulit"));
                case "build", "open", "close" -> {
                    if (admin(sender)) {
                        out.add("all");
                        out.addAll(mgr.keys());
                    }
                }
                default -> {
                }
            }
        }
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }
}
