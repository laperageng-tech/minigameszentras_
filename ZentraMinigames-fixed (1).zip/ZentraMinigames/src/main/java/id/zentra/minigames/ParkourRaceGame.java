package id.zentra.minigames;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

/** Parkour 1v1: balapan, vote map dan mode di ruang tunggu. */
public final class ParkourRaceGame extends Game {

    private static final String[] MAPS = {"Sky", "Ice", "Nether"};
    private static final String[] MODES = {"CLASSIC", "SPEEDRUN", "HARDCORE"};

    private final ParkourGame[] courses;
    private final Map<UUID, String> mapVotes = new HashMap<>();
    private final Map<UUID, String> modeVotes = new HashMap<>();
    private final Map<UUID, Integer> checkpoints = new HashMap<>();
    private ParkourGame course;
    private String selectedMap = "-";
    private ParkourGame.Mode mode = ParkourGame.Mode.CLASSIC;

    public ParkourRaceGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "parkourrace", "Parkour 1v1", Material.FEATHER, instance, cx, by, cz, 2, 2, List.of(
                "Balapan menuju garis akhir; pemain pertama yang sampai menang.",
                "Setelah lawan ditemukan, vote map dan mode di ruang tunggu.",
                "Jika tidak ada suara atau seri, pilihan diacak."));
        this.courses = new ParkourGame[]{
                new ParkourGame(plugin, mgr, "race-sky", "Sky Parkour", 0, instance, cx, by, cz - 28),
                new ParkourGame(plugin, mgr, "race-ice", "Ice Parkour", 1, instance, cx, by, cz),
                new ParkourGame(plugin, mgr, "race-nether", "Nether Parkour", 2, instance, cx, by, cz + 28)};
        this.voidY = by - 12;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        for (ParkourGame c : courses) {
            c.buildArena(bp);
        }
    }

    @Override
    protected void giveLobbyItems(Player player) {
        super.giveLobbyItems(player);
        player.getInventory().setItem(4, plugin.lobbyItem(Material.CLOCK, "&a&lVote Map & Mode", "vote", "&7Klik kanan untuk vote"));
    }

    @Override
    public boolean join(Player player) {
        if (!super.join(player)) {
            return false;
        }
        if (players.size() == 2) {
            bc("&aLawan ditemukan! Gunakan item Vote untuk memilih map dan mode.");
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (players.size() == 2 && (state == State.WAITING || state == State.COUNTDOWN)) {
                    for (Player p : online()) {
                        manager.openRaceVote(p, this);
                    }
                }
            });
        }
        return true;
    }

    public boolean canVote(Player player) {
        return players.size() == 2 && players.contains(player.getUniqueId())
                && (state == State.WAITING || state == State.COUNTDOWN);
    }

    public void vote(Player player, boolean isMap, String value) {
        if (!canVote(player)) {
            return;
        }
        for (String s : isMap ? MAPS : MODES) {
            if (s.equals(value)) {
                (isMap ? mapVotes : modeVotes).put(player.getUniqueId(), value);
                Msg.send(player, "&aVote " + (isMap ? "map" : "mode") + ": &e" + value);
                return;
            }
        }
    }

    public int mapVotes(String s) {
        return (int) mapVotes.values().stream().filter(s::equals).count();
    }

    public int modeVotes(String s) {
        return (int) modeVotes.values().stream().filter(s::equals).count();
    }

    private String pick(String[] options, Map<UUID, String> votes) {
        votes.keySet().retainAll(players);
        int best = -1;
        List<String> top = new ArrayList<>();
        for (String s : options) {
            int c = (int) votes.values().stream().filter(s::equals).count();
            if (c > best) {
                best = c;
                top.clear();
            }
            if (c == best) {
                top.add(s);
            }
        }
        return top.get(rnd.nextInt(top.size()));
    }

    @Override
    public void lobbyAction(Player player, String action) {
        if (action.equals("vote")) {
            if (canVote(player)) {
                manager.openRaceVote(player, this);
            } else {
                Msg.send(player, "&eVote tersedia setelah lawan ditemukan.");
            }
        } else if (action.equals("parkour_checkpoint") && state == State.RUNNING) {
            onOut(player, null, "kembali");
        } else {
            super.lobbyAction(player, action);
        }
    }

    @Override
    public void forceStart() {
        if (players.size() >= 2) {
            super.forceStart();
        }
    }

    @Override
    protected void onStart() {
        selectedMap = pick(MAPS, mapVotes);
        mode = ParkourGame.Mode.valueOf(pick(MODES, modeVotes));
        course = courses[Arrays.asList(MAPS).indexOf(selectedMap)];
        mapVotes.clear();
        modeVotes.clear();
        checkpoints.clear();
        for (Player p : online()) {
            p.closeInventory();
            checkpoints.put(p.getUniqueId(), 0);
            p.teleport(course.point(0));
            p.getInventory().setItem(0, plugin.lobbyItem(Material.COMPASS, "&aKembali ke checkpoint", "parkour_checkpoint",
                    "&7Kembali ke checkpoint atau awal"));
            p.getInventory().setItem(8, plugin.leaveItem());
            Msg.title(p, "&b&lPARKOUR 1v1", "&f" + selectedMap + " &8| &e" + mode, 5, 50, 10);
        }
        bc("&eMap: &f" + selectedMap + " &8| &eMode: &f" + mode + " &8| &7Pertama sampai garis akhir menang!");
    }

    @Override
    protected void onFast() {
        if (course == null) {
            return;
        }
        for (Player p : online()) {
            int n = checkpoints.getOrDefault(p.getUniqueId(), 0) + 5;
            if (n > 20 || !course.atStep(p, n)) {
                continue;
            }
            if (n == 20) {
                end(List.of(p));
                return;
            }
            checkpoints.put(p.getUniqueId(), n);
            Msg.bar(p, "&aTahap " + (n / 5) + "/3 tercapai!");
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        }
    }

    @Override
    protected void onOut(Player player, Player killer, String reason) {
        if (course == null) {
            return;
        }
        int n = mode == ParkourGame.Mode.CLASSIC ? checkpoints.getOrDefault(player.getUniqueId(), 0) : 0;
        if (mode != ParkourGame.Mode.CLASSIC) {
            checkpoints.put(player.getUniqueId(), 0);
        }
        player.setFallDistance(0.0f);
        player.teleport(course.point(n));
        Msg.bar(player, n == 0 ? "&eKembali ke awal!" : "&aKembali ke checkpoint!");
    }

    @Override
    public void onDamage(EntityDamageEvent e, Player victim, Player attacker) {
        e.setCancelled(true);
        if (state == State.RUNNING && e.getCause() == EntityDamageEvent.DamageCause.VOID) {
            onOut(victim, null, "jatuh");
        }
    }

    @Override
    protected void onLeave(Player player) {
        mapVotes.remove(player.getUniqueId());
        modeVotes.remove(player.getUniqueId());
        checkpoints.remove(player.getUniqueId());
    }

    @Override
    protected void onReset() {
        mapVotes.clear();
        modeVotes.clear();
        checkpoints.clear();
        course = null;
        selectedMap = "-";
    }

    @Override
    protected String barText() {
        return "&bParkour 1v1 &8| &f" + selectedMap + " &8| &e" + mode + " &8| &7" + fmtTime(runSecs);
    }

    @Override
    protected List<String> sideExtra() {
        return List.of("&fMap &8\u00bb &b" + selectedMap, "&fMode &8\u00bb &e" + mode, "&fWaktu &8\u00bb &e" + fmtTime(runSecs));
    }
}
