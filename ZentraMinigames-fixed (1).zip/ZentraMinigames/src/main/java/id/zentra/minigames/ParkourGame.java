package id.zentra.minigames;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

/** Parkour solo: 20 langkah, 3 checkpoint, 3 mode. Tanpa lobby, langsung main. */
public final class ParkourGame extends Game {

    private static final int STEPS = 20;

    private final int variant;
    private final Map<UUID, Integer> checkpoints = new HashMap<>();
    private final Map<UUID, Long> starts = new HashMap<>();
    private final Map<UUID, Mode> modes = new HashMap<>();
    private final Map<UUID, Integer> falls = new HashMap<>();
    private final Map<UUID, Map<Mode, Long>> records = new HashMap<>();

    public enum Mode { CLASSIC, SPEEDRUN, HARDCORE }

    public ParkourGame(ZentraMinigames plugin, GameManager mgr, String key, String name, int variant,
                       int instance, int cx, int by, int cz) {
        super(plugin, mgr, key, name,
                variant == 0 ? Material.FEATHER : (variant == 1 ? Material.ICE : Material.BLAZE_POWDER),
                instance, cx, by, cz, 1, 20, List.of(
                        "Lompat dari platform ke platform dan capai garis akhir secepat mungkin.",
                        "Injak checkpoint hijau secara berurutan. Jika jatuh, kamu kembali ke checkpoint terakhir.",
                        "Tamat untuk melihat waktumu dan mulai lagi, atau gunakan /zm leave untuk keluar."));
        this.variant = variant;
        this.continuous = true;
        this.voidY = by - 12;
    }

    private int x(int n) {
        return cx - 40 + n * 4;
    }

    private int z(int n) {
        if (variant == 0) {
            return cz;
        }
        if (variant == 1) {
            return cz + (n % 2 == 0 ? -1 : 1);
        }
        return cz + (n % 4 < 2 ? -1 : 1);
    }

    private int y(int n) {
        return by + (variant == 2 ? n / 4 : 0);
    }

    Location point(int n) {
        return new Location(world, x(n) + 0.5, y(n) + 1, z(n) + 0.5, -90.0f, 0.0f);
    }

    boolean atStep(Player p, int n) {
        if (p.getWorld() != world || !p.isOnGround()) {
            return false;
        }
        Location l = p.getLocation();
        int r = n == STEPS ? 3 : 1;
        return Math.abs(l.getX() - (x(n) + 0.5)) <= r + 0.5
                && Math.abs(l.getZ() - (z(n) + 0.5)) <= r + 0.5
                && l.getY() >= y(n) + 0.9 && l.getY() <= y(n) + 1.5;
    }

    @Override
    protected boolean hasLobby() {
        return false;
    }

    @Override
    public Location specSpawn() {
        return point(0);
    }

    @Override
    public boolean joinable() {
        return open && (state == State.WAITING || state == State.RUNNING) && players.size() < max;
    }

    @Override
    public void forceStart() {
    }

    @Override
    protected void checkWin() {
    }

    @Override
    protected void onStart() {
    }

    @Override
    protected void buildArena(Blueprint bp) {
        Material floor = variant == 0 ? Material.QUARTZ_BLOCK : (variant == 1 ? Material.PACKED_ICE : Material.RED_NETHER_BRICKS);
        Material check = Material.LIME_CONCRETE;
        Material pillar = variant == 2 ? Material.BLACKSTONE : Material.POLISHED_DEEPSLATE;
        Material lamp = Material.SEA_LANTERN;
        for (int i = 0; i <= STEPS; i++) {
            int px = x(i);
            int py = y(i);
            int pz = z(i);
            int r = (i == 0 || i == STEPS) ? 3 : 1;
            bp.fill(px - r, py, pz - r, px + r, py, pz + r, i % 5 == 0 ? check : floor);
            if (i % 5 == 0) {
                bp.fill(px, py - 4, pz, px, py - 1, pz, pillar);
                bp.set(px, py - 5, pz, lamp);
            }
        }
        for (int i : new int[]{0, STEPS}) {
            int px = x(i);
            int py = y(i);
            int pz = z(i);
            bp.fill(px, py + 1, pz - 3, px, py + 5, pz - 3, pillar);
            bp.fill(px, py + 1, pz + 3, px, py + 5, pz + 3, pillar);
            bp.fill(px, py + 5, pz - 3, px, py + 5, pz + 3, lamp);
        }
        Material deco = variant == 0 ? Material.LIGHT_BLUE_CONCRETE : (variant == 1 ? Material.BLUE_ICE : Material.NETHER_BRICKS);
        for (int i : new int[]{0, 5, 10, 15, 20}) {
            int px = x(i);
            int py = y(i);
            for (int side : new int[]{-1, 1}) {
                int pz = cz + side * 8;
                bp.cone(px, py - 2, pz, 3, 5, pillar);
                bp.disc(px, py - 1, pz, 3, deco);
                bp.fill(px, py, pz, px, py + 6, pz, pillar);
                bp.set(px, py + 7, pz, lamp);
            }
        }
        for (int i : new int[]{0, STEPS}) {
            int px = x(i);
            int py = y(i);
            int pz = z(i);
            bp.ring(px, py - 1, pz, 4, 6, deco);
            bp.cone(px, py - 2, pz, 4, 5, pillar);
            bp.fill(px, py + 6, pz - 4, px, py + 6, pz + 4, deco);
        }
    }

    @Override
    public boolean join(Player player) {
        return joinWith(player, Mode.CLASSIC);
    }

    public boolean joinWith(Player player, Mode mode) {
        if (!joinable() || players.contains(player.getUniqueId())) {
            return false;
        }
        if (state == State.WAITING) {
            state = State.RUNNING;
            runSecs = 0;
        }
        UUID id = player.getUniqueId();
        saved.put(id, snapshot(player));
        players.add(id);
        alive.add(id);
        player.leaveVehicle();
        resetPlayer(player, GameMode.ADVENTURE);
        player.getInventory().setItem(0, plugin.lobbyItem(Material.COMPASS, "&a&lKembali ke checkpoint", "parkour_checkpoint",
                "&7Kembali ke checkpoint di Classic", "&7Mode lain kembali ke awal"));
        player.getInventory().setItem(1, plugin.lobbyItem(Material.CLOCK, "&e&lMulai ulang", "parkour_restart",
                "&7Mulai lintasan dan waktu dari awal"));
        player.getInventory().setItem(8, plugin.leaveItem());
        checkpoints.put(id, 0);
        starts.put(id, System.currentTimeMillis());
        modes.put(id, mode);
        falls.put(id, 0);
        player.teleport(point(0));
        bar.addPlayer(player);
        plugin.sidebar(player, this);
        Msg.title(player, "&b&l" + name.toUpperCase(Locale.ROOT), "&e" + mode + " &7| Capai garis akhir!", 5, 50, 10);
        Msg.send(player, mode == Mode.CLASSIC ? "&aCheckpoint aktif. Jatuh kembali ke checkpoint terakhir."
                : (mode == Mode.SPEEDRUN ? "&eTanpa checkpoint: jatuh kembali ke awal, waktu terus berjalan."
                : "&cHardcore: jatuh mengulang lintasan dan waktu!"));
        return true;
    }

    @Override
    public void lobbyAction(Player player, String action) {
        UUID id = player.getUniqueId();
        if (!players.contains(id) || state != State.RUNNING) {
            return;
        }
        if (action.equals("parkour_checkpoint")) {
            onOut(player, null, "kembali");
        } else if (action.equals("parkour_restart")) {
            checkpoints.put(id, 0);
            starts.put(id, System.currentTimeMillis());
            falls.put(id, 0);
            player.setFallDistance(0.0f);
            player.teleport(point(0));
            Msg.bar(player, "&eLintasan dan waktu dimulai ulang!");
        } else {
            super.lobbyAction(player, action);
        }
    }

    @Override
    protected void onFast() {
        for (Player p : online()) {
            UUID id = p.getUniqueId();
            int n = checkpoints.getOrDefault(id, 0) + 5;
            if (n > STEPS || !atStep(p, n)) {
                continue;
            }
            if (n == STEPS) {
                long ms = System.currentTimeMillis() - starts.getOrDefault(id, System.currentTimeMillis());
                Mode mode = modes.getOrDefault(id, Mode.CLASSIC);
                Map<Mode, Long> rec = records.computeIfAbsent(id, k -> new HashMap<>());
                Long old = rec.get(mode);
                boolean pb = old == null || ms < old;
                if (pb) {
                    rec.put(mode, ms);
                }
                String t = String.format(Locale.US, "%.2f", ms / 1000.0);
                Msg.title(p, "&6&lSELESAI!", "&fWaktu: &e" + t + "s" + (pb ? " &aREKOR!" : ""), 5, 60, 10);
                Msg.send(p, "&6" + name + " &8| &e" + mode + " &8| &f" + t + "s &8| &cJatuh: " + falls.getOrDefault(id, 0)
                        + (pb ? " &aRekor pribadi baru!" : ""));
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                checkpoints.put(id, 0);
                starts.put(id, System.currentTimeMillis());
                falls.put(id, 0);
                p.teleport(point(0));
                continue;
            }
            checkpoints.put(id, n);
            Msg.bar(p, modes.getOrDefault(id, Mode.CLASSIC) == Mode.CLASSIC
                    ? "&aCheckpoint " + (n / 5) + "/3 tersimpan!" : "&bTahap " + (n / 5) + "/3 tercapai!");
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        }
    }

    @Override
    protected void onOut(Player player, Player killer, String reason) {
        UUID id = player.getUniqueId();
        Mode mode = modes.getOrDefault(id, Mode.CLASSIC);
        falls.merge(id, 1, Integer::sum);
        int n = mode == Mode.CLASSIC ? checkpoints.getOrDefault(id, 0) : 0;
        if (mode != Mode.CLASSIC) {
            checkpoints.put(id, 0);
        }
        if (mode == Mode.HARDCORE) {
            starts.put(id, System.currentTimeMillis());
        }
        player.setFallDistance(0.0f);
        player.teleport(point(n));
        Msg.bar(player, mode == Mode.CLASSIC ? "&eKembali ke checkpoint!"
                : (mode == Mode.SPEEDRUN ? "&eKembali ke awal, waktu terus berjalan!" : "&cGagal! Waktu diulang."));
    }

    @Override
    public void onDamage(EntityDamageEvent e, Player victim, Player attacker) {
        e.setCancelled(true);
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
            onOut(victim, null, "jatuh");
        }
    }

    @Override
    protected void onLeave(Player player) {
        UUID id = player.getUniqueId();
        checkpoints.remove(id);
        starts.remove(id);
        modes.remove(id);
        falls.remove(id);
    }

    @Override
    protected String barText() {
        return "&b&l" + name + " &8| &fCapai garis akhir &8| &7/zm leave";
    }

    @Override
    public List<String> sidebarLines(Player player) {
        UUID id = player.getUniqueId();
        Mode mode = modes.getOrDefault(id, Mode.CLASSIC);
        Long rec = records.getOrDefault(id, Map.of()).get(mode);
        long secs = (System.currentTimeMillis() - starts.getOrDefault(id, System.currentTimeMillis())) / 1000L;
        return List.of("&8" + id(), " ",
                "&fMode &8\u00bb &b" + mode,
                "&fTahap &8\u00bb &a" + (checkpoints.getOrDefault(id, 0) / 5) + "&7/3",
                "&fWaktu &8\u00bb &e" + secs + "s",
                "&fJatuh &8\u00bb &c" + falls.getOrDefault(id, 0),
                "&fRekor &8\u00bb &6" + (rec == null ? "-" : String.format(Locale.US, "%.2fs", rec / 1000.0)),
                " ", "&b/zm leave &7= keluar");
    }
}
