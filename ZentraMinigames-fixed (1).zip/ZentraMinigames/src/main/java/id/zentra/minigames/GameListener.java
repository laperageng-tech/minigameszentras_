package id.zentra.minigames;

import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.event.Event;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;

public final class GameListener implements Listener {

    private final ZentraMinigames plugin;
    private final GameManager mgr;

    public GameListener(ZentraMinigames plugin, GameManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    /** true = plugin ini boleh membatalkan pembatalan dari plugin lain (WorldGuard, Multiverse, dsb.) untuk pemain yang sedang bermain. */
    private boolean force() {
        return plugin.getConfig().getBoolean("compat.force-pvp", true);
    }

    private static boolean admin(Player p) {
        return p.hasPermission("zentra.minigames.admin");
    }

    /* ---------------- damage / death ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim)) {
            return;
        }
        Game game = mgr.of(victim);
        if (game == null) {
            return;
        }
        if (e.isCancelled()) {
            if (!force()) {
                return;
            }
            // dibatalkan plugin lain (mis. flag pvp WorldGuard / pvp=false Multiverse): aturan game yang menentukan
            e.setCancelled(false);
        }
        Player attacker = null;
        if (e instanceof EntityDamageByEntityEvent ev) {
            Entity damager = ev.getDamager();
            if (damager instanceof TNTPrimed) {
                e.setCancelled(true);
                return;
            }
            if (damager instanceof Player p) {
                attacker = p;
            } else if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) {
                attacker = p;
            }
        }
        game.onDamage(e, victim, attacker);
    }

    /** Pukulan ke bot Practice dan End Crystal tidak boleh diblokir plugin lain. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onHitMob(EntityDamageByEntityEvent e) {
        if (!e.isCancelled() || !force() || e.getEntity() instanceof Player) {
            return;
        }
        Player attacker = null;
        if (e.getDamager() instanceof Player p) {
            attacker = p;
        } else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player p) {
            attacker = p;
        }
        if (attacker == null) {
            return;
        }
        Game game = mgr.of(attacker);
        if (game == null || game.state != Game.State.RUNNING) {
            return;
        }
        boolean crystal = e.getEntity() instanceof EnderCrystal && game.allowBuildBlocks;
        boolean bot = game instanceof PracticeGame && mgr.gameAt(e.getEntity().getLocation()) == game;
        if (crystal || bot) {
            e.setCancelled(false);
        }
    }

    /** Memasang End Crystal, menyalakan TNT, ember dan ender pearl di game yang mengizinkan build. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onUseItem(PlayerInteractEvent e) {
        if (!force() || e.getItem() == null || e.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Game game = mgr.of(e.getPlayer());
        if (game == null || game.state != Game.State.RUNNING || !game.canBuild) {
            return;
        }
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Material m = e.getItem().getType();
        boolean onBlock = m == Material.END_CRYSTAL || m == Material.FLINT_AND_STEEL;
        boolean item = onBlock || m == Material.ENDER_PEARL || m == Material.WIND_CHARGE || m.name().endsWith("_BUCKET");
        if (!item) {
            return;
        }
        e.setUseItemInHand(Event.Result.ALLOW);
        if (onBlock && e.getClickedBlock() != null) {
            e.setUseInteractedBlock(Event.Result.ALLOW);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (mgr.of(p) == null) {
            return;
        }
        e.setKeepInventory(true);
        e.setKeepLevel(true);
        e.getDrops().clear();
        e.setDroppedExp(0);
        e.deathMessage(null);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isDead()) {
                p.spigot().respawn();
            }
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Game game = mgr.of(p);
        if (game == null) {
            return;
        }
        e.setRespawnLocation(game.specSpawn());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && mgr.of(p) == game) {
                game.playerDied(p);
            }
        }, 2L);
    }

    @EventHandler
    public void onTarget(EntityTargetLivingEntityEvent e) {
        if (e.getEntity() instanceof Player) {
            return;
        }
        if (mgr.gameAt(e.getEntity().getLocation()) instanceof PracticeGame pg) {
            if (!pg.allowTarget(e.getEntity(), e.getTarget())) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) {
            return;
        }
        if (mgr.gameAt(e.getEntity().getLocation()) instanceof PracticeGame pg) {
            pg.onBotDeath(e);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        mgr.leave(e.getPlayer());
    }

    /* ---------------- blocks ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Game game = mgr.of(p);
        if (game == null) {
            if (mgr.gameAt(e.getBlock().getLocation()) != null && !admin(p)) {
                e.setCancelled(true);
            }
            return;
        }
        if (e.isCancelled() && !force()) {
            return;
        }
        // keputusan sepenuhnya ada di aturan game (mode), bukan plugin region lain
        e.setCancelled(!game.allowBreak(e.getBlock(), p));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Game game = mgr.of(p);
        if (game == null) {
            if (mgr.gameAt(e.getBlock().getLocation()) != null && !admin(p)) {
                e.setCancelled(true);
            }
            return;
        }
        if (e.isCancelled() && !force()) {
            return;
        }
        e.setCancelled(!game.allowPlace(e.getBlockPlaced(), p));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBucket(PlayerBucketEmptyEvent e) {
        Player p = e.getPlayer();
        Game game = mgr.of(p);
        if (game == null) {
            return;
        }
        if (e.isCancelled() && !force()) {
            return;
        }
        e.setCancelled(!game.allowBuildBlocks || !game.allowPlace(e.getBlock(), p));
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        Game game = mgr.gameAt(e.getLocation());
        if (game != null) {
            game.onExplode(e);
        }
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        if (mgr.gameAt(e.getBlock().getLocation()) != null) {
            e.blockList().clear();
        }
    }

    /* ---------------- items / interaction ---------------- */

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Game game = mgr.of(p);
        if (game == null || e.getHand() != EquipmentSlot.HAND || e.getAction() == Action.PHYSICAL) {
            return;
        }
        String id = plugin.itemId(e.getItem());
        if (id != null) {
            e.setCancelled(true);
            if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
                game.lobbyAction(p, id);
            }
            return;
        }
        game.onInteract(e);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && mgr.of(p) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        Game game = mgr.of(e.getPlayer());
        if (game != null && !game.canBuild) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p) {
            Game game = mgr.of(p);
            if (game != null && !game.canBuild) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Game game = mgr.of(e.getPlayer());
        if (game != null && game.lockInv) {
            e.setCancelled(true);
        }
    }

    /* ---------------- inventories / menus ---------------- */

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof GameManager.MenuHolder holder) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player clicker)) {
                return;
            }
            if (e.getClickedInventory() != top) {
                return;
            }
            String key = holder.keys.get(e.getRawSlot());
            if (key == null || key.equals("_info")) {
                return;
            }
            handleMenu(clicker, key, e.isRightClick());
            return;
        }
        if (e.getWhoClicked() instanceof Player p) {
            Game game = mgr.of(p);
            if (game != null && game.lockInv) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof GameManager.MenuHolder) {
            e.setCancelled(true);
            return;
        }
        if (e.getWhoClicked() instanceof Player p) {
            Game game = mgr.of(p);
            if (game != null && game.lockInv) {
                e.setCancelled(true);
            }
        }
    }

    private void handleMenu(Player p, String key, boolean rightClick) {
        try {
            if (key.equals("_leave")) {
                p.closeInventory();
                if (mgr.leave(p)) {
                    Msg.send(p, "&aKamu keluar dari game.");
                }
                return;
            }
            if (key.equals("_back")) {
                mgr.openMenu(p);
                return;
            }
            if (key.equals("parkour:select")) {
                mgr.openParkourSelect(p);
                return;
            }
            if (key.equals("parkour:race")) {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> mgr.join(p, "parkourrace"));
                return;
            }
            if (key.startsWith("race:map:") || key.startsWith("race:mode:")) {
                if (mgr.of(p) instanceof ParkourRaceGame race) {
                    boolean isMap = key.startsWith("race:map:");
                    race.vote(p, isMap, key.substring(key.lastIndexOf(':') + 1));
                    if (race.canVote(p)) {
                        mgr.openRaceVote(p, race);
                    }
                }
                return;
            }
            if (key.equals("parkour:maps")) {
                mgr.openParkourMaps(p);
                return;
            }
            if (key.startsWith("parkour:map:")) {
                mgr.openParkourModes(p, key.substring("parkour:map:".length()));
                return;
            }
            if (key.startsWith("parkour:play:")) {
                String[] parts = key.split(":");
                p.closeInventory();
                mgr.joinParkour(p, parts[2], ParkourGame.Mode.valueOf(parts[3]));
                return;
            }
            if (key.equals("_bot")) {
                int level = mgr.cycleBot(p);
                Msg.bar(p, "&7Bot lawan: " + GameManager.botName(level));
                mgr.openKitMenu(p);
                return;
            }
            if (key.equals("_botoff")) {
                mgr.setBot(p, 0);
                Msg.send(p, "&aMode bot dimatikan. Kamu di arena global.");
                mgr.openKitMenu(p);
                return;
            }
            if (key.startsWith("invitepage:")) {
                mgr.openInvites(p, Integer.parseInt(key.substring("invitepage:".length())));
                return;
            }
            if (key.startsWith("invite:")) {
                p.closeInventory();
                mgr.invite(p, UUID.fromString(key.substring("invite:".length())));
                return;
            }
            if (key.startsWith("vote:")) {
                if (mgr.of(p) instanceof DuelGame duel) {
                    duel.voteKit(p, Kit.valueOf(key.substring("vote:".length())));
                    mgr.openDuelVote(p, duel);
                }
                return;
            }
            if (key.startsWith("kit:")) {
                p.closeInventory();
                mgr.pickKit(p, Kit.valueOf(key.substring("kit:".length())));
                return;
            }
            // default: nama game
            List<Game> list = mgr.list(key);
            if (rightClick && list != null) {
                p.closeInventory();
                mgr.showRules(p, key);
                return;
            }
            p.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> mgr.join(p, key));
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Menu error (" + key + "): " + ex);
        }
    }

    /* ---------------- commands ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (mgr.of(p) == null || admin(p)) {
            return;
        }
        String msg = e.getMessage();
        String root = msg.substring(1).split(" ")[0].toLowerCase(java.util.Locale.ROOT);
        if (root.equals("zm") || root.equals("minigames") || root.equals("zminigames")) {
            return;
        }
        if (plugin.getConfig().getStringList("allowed-commands").contains(root)) {
            return;
        }
        e.setCancelled(true);
        Msg.send(p, "&cTidak bisa memakai command itu saat bermain. Pakai &f/zm leave &cuntuk keluar.");
    }

    @SuppressWarnings("unused")
    private static boolean isLiving(Entity e) {
        return e instanceof LivingEntity;
    }
}
