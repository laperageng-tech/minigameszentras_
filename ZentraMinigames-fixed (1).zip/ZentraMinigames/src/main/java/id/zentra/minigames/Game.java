package id.zentra.minigames;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** Base class for every minigame arena. Subclasses implement the rules. */
public abstract class Game {

    public enum State { RESETTING, WAITING, COUNTDOWN, RUNNING, ENDING }

    protected final ZentraMinigames plugin;
    protected final GameManager manager;
    public final String key;
    public final String name;
    public final Material icon;
    public final int instance;
    public final int cx;
    public final int by;
    public final int cz;
    public final int min;
    public final int max;
    public final List<String> rules;
    protected int voidY;
    protected World world;

    protected boolean pvp;
    protected boolean envDamage;
    protected boolean fallDamage;
    protected boolean canBuild;
    protected boolean allowBuildBlocks;
    protected boolean lockInv = true;
    protected boolean continuous;
    public boolean open = true;

    public State state = State.RESETTING;
    protected int countdown;
    protected int cdFull;
    protected int runSecs;
    protected int ticks;

    protected final Set<UUID> players = new LinkedHashSet<>();
    protected final Set<UUID> alive = new LinkedHashSet<>();
    protected final Map<UUID, Saved> saved = new HashMap<>();
    protected final Map<UUID, UUID> lastHit = new HashMap<>();
    protected final Map<UUID, Long> lastHitAt = new HashMap<>();
    protected final Set<String> placed = new LinkedHashSet<>();
    protected final BossBar bar = Bukkit.createBossBar("", BarColor.BLUE, BarStyle.SOLID);
    protected final java.util.Random rnd = new java.util.Random();
    private final Map<UUID, Long> inviteCd = new HashMap<>();
    private BukkitRunnable loop;

    protected record Saved(ItemStack[] contents, ItemStack[] armor, ItemStack offhand, org.bukkit.Location loc,
                           GameMode mode, double health, int food, float saturation, float exp, int level,
                           boolean flight) {
    }

    protected Game(ZentraMinigames plugin, GameManager manager, String key, String name, Material icon,
                   int instance, int cx, int by, int cz, int min, int max, List<String> rules) {
        this.plugin = plugin;
        this.manager = manager;
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.instance = instance;
        this.cx = cx;
        this.by = by;
        this.cz = cz;
        this.min = min;
        this.max = max;
        this.rules = rules;
        this.voidY = by - 12;
        this.world = Bukkit.getWorld(plugin.worldName());
    }

    public String id() {
        return key + "-" + instance;
    }

    /* ---------------- hooks for subclasses ---------------- */

    protected abstract void buildArena(Blueprint bp);

    protected void onStart() {
    }

    protected void onSecond() {
    }

    protected void onFast() {
    }

    protected void onEnd() {
    }

    protected void onReset() {
    }

    protected void onLeave(Player player) {
    }

    protected void onInteract(org.bukkit.event.player.PlayerInteractEvent e) {
    }

    protected void onHit(EntityDamageEvent e, Player victim, Player attacker) {
        e.setCancelled(true);
    }

    protected void onOut(Player victim, Player killer, String reason) {
        eliminate(victim, killer, reason);
    }

    protected String barText() {
        return "&b" + name + " &8| &f" + state.name();
    }

    protected List<String> sideExtra() {
        return List.of();
    }

    protected boolean hasLobby() {
        return true;
    }

    public boolean allowBreak(Block block, Player player) {
        return state == State.RUNNING && placed.remove(key(block));
    }

    public boolean allowPlace(Block block, Player player) {
        if (state != State.RUNNING || !allowBuildBlocks) {
            return false;
        }
        if (Math.abs(block.getX() - cx) > 60 || Math.abs(block.getZ() - cz) > 60) {
            return false;
        }
        if (block.getY() < by - 20 || block.getY() > by + 60) {
            return false;
        }
        placed.add(key(block));
        return true;
    }

    protected static String key(Block b) {
        return b.getX() + "," + b.getY() + "," + b.getZ();
    }

    /* ---------------- lifecycle ---------------- */

    public Location lobby() {
        return new Location(world, cx + 0.5, by + 51, cz + 0.5, 0, 0);
    }

    public Location specSpawn() {
        return new Location(world, cx + 0.5, by + 30, cz + 0.5, 0, 0);
    }

    public void activate() {
        loop = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        };
        loop.runTaskTimer(plugin, 20L, 5L);
    }

    public void shutdown() {
        if (loop != null) {
            loop.cancel();
        }
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                restore(p);
            }
        }
        players.clear();
        alive.clear();
        bar.removeAll();
    }

    public boolean joinable() {
        return open && (state == State.WAITING || state == State.COUNTDOWN) && players.size() < max;
    }

    public boolean isIn(UUID id) {
        return players.contains(id);
    }

    /** Builds the arena. clear=true wipes the area first (initial/revision build). */
    public void build(boolean clear, Runnable done) {
        state = State.RESETTING;
        Blueprint bp = new Blueprint();
        if (clear) {
            bp.fill(cx - 70, by - 30, cz - 70, cx + 70, by + 70, cz + 70, Material.AIR);
        }
        if (hasLobby()) {
            buildLobby(bp);
        }
        buildArena(bp);
        buildScenery(bp);
        bp.build(plugin, world, plugin.blocksPerTick(), () -> !anyPlayerNear(clear ? 71 : 0), () -> {
            if (done != null) {
                done.run();
            }
        });
    }

    private boolean anyPlayerNear(int r) {
        if (r <= 0) {
            return true;
        }
        for (Player p : world.getPlayers()) {
            if (Math.abs(p.getLocation().getX() - cx) < r && Math.abs(p.getLocation().getZ() - cz) < r) {
                return false;
            }
        }
        return true;
    }

    private void buildLobby(Blueprint b) {
        int n = by + 50;
        b.cone(cx, n - 1, cz, 9, 9, Material.DEEPSLATE);
        b.disc(cx, n, cz, 8, Material.WHITE_CONCRETE);
        b.ring(cx, n, cz, 5, 6, Material.LIGHT_BLUE_CONCRETE);
        b.disc(cx, n, cz, 2, Material.SEA_LANTERN);
        for (int i = 1; i <= 3; i++) {
            b.ring(cx, n + i, cz, 7, 8, Material.LIGHT_BLUE_STAINED_GLASS);
        }
        for (int[] d : new int[][]{{7, 0}, {-7, 0}, {0, 7}, {0, -7}}) {
            b.fill(cx + d[0], n + 1, cz + d[1], cx + d[0], n + 4, cz + d[1], Material.QUARTZ_PILLAR);
            b.set(cx + d[0], n + 5, cz + d[1], Material.SEA_LANTERN);
        }
    }

    private void buildScenery(Blueprint b) {
        for (int[] d : new int[][]{{60, 60}, {-60, 60}, {60, -60}, {-60, -60}}) {
            int x = cx + d[0];
            int z = cz + d[1];
            b.cylinder(x, by + 7, by + 34, z, 3, Material.POLISHED_DEEPSLATE);
            b.cone(x, by + 5, z, 9, 12, Material.POLISHED_DEEPSLATE);
            b.ring(x, by + 36, z, 4, 6, Material.GOLD_BLOCK);
        }
    }

    /** Re-applies the arena, clears placed blocks and resets everything after a round. */
    protected void finish() {
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                restore(p);
            }
            manager.forget(id);
        }
        players.clear();
        alive.clear();
        saved.clear();
        lastHit.clear();
        lastHitAt.clear();
        bar.removeAll();
        clearPlaced();
        onReset();
        for (Entity e : world.getNearbyEntities(new Location(world, cx + 0.5, by + 20, cz + 0.5), 130, 120, 130)) {
            if (e instanceof org.bukkit.entity.Item || e instanceof org.bukkit.entity.ExperienceOrb
                    || e instanceof org.bukkit.entity.Projectile || e instanceof org.bukkit.entity.TNTPrimed
                    || e instanceof org.bukkit.entity.EnderCrystal || e instanceof org.bukkit.entity.FallingBlock
                    || e instanceof org.bukkit.entity.AreaEffectCloud || e instanceof org.bukkit.entity.Firework
                    || e instanceof org.bukkit.entity.Husk) {
                e.remove(); // NPC, hologram dan entity plugin lain tidak disentuh
            }
        }
        build(false, () -> state = State.WAITING);
    }

    protected void clearPlaced() {
        for (String k : placed) {
            String[] p = k.split(",");
            world.getBlockAt(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]))
                    .setType(Material.AIR, false);
        }
        placed.clear();
    }

    /* ---------------- tick loop ---------------- */

    private void tick() {
        ticks += 5;
        if (state == State.RESETTING) {
            return;
        }
        if (ticks % 20 == 0) {
            second();
        }
        if (state == State.RUNNING) {
            onFast();
        }
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                continue;
            }
            if (state == State.WAITING || state == State.COUNTDOWN) {
                if (!continuous && p.getLocation().getY() < by + 42) {
                    p.teleport(lobby());
                }
            } else if (p.getLocation().getY() < voidY) {
                if (state == State.RUNNING && alive.contains(id)) {
                    onOut(p, lastHitter(id), "jatuh ke void");
                } else {
                    p.teleport(specSpawn());
                }
            }
        }
    }

    protected void second() {
        if (continuous && state == State.WAITING) {
            state = State.RUNNING;
            runSecs = 0;
        }
        for (Player sp : online()) {
            plugin.sidebar(sp, this);
        }
        if (state == State.WAITING) {
            if (players.size() >= min) {
                state = State.COUNTDOWN;
                countdown = Math.max(5, plugin.getConfig().getInt("countdown", 20));
                cdFull = countdown;
                bc("&eCukup pemain! Mulai dalam " + countdown + " detik.");
            } else {
                bar.setTitle(plugin.colorize("&eMenunggu pemain &f" + players.size() + "/" + min));
                bar.setProgress(Math.max(0.0, Math.min(1.0, players.size() / (double) Math.max(1, min))));
                for (Player wp : online()) {
                    Msg.bar(wp, "&eMenunggu pemain &f" + players.size() + "/" + min + " &8| &7klik &bUndang Pemain &7untuk mengajak teman");
                }
            }
        } else if (state == State.COUNTDOWN) {
            if (players.size() < min) {
                state = State.WAITING;
                bc("&cHitung mundur dibatalkan, pemain kurang.");
                return;
            }
            if (countdown <= 0) {
                begin();
                return;
            }
            if (players.size() >= max && countdown > 5 && !key.equals("duel") && !key.equals("parkourrace")) {
                countdown = 5;
            }
            bar.setTitle(plugin.colorize("&aMulai dalam &f" + countdown + "s"));
            bar.setProgress(Math.max(0.0, Math.min(1.0, countdown / (double) Math.max(1, cdFull))));
            if (countdown <= 5 && countdown > 0) {
                for (Player cp : online()) {
                    Msg.title(cp, "&e&l" + countdown, "&7Bersiaplah!", 0, 20, 5);
                    cp.playSound(cp.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f + (5 - countdown) * 0.15f);
                }
            }
            if (countdown == cdFull || countdown == 15 || countdown <= 10 && countdown > 0) {
                bc("&7Mulai dalam &f" + countdown + "s");
            }
            countdown--;
        } else if (state == State.RUNNING) {
            runSecs++;
            bar.setTitle(plugin.colorize(barText()));
            onSecond();
            checkWin();
        }
    }

    public void forceStart() {
        if (state == State.WAITING || state == State.COUNTDOWN) {
            countdown = 0;
            if (state == State.WAITING) {
                state = State.COUNTDOWN;
            }
            begin();
        }
    }

    protected void begin() {
        state = State.RUNNING;
        runSecs = 0;
        bar.setProgress(1.0);
        alive.clear();
        alive.addAll(players);
        lastHit.clear();
        lastHitAt.clear();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                resetPlayer(p, canBuild ? GameMode.SURVIVAL : GameMode.ADVENTURE);
                Msg.title(p, "&6&l" + name, rules.isEmpty() ? "" : "&7" + rules.get(0), 5, 40, 10);
            }
        }
        onStart();
        bc("&aPermainan dimulai! &7" + name);
    }

    protected void checkWin() {
        if (state == State.RUNNING && alive.size() <= 1) {
            end(alivePlayers());
        }
    }

    public void end(List<Player> winners) {
        if (state == State.ENDING || state == State.RESETTING) {
            return;
        }
        state = State.ENDING;
        onEnd();
        String names = winners.isEmpty() ? "Tidak ada" : String.join(", ", winners.stream().map(Player::getName).toList());
        bc("&6&lPEMENANG: &e" + names);
        for (Player w : winners) {
            Msg.title(w, "&6&lMENANG!", "&7" + name, 5, 60, 10);
            plugin.announceWin(w.getName(), name + " #" + instance);
            w.setGameMode(GameMode.ADVENTURE);
            for (int i = 0; i < 4; i++) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (w.isOnline()) {
                        fireworkAt(w.getLocation());
                    }
                }, i * 15L);
            }
            for (String cmd : plugin.getConfig().getStringList("rewards.win")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", w.getName()));
            }
        }
        new BukkitRunnable() {
            @Override
            public void run() {
                finish();
            }
        }.runTaskLater(plugin, 140L);
    }

    /* ---------------- players ---------------- */

    public boolean join(Player player) {
        if (world == null || !joinable() || players.contains(player.getUniqueId())) {
            return false;
        }
        UUID id = player.getUniqueId();
        saved.put(id, snapshot(player));
        players.add(id);
        player.leaveVehicle();
        resetPlayer(player, GameMode.ADVENTURE);
        player.teleport(lobby());
        giveLobbyItems(player);
        bar.addPlayer(player);
        plugin.sidebar(player, this);
        bc("&e" + player.getName() + " &7bergabung. &f(" + players.size() + "/" + max + ")");
        return true;
    }

    protected void giveLobbyItems(Player player) {
        player.getInventory().setItem(0, plugin.lobbyItem(Material.BOOK, "&e&lAturan", "rules", "&7Klik kanan untuk melihat aturan"));
        player.getInventory().setItem(1, plugin.lobbyItem(Material.BELL, "&b&lUndang Pemain", "invite", "&7Klik kanan untuk mengundang"));
        player.getInventory().setItem(8, plugin.leaveItem());
    }

    public void leave(Player player) {
        UUID id = player.getUniqueId();
        boolean was = players.remove(id);
        alive.remove(id);
        bar.removePlayer(player);
        plugin.clearSidebar(player);
        if (!was) {
            return;
        }
        restore(player);
        onLeave(player);
        if (state == State.ENDING || state == State.RESETTING) {
            return;
        }
        bc("&c" + player.getName() + " keluar dari game.");
        if (state == State.RUNNING) {
            checkWin();
        } else if (state == State.COUNTDOWN && players.size() < min) {
            state = State.WAITING;
        }
    }

    public void lobbyAction(Player player, String action) {
        switch (action) {
            case "leave" -> manager.leave(player);
            case "rules" -> showRules(player);
            case "invite" -> manager.openInvites(player, 0);
            default -> {
            }
        }
    }

    public void showRules(Player player) {
        Msg.raw(player, Msg.line());
        for (String r : rules) {
            Msg.raw(player, "&7- &f" + r);
        }
        Msg.raw(player, Msg.line());
    }

    protected Saved snapshot(Player p) {
        return new Saved(p.getInventory().getContents().clone(), p.getInventory().getArmorContents().clone(),
                p.getInventory().getItemInOffHand().clone(), p.getLocation(), p.getGameMode(), p.getHealth(),
                p.getFoodLevel(), p.getSaturation(), p.getExp(), p.getLevel(), p.getAllowFlight());
    }

    public void restore(Player p) {
        UUID id = p.getUniqueId();
        Saved s = saved.remove(id);
        for (PotionEffect e : p.getActivePotionEffects()) {
            p.removePotionEffect(e.getType());
        }
        plugin.setScale(p, 1.0);
        if (s == null) {
            p.setGameMode(GameMode.SURVIVAL);
            p.teleport(plugin.spawnLocation());
            return;
        }
        p.getInventory().setContents(s.contents());
        p.getInventory().setArmorContents(s.armor());
        p.getInventory().setItemInOffHand(s.offhand());
        p.setGameMode(s.mode());
        p.setAllowFlight(s.flight());
        p.setHealth(Math.min(s.health(), p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()));
        p.setFoodLevel(s.food());
        p.setSaturation(s.saturation());
        p.setExp(s.exp());
        p.setLevel(s.level());
        p.teleport(s.loc());
    }

    protected void resetPlayer(Player p, GameMode mode) {
        p.getInventory().clear();
        p.getInventory().setArmorContents(new ItemStack[4]);
        p.getInventory().setItemInOffHand(null);
        p.setGameMode(mode);
        for (PotionEffect e : p.getActivePotionEffects()) {
            p.removePotionEffect(e.getType());
        }
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setExp(0f);
        p.setLevel(0);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setAllowFlight(false);
    }

    protected void eliminate(Player victim, Player killer, String reason) {
        UUID id = victim.getUniqueId();
        if (!alive.remove(id)) {
            return;
        }
        if (killer != null && !killer.equals(victim)) {
            bc("&c" + victim.getName() + " &7dikalahkan oleh &e" + killer.getName());
        } else {
            bc("&c" + victim.getName() + " &7" + reason);
        }
        victim.getInventory().clear();
        victim.teleport(specSpawn());
        victim.setGameMode(GameMode.SPECTATOR);
        Msg.title(victim, "&c&lTERSINGKIR", "&7Posisi: &f" + (alive.size() + 1), 5, 40, 10);
        checkWin();
    }

    protected Player lastHitter(UUID victim) {
        UUID att = lastHit.get(victim);
        Long t = lastHitAt.get(victim);
        if (att == null || t == null || System.currentTimeMillis() - t > 12000) {
            return null;
        }
        Player p = Bukkit.getPlayer(att);
        return p != null && players.contains(att) ? p : null;
    }

    /* ---------------- damage ---------------- */

    public void onDamage(EntityDamageEvent e, Player victim, Player attacker) {
        UUID vid = victim.getUniqueId();
        if (state != State.RUNNING || !alive.contains(vid)) {
            e.setCancelled(true);
            return;
        }
        EntityDamageEvent.DamageCause cause = e.getCause();
        if (cause == EntityDamageEvent.DamageCause.VOID) {
            e.setCancelled(true);
            onOut(victim, lastHitter(vid), "jatuh ke void");
            return;
        }
        if (cause == EntityDamageEvent.DamageCause.FALL && !fallDamage) {
            e.setCancelled(true);
            return;
        }
        if (attacker == null && (cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                || cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION)) {
            attacker = nearestAlive(victim, 12.0);
        }
        if (attacker != null) {
            if (attacker.equals(victim) && !pvp) {
                e.setCancelled(true);
                return;
            }
            if (!attacker.equals(victim)) {
                if (!alive.contains(attacker.getUniqueId())) {
                    e.setCancelled(true);
                    return;
                }
                lastHit.put(vid, attacker.getUniqueId());
                lastHitAt.put(vid, System.currentTimeMillis());
                if (!pvp) {
                    onHit(e, victim, attacker);
                    return;
                }
            }
        } else if (!envDamage) {
            e.setCancelled(true);
            return;
        }
        if (!e.isCancelled() && victim.getHealth() - e.getFinalDamage() <= 0) {
            if (hasTotem(victim)) {
                return; // biarkan totem aktif
            }
            e.setCancelled(true);
            onOut(victim, lastHitter(vid), "tewas");
        }
    }

    protected static boolean hasTotem(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    protected Player nearestAlive(Player from, double radius) {
        Player best = null;
        double bestD = radius * radius;
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || p.equals(from) || p.getWorld() != from.getWorld()) {
                continue;
            }
            double d = p.getLocation().distanceSquared(from.getLocation());
            if (d <= bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    /** Called by the listener when a player died anyway (e.g. damage that was not intercepted). */
    public void playerDied(Player p) {
        if (state == State.RUNNING && alive.contains(p.getUniqueId())) {
            onOut(p, lastHitter(p.getUniqueId()), "tewas");
        } else if (state == State.WAITING || state == State.COUNTDOWN) {
            p.teleport(lobby());
        } else {
            p.teleport(specSpawn());
        }
    }

    /** Default explosion rule: only blocks placed by players can be destroyed. */
    public void onExplode(org.bukkit.event.entity.EntityExplodeEvent e) {
        e.blockList().removeIf(b -> !placed.contains(key(b)));
        for (Block b : e.blockList()) {
            placed.remove(key(b));
        }
    }

    public void invite(Player inviter, Player target) {
        if (!joinable()) {
            Msg.send(inviter, "&cGame ini tidak bisa dimasuki sekarang.");
            return;
        }
        if (target == null || target.equals(inviter)) {
            return;
        }
        if (manager.of(target) != null) {
            Msg.send(inviter, "&c" + target.getName() + " sedang bermain.");
            return;
        }
        long now = System.currentTimeMillis();
        long left = 30000L - (now - inviteCd.getOrDefault(inviter.getUniqueId(), 0L));
        if (left > 0) {
            Msg.send(inviter, "&cTunggu &f" + (left / 1000 + 1) + "s &cuntuk mengundang lagi.");
            return;
        }
        inviteCd.put(inviter.getUniqueId(), now);
        manager.recordInvite(target, inviter);
        net.kyori.adventure.text.Component msg = Msg.c(Msg.PREFIX + "&e" + inviter.getName() + " &7mengundangmu ke &b" + name + "&7! ")
                .append(Msg.c("&a&l[GABUNG]").clickEvent(
                        net.kyori.adventure.text.event.ClickEvent.runCommand("/zm accept " + inviter.getUniqueId())));
        target.sendMessage(msg);
        Msg.send(inviter, "&aUndangan dikirim ke &f" + target.getName() + "&a.");
    }

    protected void spreadRing(List<Player> list, double radius, int y) {
        int n = Math.max(1, list.size());
        for (int i = 0; i < list.size(); i++) {
            double a = Math.PI * 2 * i / n;
            double x = cx + 0.5 + Math.cos(a) * radius;
            double z = cz + 0.5 + Math.sin(a) * radius;
            Location l = new Location(world, x, y, z);
            l.setDirection(new org.bukkit.util.Vector(cx + 0.5 - x, 0, cz + 0.5 - z));
            list.get(i).teleport(l);
        }
    }

    protected List<Player> aliveWhere(java.util.function.Predicate<UUID> pred) {
        List<Player> list = new ArrayList<>();
        for (UUID id : alive) {
            if (!pred.test(id)) {
                continue;
            }
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                list.add(p);
            }
        }
        return list;
    }

    protected void fireworkAt(Location loc) {
        org.bukkit.entity.Firework fw = loc.getWorld().spawn(loc, org.bukkit.entity.Firework.class);
        org.bukkit.inventory.meta.FireworkMeta meta = fw.getFireworkMeta();
        meta.addEffect(org.bukkit.FireworkEffect.builder()
                .with(org.bukkit.FireworkEffect.Type.BALL_LARGE)
                .withColor(org.bukkit.Color.AQUA, org.bukkit.Color.WHITE)
                .withFade(org.bukkit.Color.YELLOW)
                .build());
        meta.setPower(1);
        fw.setFireworkMeta(meta);
    }

    /* ---------------- helpers ---------------- */

    protected List<Player> alivePlayers() {
        List<Player> list = new ArrayList<>();
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                list.add(p);
            }
        }
        return list;
    }

    protected List<Player> online() {
        List<Player> list = new ArrayList<>();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                list.add(p);
            }
        }
        return list;
    }

    protected void bc(String text) {
        for (Player p : online()) {
            Msg.send(p, text);
        }
    }

    protected void sound(org.bukkit.Sound s, float vol, float pitch) {
        for (Player p : online()) {
            p.playSound(p.getLocation(), s, vol, pitch);
        }
    }

    protected ItemStack item(Material m, int n, String name, String... lore) {
        ItemStack stack = new ItemStack(m, n);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Msg.c(name));
        List<net.kyori.adventure.text.Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(Msg.c(s));
        }
        meta.lore(l);
        stack.setItemMeta(meta);
        return stack;
    }

    public static String fmtTime(int sec) {
        return (sec / 60) + ":" + String.format("%02d", sec % 60);
    }

    /** Sends the sidebar lines for this game. */
    public List<String> sidebarLines(Player player) {
        List<String> lines = new ArrayList<>();
        lines.add("&8" + id());
        lines.add(" ");
        lines.add("&fStatus &8» &e" + state.name());
        lines.add("&fPemain &8» &a" + players.size() + "/" + max);
        lines.addAll(sideExtra());
        lines.add(" ");
        lines.add("&b/zm leave &7= keluar");
        return lines;
    }

    protected abstract static class Unused {
    }
}
