package id.zentra.minigames;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public final class ZentraMinigames extends JavaPlugin implements Listener {

    private GameManager manager;
    private final NamespacedKey itemKey = new NamespacedKey(this, "lobby_item");
    private final File dataFile = new File(getDataFolder(), "data.yml");
    private YamlConfiguration data;
    private final Deque<String> winQueue = new ArrayDeque<>();
    private BossBar winBar;
    private int winTicks;
    private final java.util.Map<java.util.UUID, Sidebar> sidebars = new java.util.HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        manager = new GameManager(this);
        winBar = Bukkit.createBossBar("", BarColor.YELLOW, BarStyle.SOLID);
        getServer().getPluginManager().registerEvents(new GameListener(this, manager), this);
        getServer().getPluginManager().registerEvents(this, this);
        MinigamesCommand cmd = new MinigamesCommand(this, manager);
        getCommand("zm").setExecutor(cmd);
        getCommand("zm").setTabCompleter(cmd);
        new BukkitRunnable() {
            @Override
            public void run() {
                tickWin();
            }
        }.runTaskTimer(this, 0L, 5L);
        new BukkitRunnable() {
            int tries;

            @Override
            public void run() {
                World w = Bukkit.getWorld(worldName());
                if (w == null) {
                    if (++tries > 30) {
                        cancel();
                        getLogger().severe("World '" + worldName() + "' tidak ditemukan!");
                    }
                    return;
                }
                cancel();
                applyGameRules(w);
                manager.init(w);
            }
        }.runTaskTimer(this, 60L, 100L);
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
        winBar.removeAll();
        winQueue.clear();
    }

    public GameManager manager() {
        return manager;
    }

    public String worldName() {
        return getConfig().getString("world", "pvp");
    }

    public int blocksPerTick() {
        return getConfig().getInt("build.blocks-per-tick", 4000);
    }

    public Location spawnLocation() {
        World w = Bukkit.getWorld(worldName());
        return w != null ? w.getSpawnLocation() : Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    private void tryRule(String label, Runnable r) {
        try {
            r.run();
        } catch (Throwable t) { // NoSuchFieldError dll. di versi server yang mengubah GameRule
            getLogger().warning("Gamerule " + label + " dilewati: " + t);
        }
    }

    /**
     * Pengaturan world minigame saja (world lain / Multiverse tidak disentuh).
     * Matikan lewat gamerules.apply: false di config.yml bila ingin mengatur gamerule sendiri.
     */
    public void applyGameRules(World w) {
        if (getConfig().getBoolean("gamerules.apply", true)) {
            tryRule("doFireTick", () -> w.setGameRule(org.bukkit.GameRule.DO_FIRE_TICK, false));
            tryRule("doMobSpawning", () -> w.setGameRule(org.bukkit.GameRule.DO_MOB_SPAWNING, false));
            tryRule("doDaylightCycle", () -> w.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false));
            tryRule("doWeatherCycle", () -> w.setGameRule(org.bukkit.GameRule.DO_WEATHER_CYCLE, false));
            tryRule("keepInventory", () -> w.setGameRule(org.bukkit.GameRule.KEEP_INVENTORY, true));
            tryRule("doImmediateRespawn", () -> w.setGameRule(org.bukkit.GameRule.DO_IMMEDIATE_RESPAWN, true));
            tryRule("showDeathMessages", () -> w.setGameRule(org.bukkit.GameRule.SHOW_DEATH_MESSAGES, false));
            tryRule("doInsomnia", () -> w.setGameRule(org.bukkit.GameRule.DO_INSOMNIA, false));
            tryRule("doPatrolSpawning", () -> w.setGameRule(org.bukkit.GameRule.DO_PATROL_SPAWNING, false));
            tryRule("doTraderSpawning", () -> w.setGameRule(org.bukkit.GameRule.DO_TRADER_SPAWNING, false));
            tryRule("doTileDrops", () -> w.setGameRule(org.bukkit.GameRule.DO_TILE_DROPS, false));
            w.setTime(6000L);
        }
        enforceWorld(w);
        for (String cmd : getConfig().getStringList("hooks.on-init")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
        for (String name : new String[]{"WorldGuard", "Multiverse-Core", "FastAsyncWorldEdit", "WorldEdit"}) {
            if (Bukkit.getPluginManager().getPlugin(name) != null) {
                getLogger().info("Terdeteksi " + name + ": pemain di dalam game dikendalikan aturan game "
                        + "(compat.force-pvp). Flag/pengaturan world lain tidak diubah.");
            }
        }
    }

    /** Dipanggil berkala: pastikan PvP aktif dan world tidak Peaceful (bot butuh mob) walau Multiverse mengubahnya. */
    public void enforceWorld(World w) {
        if (!getConfig().getBoolean("compat.force-pvp", true)) {
            return;
        }
        if (!w.getPVP()) {
            w.setPVP(true);
        }
        if (w.getDifficulty() == org.bukkit.Difficulty.PEACEFUL) {
            w.setDifficulty(org.bukkit.Difficulty.NORMAL);
        }
    }

    public String colorize(String s) {
        return s == null ? "" : s.replace('&', '\u00a7');
    }

    /* ---------------- win announcements ---------------- */

    public void announceWin(String winner, String label) {
        winQueue.add("&6&l\u2605 &e" + winner + " &a&lWIN &f" + label + " &6&l\u2605");
    }

    private void tickWin() {
        if (winTicks > 0) {
            winTicks -= 5;
            winBar.setProgress(Math.max(0, Math.min(1, winTicks / 100.0)));
            if (winTicks <= 0) {
                winBar.removeAll();
            }
            return;
        }
        String next = winQueue.poll();
        if (next == null) {
            return;
        }
        winBar.setTitle(colorize(next));
        winBar.setProgress(1.0);
        for (Player p : Bukkit.getOnlinePlayers()) {
            winBar.addPlayer(p);
        }
        winTicks = 100;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        winBar.addPlayer(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        winBar.removePlayer(e.getPlayer());
    }

    /* ---------------- sidebar ---------------- */

    public void sidebar(Player p, Game g) {
        Sidebar s = sidebars.computeIfAbsent(p.getUniqueId(), k -> new Sidebar());
        s.setTitle("&6&lZENTRA");
        s.setLines(g.sidebarLines(p));
        s.show(p);
    }

    public void clearSidebar(Player p) {
        Sidebar s = sidebars.remove(p.getUniqueId());
        if (s != null) {
            s.hide(p);
        }
    }

    /* ---------------- data ---------------- */

    private void loadData() {
        getDataFolder().mkdirs();
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Gagal menyimpan data.yml: " + ex.getMessage());
        }
    }

    public YamlConfiguration data() {
        return data;
    }

    /* ---------------- items ---------------- */

    public void setScale(Player p, double value) {
        var attr = p.getAttribute(Attribute.SCALE);
        if (attr != null && attr.getBaseValue() != value) {
            attr.setBaseValue(value);
        }
    }

    public ItemStack lobbyItem(Material material, String name, String id, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Msg.c(name));
        List<net.kyori.adventure.text.Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(Msg.c(s));
        }
        meta.lore(l);
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack leaveItem() {
        return lobbyItem(Material.RED_DYE, "&c&lKeluar &7(klik kanan)", "leave", "&7Kembali ke tempat semula");
    }

    public String itemId(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }
}
