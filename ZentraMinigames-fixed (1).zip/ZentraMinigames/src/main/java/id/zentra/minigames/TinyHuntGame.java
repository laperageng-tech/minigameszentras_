package id.zentra.minigames;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Tiny Hunt: pelarian menyusut dan bersembunyi di kota mainan, pemburu mencari. */
public final class TinyHuntGame extends Game {

    private static final int HALF = 22;

    private final Set<UUID> seekers = new HashSet<>();
    private final Map<UUID, Long> radarCd = new HashMap<>();
    private int phase;
    private int timer;

    public TinyHuntGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "tinyhunt", "Tiny Hunt: Kota Mainan", Material.SPYGLASS, instance, cx, by, cz, 3, 16, List.of(
                "Pelarian menyusut jadi mungil dan bersembunyi, Pemburu mencari!",
                "Pelarian bisa menyelinap lewat lubang 1 blok di rumah mainan. Pemburu tidak muat!",
                "Pemburu buta 25 detik di awal. Kompas Radar menunjukkan arah pelarian terdekat (jeda 15 detik).",
                "Pelarian punya 1 Bom Asap (kecepatan kilat). Tiap 30 detik semua pelarian berpendar sesaat.",
                "Pelarian menang kalau ada yang bertahan 3 menit. Pemburu menang kalau semua tertangkap."));
        this.voidY = by - 10;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 1, cz, 30, 18, Material.DIRT);
        bp.fill(cx - HALF, by, cz - HALF, cx + HALF, by, cz + HALF, Material.MOSS_BLOCK);
        bp.fill(cx - HALF, by, cz - 1, cx + HALF, by, cz + 1, Material.GRAY_CONCRETE);
        bp.fill(cx - 1, by, cz - HALF, cx + 1, by, cz + HALF, Material.GRAY_CONCRETE);
        bp.disc(cx, by, cz, 5, Material.QUARTZ_BLOCK);
        bp.disc(cx, by, cz, 2, Material.GOLD_BLOCK);
        Material glass = Material.LIGHT_BLUE_STAINED_GLASS;
        bp.fill(cx - HALF - 1, by + 1, cz - HALF - 1, cx + HALF + 1, by + 8, cz - HALF - 1, glass);
        bp.fill(cx - HALF - 1, by + 1, cz + HALF + 1, cx + HALF + 1, by + 8, cz + HALF + 1, glass);
        bp.fill(cx - HALF - 1, by + 1, cz - HALF - 1, cx - HALF - 1, by + 8, cz + HALF + 1, glass);
        bp.fill(cx + HALF + 1, by + 1, cz - HALF - 1, cx + HALF + 1, by + 8, cz + HALF + 1, glass);

        Random r = new Random(777L + instance * 31L);
        Material[] wall = {Material.RED_TERRACOTTA, Material.YELLOW_TERRACOTTA, Material.LIGHT_BLUE_CONCRETE, Material.PINK_CONCRETE,
                Material.ORANGE_CONCRETE, Material.LIME_CONCRETE, Material.PURPLE_CONCRETE, Material.WHITE_CONCRETE};
        for (int i = 0; i < 26; i++) {
            int w = 4 + r.nextInt(4);
            int d = 4 + r.nextInt(4);
            int h = 3 + r.nextInt(5);
            int x = cx - HALF + 3 + r.nextInt(34);
            int z = cz - HALF + 3 + r.nextInt(34);
            if ((Math.abs(x - cx) < 8 && Math.abs(z - cz) < 8) || Math.abs(x + w / 2 - cx) < 4 || Math.abs(z + d / 2 - cz) < 4) {
                continue;
            }
            Material m = wall[r.nextInt(wall.length)];
            bp.box(x, by + 1, z, x + w - 1, by + h, z + d - 1, m);
            bp.set(x + w / 2, by + 1, z, Material.AIR); // lubang 1 blok
            bp.fill(x, by + h + 1, z, x + w - 1, by + h + 1, z + d - 1, Material.SMOOTH_QUARTZ_SLAB);
        }
        for (int i = 0; i < 12; i++) {
            int x = cx - HALF + 3 + r.nextInt(38);
            int z = cz - HALF + 3 + r.nextInt(38);
            if ((Math.abs(x - cx) < 6 && Math.abs(z - cz) < 6) || Math.abs(x - cx) < 3 || Math.abs(z - cz) < 3) {
                continue;
            }
            int h = 3 + r.nextInt(2);
            bp.fill(x, by + 1, z, x, by + h, z, Material.MUSHROOM_STEM);
            bp.disc(x, by + h + 1, z, 2, Material.RED_MUSHROOM_BLOCK);
        }
        for (int i = 0; i < 10; i++) {
            int x = cx - HALF + 3 + r.nextInt(38);
            int z = cz - HALF + 3 + r.nextInt(38);
            if ((Math.abs(x - cx) < 6 && Math.abs(z - cz) < 6) || Math.abs(x - cx) < 3 || Math.abs(z - cz) < 3) {
                continue;
            }
            int h = 5 + r.nextInt(3);
            bp.fill(x, by + 1, z, x, by + h, z, Material.OAK_LOG);
            bp.fill(x - 2, by + h - 1, z - 2, x + 2, by + h, z + 2, Material.OAK_LEAVES);
            bp.fill(x - 1, by + h + 1, z - 1, x + 1, by + h + 1, z + 1, Material.OAK_LEAVES);
        }
    }

    private Location randomSpot() {
        for (int i = 0; i < 30; i++) {
            int x = cx - HALF + 2 + rnd.nextInt(41);
            int z = cz - HALF + 2 + rnd.nextInt(41);
            if (world.getBlockAt(x, by + 1, z).isEmpty() && world.getBlockAt(x, by + 2, z).isEmpty()
                    && world.getBlockAt(x, by, z).getType().isSolid()) {
                return new Location(world, x + 0.5, by + 1, z + 0.5);
            }
        }
        return new Location(world, cx + 0.5, by + 1, cz + 7.5);
    }

    @Override
    protected void onStart() {
        seekers.clear();
        radarCd.clear();
        List<Player> list = alivePlayers();
        Collections.shuffle(list, rnd);
        int n = Math.max(1, list.size() / 5);
        for (int i = 0; i < list.size(); i++) {
            Player p = list.get(i);
            if (i < n) {
                seekers.add(p.getUniqueId());
                p.teleport(new Location(world, cx + 0.5, by + 1, cz + 0.5));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 520, 0, false, false));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 520, 9, false, false));
                Msg.title(p, "&c&lPEMBURU", "&7Tunggu 25 detik, lalu buru mereka!", 5, 60, 10);
            } else {
                plugin.setScale(p, 0.4);
                p.teleport(randomSpot());
                p.getInventory().setItem(0, item(Material.GUNPOWDER, 1, "&7&lBom Asap", "&7Klik kanan: kecepatan kilat 5 detik"));
                Msg.title(p, "&a&lPELARIAN", "&7Kamu mungil! Sembunyi 25 detik!", 5, 60, 10);
            }
        }
        phase = 0;
        timer = 25;
    }

    @Override
    protected void onSecond() {
        timer--;
        if (phase == 0) {
            if (timer <= 0) {
                releaseSeekers();
            }
            return;
        }
        if (timer <= 0) {
            end(aliveWhere(id -> !seekers.contains(id)));
            return;
        }
        if (timer % 30 == 0) {
            bc("&e&lPULSE! &fSemua pelarian berpendar sesaat!");
            for (Player p : aliveWhere(id -> !seekers.contains(id))) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false));
            }
        }
    }

    private void releaseSeekers() {
        phase = 1;
        timer = 180;
        for (Player p : aliveWhere(seekers::contains)) {
            p.removePotionEffect(PotionEffectType.BLINDNESS);
            p.removePotionEffect(PotionEffectType.SLOWNESS);
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 3600, 0, false, false));
            p.getInventory().setItem(0, item(Material.IRON_SWORD, 1, "&c&lPedang Pemburu"));
            p.getInventory().setItem(1, item(Material.COMPASS, 1, "&b&lRadar", "&7Klik kanan: arah pelarian terdekat"));
            Msg.title(p, "&c&lBURU MEREKA!", "&7Pelarian menang jika bertahan 3 menit", 5, 40, 10);
        }
        bc("&cPara pemburu sudah dilepas! &7Waktu: 3 menit.");
        sound(Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
    }

    @Override
    protected void onHit(EntityDamageEvent e, Player victim, Player attacker) {
        e.setCancelled(true);
        if (phase != 1) {
            return;
        }
        if (seekers.contains(attacker.getUniqueId()) && !seekers.contains(victim.getUniqueId())) {
            plugin.setScale(victim, 1.0);
            eliminate(victim, attacker, "tertangkap");
        }
    }

    @Override
    protected void onInteract(PlayerInteractEvent e) {
        if (state != State.RUNNING) {
            return;
        }
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack stack = e.getItem();
        Player p = e.getPlayer();
        if (stack == null || !alive.contains(p.getUniqueId())) {
            return;
        }
        boolean seeker = seekers.contains(p.getUniqueId());
        if (stack.getType() == Material.GUNPOWDER && !seeker) {
            e.setCancelled(true);
            stack.setAmount(stack.getAmount() - 1);
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2));
            world.spawnParticle(Particle.CLOUD, p.getLocation().add(0, 0.3, 0), 30, 0.3, 0.2, 0.3, 0.02);
            p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXTINGUISH_FIRE, 1.0f, 1.0f);
        } else if (stack.getType() == Material.COMPASS && seeker && phase == 1) {
            e.setCancelled(true);
            long now = System.currentTimeMillis();
            long left = 15000L - (now - radarCd.getOrDefault(p.getUniqueId(), 0L));
            if (left > 0) {
                Msg.bar(p, "&cRadar isi ulang &f" + (left / 1000 + 1) + "s");
                return;
            }
            Player nearest = null;
            double best = Double.MAX_VALUE;
            for (Player t : aliveWhere(id -> !seekers.contains(id))) {
                double d = t.getLocation().distanceSquared(p.getLocation());
                if (d < best) {
                    best = d;
                    nearest = t;
                }
            }
            if (nearest == null) {
                return;
            }
            radarCd.put(p.getUniqueId(), now);
            double dx = nearest.getX() - p.getX();
            double dz = nearest.getZ() - p.getZ();
            double ang = Math.toDegrees(Math.atan2(-dx, dz)) - p.getLocation().getYaw();
            while (ang > 180.0) {
                ang -= 360.0;
            }
            while (ang < -180.0) {
                ang += 360.0;
            }
            String[] arrows = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
            int idx = (int) Math.round(ang / 45.0);
            String arrow = arrows[((idx % 8) + 8) % 8];
            Msg.bar(p, "&bRadar: pelarian terdekat &f" + (int) Math.sqrt(best) + "m &e" + arrow);
            p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
        }
    }

    @Override
    protected void checkWin() {
        if (state != State.RUNNING) {
            return;
        }
        long runners = alive.stream().filter(id -> !seekers.contains(id)).count();
        long hunters = alive.size() - runners;
        if (runners == 0) {
            end(aliveWhere(seekers::contains));
        } else if (hunters == 0) {
            end(aliveWhere(id -> !seekers.contains(id)));
        }
    }

    @Override
    protected void onEnd() {
        for (Player p : online()) {
            plugin.setScale(p, 1.0);
            p.removePotionEffect(PotionEffectType.BLINDNESS);
            p.removePotionEffect(PotionEffectType.SLOWNESS);
        }
    }

    @Override
    protected void onReset() {
        seekers.clear();
        radarCd.clear();
    }

    @Override
    protected String barText() {
        long runners = alive.stream().filter(id -> !seekers.contains(id)).count();
        return phase == 0
                ? "&aSembunyi! &8| &fPemburu dilepas dalam &e" + timer + "s"
                : "&6Tiny Hunt &8| &fPelarian: &a" + runners + " &8| &fSisa waktu: &e" + timer + "s";
    }

    @Override
    protected List<String> sideExtra() {
        long runners = alive.stream().filter(id -> !seekers.contains(id)).count();
        return List.of("&fPelarian &8\u00bb &a" + runners, "&fPemburu &8\u00bb &c" + (alive.size() - runners), "&fWaktu &8\u00bb &e" + timer + "s");
    }
}
