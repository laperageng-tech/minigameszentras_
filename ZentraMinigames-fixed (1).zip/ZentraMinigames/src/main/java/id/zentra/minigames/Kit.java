package id.zentra.minigames;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;
import org.bukkit.Registry;

/** Practice / duel kits. Every piece of gear is fully enchanted. */
public enum Kit {
    CRYSTAL("Crystal PvP", "&d", Material.END_CRYSTAL),
    MACE("Mace", "&6", Material.MACE),
    SWORD("Sword", "&b", Material.DIAMOND_SWORD),
    NODEBUFF("NoDebuff", "&c", Material.SPLASH_POTION);

    public final String display;
    public final String color;
    private final Material icon;

    Kit(String display, String color, Material icon) {
        this.display = display;
        this.color = color;
        this.icon = icon;
    }

    public static Kit parse(String raw) {
        if (raw == null) {
            return null;
        }
        return switch (raw.toLowerCase(java.util.Locale.ROOT)) {
            case "crystal", "crystalpvp", "cpvp", "crystal_pvp" -> CRYSTAL;
            case "mace" -> MACE;
            case "sword", "sw" -> SWORD;
            case "nodebuff", "nd", "debuff" -> NODEBUFF;
            default -> null;
        };
    }

    public String label() {
        return color + "&l" + display;
    }

    public ItemStack icon() {
        return new ItemStack(icon);
    }

    /** Gives this kit to the player. Inventory is cleared first. */
    public void give(Player player) {
        PlayerInventory inv = player.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(null);
        switch (this) {
            case CRYSTAL -> giveCrystal(inv);
            case MACE -> giveMace(inv);
            case SWORD -> giveSword(inv);
            case NODEBUFF -> giveNoDebuff(inv);
        }
    }

    private static void giveCrystal(PlayerInventory inv) {
        armor(inv, Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS);
        inv.setItem(0, enchanted(Material.NETHERITE_SWORD, 1, "&d&lCrystal Blade",
                "sharpness", 5, "unbreaking", 3, "fire_aspect", 2, "looting", 3, "sweeping_edge", 3));
        inv.setItem(1, item(Material.END_CRYSTAL, 64, "&d&lEnd Crystal"));
        inv.setItem(2, item(Material.OBSIDIAN, 64, "&8Obsidian"));
        inv.setItem(3, item(Material.GOLDEN_APPLE, 16, "&6Golden Apple"));
        inv.setItem(4, item(Material.ENDER_PEARL, 16, "&3Ender Pearl"));
        inv.setItem(5, item(Material.END_CRYSTAL, 64, "&d&lEnd Crystal"));
        inv.setItem(6, item(Material.OBSIDIAN, 64, "&8Obsidian"));
        inv.setItem(9, item(Material.TOTEM_OF_UNDYING, 1, "&e&lTotem"));
        inv.setItem(10, item(Material.TOTEM_OF_UNDYING, 1, "&e&lTotem"));
        inv.setItem(11, item(Material.TOTEM_OF_UNDYING, 1, "&e&lTotem"));
        inv.setItemInOffHand(item(Material.TOTEM_OF_UNDYING, 1, "&e&lTotem"));
    }

    private static void giveMace(PlayerInventory inv) {
        armor(inv, Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS);
        inv.setItem(0, enchanted(Material.MACE, 1, "&6&lMace",
                "density", 5, "breach", 4, "wind_burst", 3, "unbreaking", 3));
        inv.setItem(1, enchanted(Material.DIAMOND_AXE, 1, "&bAxe",
                "sharpness", 5, "unbreaking", 3, "efficiency", 5));
        inv.setItem(2, item(Material.WIND_CHARGE, 64, "&f&lWind Charge"));
        inv.setItem(3, item(Material.GOLDEN_APPLE, 16, "&6Golden Apple"));
        inv.setItem(4, item(Material.ENDER_PEARL, 8, "&3Ender Pearl"));
        inv.setItemInOffHand(enchanted(Material.SHIELD, 1, "&7Shield", "unbreaking", 3));
    }

    private static void giveSword(PlayerInventory inv) {
        armor(inv, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS);
        inv.setItem(0, enchanted(Material.DIAMOND_SWORD, 1, "&b&lSword",
                "sharpness", 5, "unbreaking", 3, "fire_aspect", 2, "looting", 3, "sweeping_edge", 3));
        inv.setItem(1, item(Material.GOLDEN_APPLE, 8, "&6Golden Apple"));
        inv.setItem(2, item(Material.ENDER_PEARL, 4, "&3Ender Pearl"));
        inv.setItemInOffHand(enchanted(Material.SHIELD, 1, "&7Shield", "unbreaking", 3));
    }

    private static void giveNoDebuff(PlayerInventory inv) {
        armor(inv, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS);
        inv.setItem(0, enchanted(Material.DIAMOND_SWORD, 1, "&c&lNoDebuff Sword",
                "sharpness", 5, "unbreaking", 3, "fire_aspect", 2, "looting", 3, "sweeping_edge", 3));
        inv.setItem(1, item(Material.ENDER_PEARL, 16, "&3Ender Pearl"));
        inv.setItem(2, potion(Material.POTION, PotionType.STRONG_SWIFTNESS, 1, "&bSwiftness"));
        for (int slot = 9; slot <= 35; slot++) {
            inv.setItem(slot, potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1, "&dHealing"));
        }
        for (int slot = 3; slot <= 6; slot++) {
            inv.setItem(slot, potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1, "&dHealing"));
        }
    }

    private static void armor(PlayerInventory inv, Material helmet, Material chest, Material legs, Material boots) {
        inv.setHelmet(enchanted(helmet, 1, null, "protection", 4, "unbreaking", 3, "mending", 1));
        inv.setChestplate(enchanted(chest, 1, null, "protection", 4, "unbreaking", 3, "mending", 1));
        inv.setLeggings(enchanted(legs, 1, null, "protection", 4, "unbreaking", 3, "mending", 1));
        inv.setBoots(enchanted(boots, 1, null, "protection", 4, "unbreaking", 3, "mending", 1));
    }

    static ItemStack item(Material material, int amount, String name) {
        ItemStack stack = new ItemStack(material, amount);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null && name != null) {
            meta.displayName(Msg.c(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    static ItemStack potion(Material material, PotionType type, int amount, String name) {
        ItemStack stack = new ItemStack(material, amount);
        if (stack.getItemMeta() instanceof PotionMeta meta) {
            meta.setBasePotionType(type);
            meta.displayName(Msg.c(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Creates an item, applies enchantments given as (key, level) pairs and makes it unbreakable-free. */
    static ItemStack enchanted(Material material, int amount, String name, Object... pairs) {
        ItemStack stack = item(material, amount, name);
        ItemMeta meta = stack.getItemMeta();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            Enchantment ench = enchantment((String) pairs[i]);
            if (ench != null) {
                meta.addEnchant(ench, (Integer) pairs[i + 1], true);
            }
        }
        stack.setItemMeta(meta);
        return stack;
    }

    static Enchantment enchantment(String key) {
        return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key));
    }

    /** Helper used by games that need the kit's main weapon name. */
    public static List<Kit> all() {
        return List.of(values());
    }

    public EquipmentSlot offhandSlot() {
        return EquipmentSlot.OFF_HAND;
    }
}
