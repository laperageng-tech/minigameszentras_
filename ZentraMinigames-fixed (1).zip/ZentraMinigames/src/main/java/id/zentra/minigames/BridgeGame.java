package id.zentra.minigames;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Practice Bridge: dua platform dengan jembatan papan di tengah, duel pedang + blok. */
public final class BridgeGame extends Game {

    public BridgeGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "bridge", "Practice Bridge", Material.OAK_PLANKS, instance, cx, by, cz, 2, 2, List.of(
                "Duel pedang di dua platform yang dihubungkan jembatan papan.",
                "Kamu mendapat blok untuk membangun jembatan atau berlindung.",
                "Dorong lawan ke void. Pemain terakhir menang."));
        this.voidY = by - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 14, cz, 17, 12, Material.BLACKSTONE);
        for (int side : new int[]{-12, 12}) {
            bp.disc(cx + side, by, cz, 7, Material.DEEPSLATE_TILES);
            bp.ring(cx + side, by, cz, 6, 7, Material.POLISHED_BLACKSTONE_BRICKS);
            bp.disc(cx + side, by, cz, 2, Material.CRYING_OBSIDIAN);
        }
        bp.fill(cx - 5, by, cz - 1, cx + 5, by, cz + 1, Material.OAK_PLANKS);
        for (int sx : new int[]{-12, 12}) {
            for (int sz : new int[]{-5, 5}) {
                bp.fill(cx + sx, by + 1, cz + sz, cx + sx, by + 4, cz + sz, Material.CRYING_OBSIDIAN);
                bp.set(cx + sx, by + 5, cz + sz, Material.SEA_LANTERN);
            }
        }
    }

    @Override
    protected void onStart() {
        int i = 0;
        for (Player p : alivePlayers()) {
            boolean left = i++ == 0;
            Location l = new Location(world, cx + (left ? -12 : 12) + 0.5, by + 1, cz + 0.5, left ? -90f : 90f, 0f);
            p.teleport(l);
            Kit.SWORD.give(p);
            p.getInventory().setItem(3, new ItemStack(Material.OAK_PLANKS, 64));
            p.getInventory().setItem(4, new ItemStack(Material.OAK_PLANKS, 64));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 9, false, false));
            Msg.title(p, "&6&lBRIDGE", "&7Jatuhkan lawanmu ke void!", 5, 40, 10);
        }
    }

    @Override
    public void forceStart() {
        if (players.size() >= 2) {
            super.forceStart();
        }
    }

    @Override
    protected String barText() {
        return "&6Practice Bridge &8| &fHidup: &a" + alive.size();
    }
}
