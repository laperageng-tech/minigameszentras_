package id.zentra.minigames;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Bom Estafet: pembawa bom saat sumbu habis akan tersingkir. */
public final class TntTagGame extends Game {

    private final Set<UUID> its = new HashSet<>();
    private final Map<UUID, Long> tagCd = new HashMap<>();
    private int round;
    private int phase;
    private int timer;
    private int roundLen = 30;

    public TntTagGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "tnttag", "Bom Estafet", Material.TNT, instance, cx, by, cz, 3, 16, List.of(
                "Jangan jadi pembawa bom saat sumbunya habis!",
                "Pembawa bom ditandai helm TNT dan efek menyala. Pukul orang lain untuk memindahkan bom.",
                "Setiap ronde pembawa bom meledak dan tersingkir. Ronde makin singkat.",
                "Bom yang baru dioper punya perlindungan 1,5 detik. Bertahan sampai terakhir!"));
        this.voidY = by - 10;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 14, cz, 17, 12, Material.BLACKSTONE);
        bp.disc(cx, by, cz, 17, Material.GRAY_CONCRETE);
        bp.ring(cx, by, cz, 6, 7, Material.ORANGE_CONCRETE);
        bp.ring(cx, by, cz, 11, 12, Material.ORANGE_CONCRETE);
        bp.ring(cx, by, cz, 16, 17, Material.RED_CONCRETE);
        bp.disc(cx, by, cz, 2, Material.YELLOW_CONCRETE);
        bp.set(cx, by + 1, cz, Material.TNT);
        for (int[] d : new int[][]{{9, 0}, {-9, 0}, {0, 9}, {0, -9}}) {
            int x = cx + d[0];
            int z = cz + d[1];
            if (d[0] == 0) {
                bp.fill(x - 2, by + 1, z, x + 2, by + 3, z, Material.POLISHED_BLACKSTONE_BRICKS);
            } else {
                bp.fill(x, by + 1, z - 2, x, by + 3, z + 2, Material.POLISHED_BLACKSTONE_BRICKS);
            }
        }
        for (int[] d : new int[][]{{12, 12}, {-12, 12}, {12, -12}, {-12, -12}}) {
            int x = cx + d[0];
            int z = cz + d[1];
            bp.fill(x, by + 1, z, x, by + 6, z, Material.OBSIDIAN);
            bp.set(x, by + 7, z, Material.SEA_LANTERN);
        }
    }

    @Override
    protected void onStart() {
        its.clear();
        tagCd.clear();
        round = 0;
        phase = 0;
        timer = 5;
        spreadRing(alivePlayers(), 12.0, by + 1);
        bc("&cBom pertama dipilih dalam 5 detik...");
    }

    @Override
    protected void onSecond() {
        timer--;
        if (phase == 0) {
            if (timer <= 0) {
                startRound();
            } else {
                for (Player p : alivePlayers()) {
                    Msg.bar(p, "&eRonde berikutnya dalam &f" + timer + "s");
                }
            }
            return;
        }
        for (Player p : alivePlayers()) {
            if (its.contains(p.getUniqueId())) {
                Msg.bar(p, "&c&lKAMU BOM! &f" + timer + "s &7- pukul orang lain!");
                float pitch = 0.5f + (1.0f - Math.max(0, timer) / (float) roundLen) * 1.5f;
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, pitch);
            } else {
                Msg.bar(p, "&aHindari pembawa bom! &7" + timer + "s");
            }
        }
        if (timer <= 0) {
            explode();
        }
    }

    private void startRound() {
        round++;
        roundLen = Math.max(12, 30 - (round - 1) * 3);
        List<Player> list = alivePlayers();
        Collections.shuffle(list, rnd);
        int n = Math.max(1, list.size() / 4);
        its.clear();
        for (int i = 0; i < n && i < list.size(); i++) {
            setIt(list.get(i), true);
        }
        phase = 1;
        timer = roundLen;
        StringBuilder sb = new StringBuilder();
        for (UUID id : its) {
            String nm = Bukkit.getOfflinePlayer(id).getName();
            sb.append(nm == null ? "?" : nm).append(' ');
        }
        bc("&6Ronde &f" + round + " &6- bom dibawa: &c" + sb.toString().trim() + " &8(" + roundLen + "s)");
        sound(Sound.ENTITY_TNT_PRIMED, 1.0f, 1.0f);
    }

    private void setIt(Player p, boolean bomb) {
        if (bomb) {
            its.add(p.getUniqueId());
            p.getInventory().setHelmet(new ItemStack(Material.TNT));
            p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 1200, 0, false, false));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 1200, 1, false, false));
            Msg.title(p, "&c&lKAMU BOM!", "&7Pukul seseorang!", 0, 30, 10);
        } else {
            its.remove(p.getUniqueId());
            p.getInventory().setHelmet(null);
            p.removePotionEffect(PotionEffectType.GLOWING);
            p.removePotionEffect(PotionEffectType.SPEED);
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 1200, 0, false, false));
        }
    }

    private void explode() {
        List<Player> bombs = new ArrayList<>();
        for (UUID id : new ArrayList<>(its)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                bombs.add(p);
            }
        }
        its.clear();
        for (Player p : bombs) {
            world.spawnParticle(Particle.EXPLOSION_EMITTER, p.getLocation(), 1);
            world.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.0f);
            p.getInventory().setHelmet(null);
            eliminate(p, null, "meledak jadi serpihan");
        }
        if (state == State.RUNNING) {
            for (Player p : alivePlayers()) {
                p.getInventory().setHelmet(null);
                p.removePotionEffect(PotionEffectType.GLOWING);
            }
            phase = 0;
            timer = 4;
        }
    }

    @Override
    protected void onHit(EntityDamageEvent e, Player victim, Player attacker) {
        e.setCancelled(true);
        if (phase != 1) {
            return;
        }
        if (!its.contains(attacker.getUniqueId()) || its.contains(victim.getUniqueId())) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - tagCd.getOrDefault(attacker.getUniqueId(), 0L) < 1500L) {
            return;
        }
        tagCd.put(victim.getUniqueId(), now);
        setIt(attacker, false);
        setIt(victim, true);
        world.playSound(victim.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.6f);
    }

    @Override
    protected void onEnd() {
        its.clear();
    }

    @Override
    protected void onReset() {
        its.clear();
        tagCd.clear();
    }

    @Override
    protected String barText() {
        return "&cBom Estafet &8| &fRonde &e" + round + " &8| &fHidup: &a" + alive.size();
    }

    @Override
    protected List<String> sideExtra() {
        return List.of("&fRonde &8\u00bb &e" + round, "&fHidup &8\u00bb &a" + alive.size(), "&fSumbu &8\u00bb &c" + Math.max(0, timer) + "s");
    }
}
