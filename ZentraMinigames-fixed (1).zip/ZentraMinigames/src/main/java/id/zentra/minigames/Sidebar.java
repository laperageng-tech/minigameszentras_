package id.zentra.minigames;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/** Per-player sidebar. Each line is a team prefix bound to a unique invisible entry. */
public final class Sidebar {

    private static final int MAX_LINES = 15;
    private static final String[] ENTRIES = new String[MAX_LINES];

    static {
        for (int i = 0; i < MAX_LINES; i++) {
            ENTRIES[i] = ChatColor.values()[i].toString() + ChatColor.RESET;
        }
    }

    private final Scoreboard board;
    private final Objective objective;
    private final Team[] teams = new Team[MAX_LINES];

    public Sidebar() {
        board = Bukkit.getScoreboardManager().getNewScoreboard();
        objective = board.registerNewObjective("zm", "dummy", ChatColor.GOLD + "" + ChatColor.BOLD + "ZENTRA");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        for (int i = 0; i < MAX_LINES; i++) {
            teams[i] = board.registerNewTeam("zm" + i);
            teams[i].addEntry(ENTRIES[i]);
            objective.getScore(ENTRIES[i]).setScore(MAX_LINES - i);
        }
    }

    public void setTitle(String title) {
        objective.setDisplayName(ChatColor.translateAlternateColorCodes('&', title));
    }

    /** Sets the visible lines (top to bottom). Extra lines are blanked. */
    public void setLines(List<String> lines) {
        for (int i = 0; i < MAX_LINES; i++) {
            String text = i < lines.size() ? lines.get(i) : "";
            String legacy = ChatColor.translateAlternateColorCodes('&', text);
            if (legacy.length() > 64) {
                legacy = legacy.substring(0, 64);
            }
            teams[i].setPrefix(legacy);
        }
    }

    public void show(Player player) {
        player.setScoreboard(board);
    }

    public void hide(Player player) {
        if (player.getScoreboard() == board) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }
}
