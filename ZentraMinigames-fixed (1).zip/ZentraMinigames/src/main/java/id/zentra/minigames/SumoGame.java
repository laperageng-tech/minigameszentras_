package id.zentra.minigames;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

/** Void Sumo: tangan kosong, pukulan menaikkan "panas" sehingga lawan terpental makin jauh. */
public final class SumoGame extends Game {

    private static final int R = 14;
    private static final int RINGS = 7;

    private int stage;
    private final Map<UUID, Integer> heat = new HashMap<>();

    public SumoGame(ZentraMinigames plugin, GameManager mgr, int instance, int cx, int by, int cz) {
        super(plugin, mgr, "sumo", "Void Sumo", Material.SLIME_BALL, instance, cx, by, cz, 2, 12, List.of(
                "Dorong semua lawan jatuh ke void!",
                "Pukulanmu tidak melukai, tapi menaikkan PANAS lawan. Makin panas, makin jauh terpental.",
                "Tiap 25 detik satu cincin platform runtuh. Ruang gerak makin sempit!",
                "Orang terakhir yang berdiri menang."));
        this.voidY = by - 8;
        this.pvp = false;
        this.envDamage = false;
        this.fallDamage = false;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        Material[] colors = {Material.RED_CONCRETE, Material.ORANGE_CONCRETE, Material.YELLOW_CONCRETE,
                Material.LIME_CONCRETE, Material.CYAN_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.PURPLE_CONCRETE};
        bp.cone(cx, by - 10, cz, 15, 12, Material.DEEPSLATE_BRICKS);
        for (int i = 0; i < RINGS; i++) {
            bp.ring(cx, by, cz, i == RINGS - 1 ? -1 : R - 2 * (i + 1), R - 2 * i, colors[i]);
        }
        for (int[] d : new int[][]{{16, 0}, {-16, 0}, {0, 16}, {0, -16}}) {
            bp.fill(cx + d[0], by - 10, cz + d[1], cx + d[0], by + 9, cz + d[1], Material.CRYING_OBSIDIAN);
            bp.set(cx + d[0], by + 10, cz + d[1], Material.SEA_LANTERN);
        }
        bp.ring(cx, by + 10, cz, 15, 16, Material.AMETHYST_BLOCK);
    }

    @Override
    protected void onStart() {
        heat.clear();
        stage = 0;
        List<Player> list = alivePlayers();
        spreadRing(list, 9.0, by + 1);
        for (Player p : list) {
            p.getInventory().clear(); // tangan kosong, hanya dorongan
        }
        bc("&eCincin luar runtuh tiap 25 detik. Bertahan!");
    }

    @Override
    protected void onHit(EntityDamageEvent e, Player victim, Player attacker) {
        e.setDamage(0.0);
        int h = heat.merge(victim.getUniqueId(), 1, Integer::sum);
        Vector dir = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).setY(0);
        if (dir.lengthSquared() > 0.01) {
            Vector push = dir.normalize().multiply(Math.min(1.6, 0.35 + 0.07 * h)).setY(0.25);
            Bukkit.getScheduler().runTask(plugin, () -> victim.setVelocity(victim.getVelocity().add(push)));
        }
        Msg.bar(victim, "&cPanas: &f" + (h * 8) + "%");
        attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 1.0f);
    }

    @Override
    protected void onSecond() {
        if (stage < RINGS - 1) {
            int n = runSecs % 25;
            if (n == 20) {
                bc("&cPlatform menyusut dalam &f5 &cdetik!");
            }
            if (n == 0 && runSecs > 0) {
                removeRing(stage++);
            }
        }
        if (runSecs >= 240) {
            end(alivePlayers());
        }
    }

    private void removeRing(int n) {
        int inner = R - 2 * (n + 1);
        int outer = R - 2 * n;
        for (int dx = -outer; dx <= outer; dx++) {
            for (int dz = -outer; dz <= outer; dz++) {
                if (!Blueprint.inRing(dx, dz, inner, outer)) {
                    continue;
                }
                Block b = world.getBlockAt(cx + dx, by, cz + dz);
                if (b.getType() == Material.AIR) {
                    continue;
                }
                b.setType(Material.AIR, false);
                if (rnd.nextInt(5) == 0) {
                    world.spawnParticle(Particle.CLOUD, b.getLocation().add(0.5, 1.0, 0.5), 1, 0, 0, 0, 0);
                }
            }
        }
        bc("&6Satu cincin platform runtuh!");
        sound(Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.7f);
    }

    @Override
    protected void onReset() {
        heat.clear();
    }

    @Override
    protected String barText() {
        return "&6Void Sumo &8| &fHidup: &a" + alive.size() + " &8| &fCincin tersisa: &e" + (RINGS - stage);
    }

    @Override
    protected List<String> sideExtra() {
        return List.of("&fHidup &8\u00bb &a" + alive.size(), "&fWaktu &8\u00bb &e" + fmtTime(runSecs));
    }
}
