# ZentraMinigames 1.3.0

Plugin minigames untuk server ZENTRA (Paper 1.21.11, Java 21). Command utama: `/zm`.

## Build otomatis (GitHub Actions)
1. Upload seluruh isi folder ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** → workflow **Build ZentraMinigames** berjalan otomatis.
3. Unduh `ZentraMinigames` dari bagian **Artifacts**, ambil file `ZentraMinigames-1.3.0.jar`, taruh di folder `plugins/`.
4. Push tag `v1.3.0` jika ingin jar otomatis masuk GitHub Release.

Build lokal: `mvn -B clean package` (hasil di `target/`).

## Game
Void Sumo, Bom Estafet, Crumble Run, Color Rush, Pillars of Fortune, Tiny Hunt, Arena Duel (vote kit),
Practice PvP (kit Crystal/Mace/Sword/NoDebuff + bot lawan di arena yang sama), Practice Bridge,
Parkour Sky/Ice/Nether (Classic/Speedrun/Hardcore) dan Parkour 1v1 (vote map + mode).

## Command
`/zm` menu · `/zm join <game>` · `/zm leave` · `/zm list` · `/zm rules <game>` · `/zm practice <kit>` · `/zm bot <mati|mudah|sedang|sulit>`
Admin (`zentra.minigames.admin`): `/zm build <game|all>` · `/zm reload` · `/zm forcestart` · `/zm open|close <game|all>`

## Catatan
- World arena default `pvp` (ubah di `config.yml`). Arena dibangun otomatis saat pertama start; naikkan `build-version` untuk memaksa bangun ulang.
- Bot Practice memakai Husk, tidak muncul bila difficulty Peaceful.

## Kompatibilitas (Paper / Purpur, 1.21.11+)
- **PvP, pasang/hancurkan blok, End Crystal, bot:** untuk pemain yang sedang bermain, keputusan ada di aturan game
  (mode), bukan di flag plugin lain. Bila WorldGuard (`pvp deny`, `build deny`) atau Multiverse (`pvp false`) membatalkan
  event, plugin membatalkan pembatalan itu (`compat.force-pvp: true`). Pemain di luar game tetap dilindungi: blok di
  area arena tidak bisa diubah kecuali admin.
- **World:** hanya world minigame (`world:` di config) yang diatur: PvP dipaksa aktif dan difficulty Peaceful dinaikkan
  ke Normal (bot butuh mob). World lain / pengaturan Multiverse per-world tidak disentuh. Dengan `gamerules.apply: false`
  gamerule pun tidak disentuh.
- **WorldGuard (disarankan, opsional):** region arena dengan flag `pvp allow`, `build allow`, `block-break allow`,
  `block-place allow`, `use allow`, `tnt allow`, `other-explosion allow`, `mob-spawning allow`, `entry allow`.
- **FAWE/WorldEdit:** tidak dibutuhkan. Reset arena memakai pembangun bawaan plugin (bertahap, per tick), jadi tidak
  bentrok dengan FAWE. Arena di koordinat jauh (`arena.x/z`), dan reset hanya menghapus entity milik game
  (item, projectile, crystal, bot), bukan NPC/hologram plugin lain.
