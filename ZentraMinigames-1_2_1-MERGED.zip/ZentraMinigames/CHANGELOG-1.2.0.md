# ZentraMinigames 1.2.0 — Perbaikan semua bug (dari 1.1.0)

## 1. PvP 1v1 / Duel
- FIX: pemain tidak bisa saling serang di arena. Penyebab: `Game.onDamage()` membatalkan semua damage non-PvP dan logika `envDamage` salah. Sekarang PvP damage diteruskan, env damage sesuai flag game.
- FIX: semua kit sekarang FULL ENCHANT (pakai `Kit` yang sama dengan Practice: Crystal = Netherite Prot IV + Sharp V + 128 crystal + 128 obsidian + totem; Mace = Density V; Sword = Prot IV + Sharp III; NoDebuff). Duel sebelumnya pakai iron/diamond tanpa enchant.
- FIX: tidak bisa menaruh obsidian di arena. Sekarang Duel `canBuild=true`, `allowBuildBlocks=true`, `lockInv=false` — obsidian/crystal PvP bisa dipakai.
- FIX: arena tidak otomatis diperbaiki setelah ronde selesai. Sekarang `Game.finish()` memanggil `clearPlacedBlocks()` + `onReset()` lalu rebuild arena via `build()` (antrean GameManager), jadi arena selalu bersih untuk ronde berikutnya.
- Tambahan kit Crystal PvP di vote Duel.

## 2. Sumo
- FIX: tidak lagi pakai stick enchant knockback. Sekarang tangan kosong (inventory dikosongkan), knockback murni dari `onHit` heat system.

## 3. Tiny Hunt
- Diperbaiki & diperkeren ala server terkenal: seeker dapat Speed permanen saat dilepas, radar kompas + efek glow + bom asap pelarian tetap, arena kota mainan dengan lubang 1 blok untuk pelarian mungil (scale 0.4).

## 4. Practice PvP
- FIX: setelah masuk Practice Bot tidak bisa balik ke Practice global. Penyebab: `GameManager.pickKit()` memilih arena berdasarkan `botLevel` dan `setBot()` menolak ganti saat di dalam game. Sekarang: menu kit punya tombol kembali, `/zm practice <kit>` dan klik kit saat sudah di dalam game akan `changeKit` (respawn dengan kit baru) tanpa harus leave; bot level bisa diganti dari menu.
- FIX: tidak bisa menaruh obsidian. `allowPlace` sebelumnya hanya mengizinkan OBSIDIAN untuk kit CRYSTAL saja. Sekarang semua kit bisa menaruh block apa saja (termasuk obsidian untuk Crystal PvP), dengan batas area arena + expiry 20 detik seperti sebelumnya.
- `canBuild=true` sehingga bucket/drop/pickup tidak diblokir.

## 5. Pillars of Fortune
- FIX: tidak bisa saling mukul. `pvp=true` sekarang benar-benar memberi damage (fix di Game.onDamage).
- FIX: pilar tidak lagi diberi block datar 3x3 di atasnya. Sekarang hanya SATU block (gold) sebagai pijakan, sesuai permintaan. Block lain di atas pilar dihapus.

## 6. Block Party (Color Rush)
- Sudah oke, diperkeren: tetap 12 warna, musik/ronde makin cepat, knockback untuk mendorong lawan.

## 7. Block Run (Crumble Run)
- FIX: block hancur terlalu cepat (pending=3 tick). Sekarang pending=8 (jeda ~2 detik) sehingga pemain bisa lari.
- FIX: lapisan ditambah dari 3 menjadi 5 lapis (merah→oranye→kuning→hijau muda→putih).

## 8. TNT Tag
- FIX gamerule: `applyGameRules()` di world arena — DO_FIRE_TICK=false, DO_MOB_SPAWNING=false, MOB_GRIEFING=false, DO_DAYLIGHT_CYCLE=false, DO_WEATHER_CYCLE=false, KEEP_INVENTORY=true, DO_IMMEDIATE_RESPAWN=true, ANNOUNCE_ADVANCEMENTS=false. Tag/bom estafet tetap: helm TNT + glowing, oper bom dengan pukulan, cooldown 1.5s, ronde makin singkat.

## 9. Practice Bridge (BARU)
- Game baru `bridge` (2 instance): dua pulau + jembatan sempit 1 blok di atas void, kit Sword full enchant, building bebas (obsidian boleh), no fall damage, dorong lawan ke void. Terdaftar di menu, config, dan `/zm join bridge`.

## Umum
- Semua game yang boleh build sekarang memakai sistem `placedBlocks` terpusat di `Game` (track + auto-cleanup saat reset), batas tinggi/area agar tidak grief arena lain.
- `build-version` dinaikkan ke 4 agar arena lama dibangun ulang otomatis saat start.
- Tidak ada TODO/placeholder; semua fungsi terimplementasi penuh.

## Verifikasi
- Source didecompile dari JAR 1.1.0 (CFR), diperbaiki, dikompilasi ulang dengan JDK 21 + Paper API 1.21.4, dan dibandingkan dengan JAR asli: semua class utama ada (351→352, +BridgeGame), tidak ada class hilang.
