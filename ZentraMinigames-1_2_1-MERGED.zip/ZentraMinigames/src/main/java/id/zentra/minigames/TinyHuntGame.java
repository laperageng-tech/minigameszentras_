/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class TinyHuntGame
extends Game {
    private static final int HALF = 22;
    private final Set<UUID> seekers = new HashSet<UUID>();
    private final Map<UUID, Long> radarCd = new HashMap<UUID, Long>();
    private int phase;
    private int timer;

    public TinyHuntGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "tinyhunt", "Tiny Hunt: Kota Mainan", Material.SPYGLASS, n, n2, n3, n4, 3, 16, List.of("Pelarian menyusut jadi mungil dan bersembunyi, Pemburu mencari!", "Pelarian bisa menyelinap lewat lubang 1 blok di rumah mainan. Pemburu tidak muat!", "Pemburu buta 25 detik di awal. Kompas Radar menunjukkan arah pelarian terdekat (jeda 15 detik).", "Pelarian punya 1 Bom Asap (kecepatan kilat). Tiap 30 detik semua pelarian berpendar sesaat.", "Pelarian menang kalau ada yang bertahan 3 menit. Pemburu menang kalau semua tertangkap."));
        this.voidY = n3 - 10;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        int n;
        int n2;
        int n3;
        int n4;
        blueprint.cone(this.cx, this.by - 1, this.cz, 30, 18, Material.DIRT);
        blueprint.fill(this.cx - 22, this.by, this.cz - 22, this.cx + 22, this.by, this.cz + 22, Material.MOSS_BLOCK);
        blueprint.fill(this.cx - 22, this.by, this.cz - 1, this.cx + 22, this.by, this.cz + 1, Material.GRAY_CONCRETE);
        blueprint.fill(this.cx - 1, this.by, this.cz - 22, this.cx + 1, this.by, this.cz + 22, Material.GRAY_CONCRETE);
        blueprint.disc(this.cx, this.by, this.cz, 5, Material.QUARTZ_BLOCK);
        blueprint.disc(this.cx, this.by, this.cz, 2, Material.GOLD_BLOCK);
        Material material = Material.LIGHT_BLUE_STAINED_GLASS;
        blueprint.fill(this.cx - 22 - 1, this.by + 1, this.cz - 22 - 1, this.cx + 22 + 1, this.by + 8, this.cz - 22 - 1, material);
        blueprint.fill(this.cx - 22 - 1, this.by + 1, this.cz + 22 + 1, this.cx + 22 + 1, this.by + 8, this.cz + 22 + 1, material);
        blueprint.fill(this.cx - 22 - 1, this.by + 1, this.cz - 22 - 1, this.cx - 22 - 1, this.by + 8, this.cz + 22 + 1, material);
        blueprint.fill(this.cx + 22 + 1, this.by + 1, this.cz - 22 - 1, this.cx + 22 + 1, this.by + 8, this.cz + 22 + 1, material);
        Random random = new Random(777L + (long)this.instance * 31L);
        Material[] materialArray = new Material[]{Material.RED_TERRACOTTA, Material.YELLOW_TERRACOTTA, Material.LIGHT_BLUE_CONCRETE, Material.PINK_CONCRETE, Material.ORANGE_CONCRETE, Material.LIME_CONCRETE, Material.PURPLE_CONCRETE, Material.WHITE_CONCRETE};
        for (n4 = 0; n4 < 26; ++n4) {
            n3 = 4 + random.nextInt(4);
            n2 = 4 + random.nextInt(4);
            n = 3 + random.nextInt(5);
            int n5 = this.cx - 22 + 3 + random.nextInt(34);
            int n6 = this.cz - 22 + 3 + random.nextInt(34);
            if (Math.abs(n5 - this.cx) < 8 && Math.abs(n6 - this.cz) < 8 || Math.abs(n5 + n3 / 2 - this.cx) < 4 || Math.abs(n6 + n2 / 2 - this.cz) < 4) continue;
            Material material2 = materialArray[random.nextInt(materialArray.length)];
            blueprint.box(n5, this.by + 1, n6, n5 + n3 - 1, this.by + n, n6 + n2 - 1, material2);
            blueprint.set(n5 + n3 / 2, this.by + 1, n6, Material.AIR);
            blueprint.fill(n5, this.by + n + 1, n6, n5 + n3 - 1, this.by + n + 1, n6 + n2 - 1, Material.SMOOTH_QUARTZ_SLAB);
        }
        for (n4 = 0; n4 < 12; ++n4) {
            n3 = this.cx - 22 + 3 + random.nextInt(38);
            n2 = this.cz - 22 + 3 + random.nextInt(38);
            if (Math.abs(n3 - this.cx) < 6 && Math.abs(n2 - this.cz) < 6 || Math.abs(n3 - this.cx) < 3 || Math.abs(n2 - this.cz) < 3) continue;
            n = 3 + random.nextInt(2);
            blueprint.fill(n3, this.by + 1, n2, n3, this.by + n, n2, Material.MUSHROOM_STEM);
            blueprint.disc(n3, this.by + n + 1, n2, 2, Material.RED_MUSHROOM_BLOCK);
        }
        for (n4 = 0; n4 < 10; ++n4) {
            n3 = this.cx - 22 + 3 + random.nextInt(38);
            n2 = this.cz - 22 + 3 + random.nextInt(38);
            if (Math.abs(n3 - this.cx) < 6 && Math.abs(n2 - this.cz) < 6 || Math.abs(n3 - this.cx) < 3 || Math.abs(n2 - this.cz) < 3) continue;
            n = 5 + random.nextInt(3);
            blueprint.fill(n3, this.by + 1, n2, n3, this.by + n, n2, Material.OAK_LOG);
            blueprint.fill(n3 - 2, this.by + n - 1, n2 - 2, n3 + 2, this.by + n, n2 + 2, Material.OAK_LEAVES);
            blueprint.fill(n3 - 1, this.by + n + 1, n2 - 1, n3 + 1, this.by + n + 1, n2 + 1, Material.OAK_LEAVES);
        }
    }

    private Location randomSpot() {
        for (int i = 0; i < 30; ++i) {
            int n;
            int n2 = this.cx - 22 + 2 + this.rnd.nextInt(41);
            if (!this.world.getBlockAt(n2, this.by + 1, n = this.cz - 22 + 2 + this.rnd.nextInt(41)).isEmpty() || !this.world.getBlockAt(n2, this.by + 2, n).isEmpty() || !this.world.getBlockAt(n2, this.by, n).getType().isSolid()) continue;
            return new Location(this.world, (double)n2 + 0.5, (double)(this.by + 1), (double)n + 0.5);
        }
        return new Location(this.world, (double)this.cx + 0.5, (double)(this.by + 1), (double)this.cz + 7.5);
    }

    @Override
    protected void onStart() {
        this.seekers.clear();
        this.radarCd.clear();
        List<Player> list = this.alivePlayers();
        Collections.shuffle(list, this.rnd);
        int n = Math.max(1, list.size() / 5);
        for (int i = 0; i < list.size(); ++i) {
            Player player = list.get(i);
            if (i < n) {
                this.seekers.add(player.getUniqueId());
                player.teleport(new Location(this.world, (double)this.cx + 0.5, (double)(this.by + 1), (double)this.cz + 0.5));
                player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 520, 0, false, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 520, 9, false, false));
                Msg.title(player, "&c&lPEMBURU", "&7Tunggu 25 detik, lalu buru mereka!", 5, 60, 10);
                continue;
            }
            this.plugin.setScale(player, 0.4);
            player.teleport(this.randomSpot());
            player.getInventory().setItem(0, this.item(Material.GUNPOWDER, 1, "&7&lBom Asap", "&7Klik kanan: kecepatan kilat 5 detik"));
            Msg.title(player, "&a&lPELARIAN", "&7Kamu mungil! Sembunyi 25 detik!", 5, 60, 10);
        }
        this.phase = 0;
        this.timer = 25;
    }

    @Override
    protected void onSecond() {
        --this.timer;
        if (this.phase == 0) {
            if (this.timer <= 0) {
                this.releaseSeekers();
            }
            return;
        }
        if (this.timer <= 0) {
            this.end(this.aliveWhere(uUID -> !this.seekers.contains(uUID)));
            return;
        }
        if (this.timer % 30 == 0) {
            this.bc("&e&lPULSE! &fSemua pelarian berpendar sesaat!");
            for (Player player : this.aliveWhere(uUID -> !this.seekers.contains(uUID))) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false));
            }
        }
    }

    private void releaseSeekers() {
        this.phase = 1;
        this.timer = 180;
        for (Player player : this.aliveWhere(this.seekers::contains)) {
            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.removePotionEffect(PotionEffectType.SLOWNESS);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 3600, 0, false, false));
            player.getInventory().setItem(0, this.item(Material.IRON_SWORD, 1, "&c&lPedang Pemburu", new String[0]));
            player.getInventory().setItem(1, this.item(Material.COMPASS, 1, "&b&lRadar", "&7Klik kanan: arah pelarian terdekat"));
            Msg.title(player, "&c&lBURU MEREKA!", "&7Pelarian menang jika bertahan 3 menit", 5, 40, 10);
        }
        this.bc("&cPara pemburu sudah dilepas! &7Waktu: 3 menit.");
        this.sound(Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
    }

    @Override
    protected void onHit(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setCancelled(true);
        if (this.phase != 1) {
            return;
        }
        if (this.seekers.contains(player2.getUniqueId()) && !this.seekers.contains(player.getUniqueId())) {
            this.plugin.setScale(player, 1.0);
            this.eliminate(player, player2, "tertangkap");
        }
    }

    @Override
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        if (this.state != Game.State.RUNNING) {
            return;
        }
        Action action = playerInteractEvent.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack itemStack = playerInteractEvent.getItem();
        Player player = playerInteractEvent.getPlayer();
        if (itemStack == null || !this.alive.contains(player.getUniqueId())) {
            return;
        }
        if (itemStack.getType() == Material.GUNPOWDER && !this.seekers.contains(player.getUniqueId())) {
            playerInteractEvent.setCancelled(true);
            itemStack.setAmount(itemStack.getAmount() - 1);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2));
            this.world.spawnParticle(Particle.CLOUD, player.getLocation().add(0.0, 0.3, 0.0), 30, 0.3, 0.2, 0.3, 0.02);
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXTINGUISH_FIRE, 1.0f, 1.0f);
        } else if (itemStack.getType() == Material.COMPASS && this.seekers.contains(player.getUniqueId()) && this.phase == 1) {
            double d;
            double d2;
            playerInteractEvent.setCancelled(true);
            long l = System.currentTimeMillis();
            long l2 = 15000L - (l - this.radarCd.getOrDefault(player.getUniqueId(), 0L));
            if (l2 > 0L) {
                Msg.bar(player, "&cRadar isi ulang &f" + (l2 / 1000L + 1L) + "s");
                return;
            }
            Player player2 = null;
            double d3 = Double.MAX_VALUE;
            for (Player player3 : this.aliveWhere(uUID -> !this.seekers.contains(uUID))) {
                d2 = player3.getLocation().distanceSquared(player.getLocation());
                if (!(d2 < d3)) continue;
                d3 = d2;
                player2 = player3;
            }
            if (player2 == null) {
                return;
            }
            this.radarCd.put(player.getUniqueId(), l);
            double d4 = player2.getX() - player.getX();
            d2 = player2.getZ() - player.getZ();
            for (d = Math.toDegrees(Math.atan2(-d4, d2)) - (double)player.getLocation().getYaw(); d > 180.0; d -= 360.0) {
            }
            while (d < -180.0) {
                d += 360.0;
            }
            String[] stringArray = new String[]{"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
            int n = (int)Math.round(d / 45.0);
            String string = stringArray[(n % 8 + 8) % 8];
            Msg.bar(player, "&bRadar: pelarian terdekat &f" + (int)Math.sqrt(d3) + "m &e" + string);
            player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
        }
    }

    @Override
    protected void checkWin() {
        if (this.state != Game.State.RUNNING) {
            return;
        }
        long l = this.alive.stream().filter(uUID -> !this.seekers.contains(uUID)).count();
        long l2 = (long)this.alive.size() - l;
        if (l == 0L) {
            this.end(this.aliveWhere(this.seekers::contains));
        } else if (l2 == 0L) {
            this.end(this.aliveWhere(uUID -> !this.seekers.contains(uUID)));
        }
    }

    @Override
    protected void onEnd() {
        for (Player player : this.online()) {
            this.plugin.setScale(player, 1.0);
            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.removePotionEffect(PotionEffectType.SLOWNESS);
        }
    }

    @Override
    protected String barText() {
        long l = this.alive.stream().filter(uUID -> !this.seekers.contains(uUID)).count();
        return this.phase == 0 ? "&aSembunyi! &8| &fPemburu dilepas dalam &e" + this.timer + "s" : "&6Tiny Hunt &8| &fPelarian: &a" + l + " &8| &fSisa waktu: &e" + this.timer + "s";
    }
}

