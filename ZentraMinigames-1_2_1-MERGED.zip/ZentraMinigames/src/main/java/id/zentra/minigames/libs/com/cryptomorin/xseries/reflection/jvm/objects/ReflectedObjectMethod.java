/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.AbstractMemberReflectedObject;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import org.jspecify.annotations.NonNull;

final class ReflectedObjectMethod
extends AbstractMemberReflectedObject {
    private final Method delegate;

    ReflectedObjectMethod(Method delegate) {
        this.delegate = delegate;
    }

    @Override
    public @NonNull ReflectedObject.Type type() {
        return ReflectedObject.Type.METHOD;
    }

    @Override
    public @NonNull Method unreflect() {
        return this.delegate;
    }

    @Override
    protected Member member() {
        return this.delegate;
    }
}

