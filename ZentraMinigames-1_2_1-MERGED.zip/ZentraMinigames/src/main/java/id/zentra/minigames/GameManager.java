/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package id.zentra.minigames;

import id.zentra.minigames.ColorRushGame;
import id.zentra.minigames.CrumbleRunGame;
import id.zentra.minigames.DuelGame;
import id.zentra.minigames.Game;
import id.zentra.minigames.Kit;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ParkourGame;
import id.zentra.minigames.ParkourRaceGame;
import id.zentra.minigames.PillarsGame;
import id.zentra.minigames.PracticeGame;
import id.zentra.minigames.SumoGame;
import id.zentra.minigames.TinyHuntGame;
import id.zentra.minigames.TntTagGame;
import id.zentra.minigames.ZentraMinigames;
import id.zentra.minigames.libs.com.cryptomorin.xseries.XMaterial;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class GameManager {
    public static final List<String> KEYS = List.of("sumo", "tnttag", "crumble", "colorrush", "pillars", "tinyhunt", "duel", "practice", "practicebot", "bridge", "skyparkour", "iceparkour", "netherparkour", "parkourrace");
    private final ZentraMinigames plugin;
    private final Map<String, List<Game>> games = new LinkedHashMap<String, List<Game>>();
    private final Map<UUID, Game> inGame = new HashMap<UUID, Game>();
    private final Map<UUID, Integer> botPref = new HashMap<UUID, Integer>();
    private final Map<UUID, UUID> invitations = new HashMap<UUID, UUID>();
    private final Deque<Game> buildQueue = new ArrayDeque<Game>();
    private final Set<String> queued = new HashSet<String>();
    private static final int STRUCTURE_REVISION = 1;
    private boolean building;
    private World world;
    private static final Map<String, String> CATEGORY = Map.of("sumo", "Battle", "tnttag", "Party", "crumble", "Lari", "colorrush", "Refleks", "pillars", "Survival", "tinyhunt", "Petak Umpet", "duel", "Duel 1v1", "practice", "PvP Bebas", "bridge", "Bridge");

    public GameManager(ZentraMinigames zentraMinigames) {
        this.plugin = zentraMinigames;
    }

    public World world() {
        return this.world;
    }

    public void init(World world) {
        this.world = world;
        FileConfiguration fileConfiguration = this.plugin.getConfig();
        int n = fileConfiguration.getInt("arena.x", 30000);
        int n2 = fileConfiguration.getInt("arena.z", 30000);
        int n3 = fileConfiguration.getInt("arena.y", 150);
        int n4 = fileConfiguration.getInt("build-version", 1);
        if (this.plugin.data().getInt("build-version", 0) != n4) {
            this.plugin.data().set("built", null);
            this.plugin.data().set("structure-revision", null);
            this.plugin.data().set("build-version", (Object)n4);
            this.plugin.saveData();
        }
        int n5 = 0;
        for (String string : KEYS) {
            if (!fileConfiguration.getBoolean("games." + string + ".enabled", true)) continue;
            int n6 = Math.max(1, fileConfiguration.getInt("games." + string + ".instances", string.equals("practice") ? 1 : 2));
            ArrayList<Game> arrayList = new ArrayList<Game>();
            for (int i = 0; i < n6; ++i) {
                Game game = this.create(string, i, n + n5 * 400, n3, n2 + i * 400);
                arrayList.add(game);
                game.activate();
                if (this.plugin.isBuilt(game.id()) && this.plugin.data().getInt("structure-revision." + game.id(), 0) == 1) {
                    game.state = Game.State.WAITING;
                    continue;
                }
                this.queueBuild(game);
            }
            this.games.put(string, arrayList);
            ++n5;
        }
        this.plugin.getLogger().info("Zentra Minigames siap di world '" + world.getName() + "'. Arena yang belum ada akan dibangun otomatis.");
        this.pump();
    }

    private Game create(String string, int n, int n2, int n3, int n4) {
        return switch (string) {
            case "sumo" -> new SumoGame(this.plugin, n, n2, n3, n4);
            case "tnttag" -> new TntTagGame(this.plugin, n, n2, n3, n4);
            case "crumble" -> new CrumbleRunGame(this.plugin, n, n2, n3, n4);
            case "colorrush" -> new ColorRushGame(this.plugin, n, n2, n3, n4);
            case "pillars" -> new PillarsGame(this.plugin, n, n2, n3, n4);
            case "tinyhunt" -> new TinyHuntGame(this.plugin, n, n2, n3, n4);
            case "duel" -> new DuelGame(this.plugin, n, n2, n3, n4);
            case "practice" -> new PracticeGame(this.plugin, n, n2, n3, n4, false);
            case "practicebot" -> new PracticeGame(this.plugin, n, n2, n3, n4, true);
            case "bridge" -> new BridgeGame(this.plugin, n, n2, n3, n4);
            case "skyparkour" -> new ParkourGame(this.plugin, string, "Sky Parkour", 0, n, n2, n3, n4);
            case "iceparkour" -> new ParkourGame(this.plugin, string, "Ice Parkour", 1, n, n2, n3, n4);
            case "netherparkour" -> new ParkourGame(this.plugin, string, "Nether Parkour", 2, n, n2, n3, n4);
            case "parkourrace" -> new ParkourRaceGame(this.plugin, n, n2, n3, n4);
            default -> throw new IllegalArgumentException(string);
        };
    }

    private void queueBuild(Game game) {
        if (!this.queued.add(game.id())) {
            return;
        }
        game.state = Game.State.RESETTING;
        this.buildQueue.add(game);
    }

    private void pump() {
        boolean bl;
        if (this.building) {
            return;
        }
        Game game = this.buildQueue.poll();
        if (game == null) {
            return;
        }
        this.building = true;
        this.plugin.getLogger().info("Membangun arena " + game.id() + " ...");
        boolean bl2 = bl = this.plugin.data().getInt("structure-revision." + game.id(), 0) != 1;
        if (bl) {
            this.plugin.markBuilt(game.id(), false);
            this.plugin.getLogger().info("Area " + game.id() + " akan dibersihkan dan diperbarui; pembangunan menunggu jika ada pemain di area.");
        }
        game.build(bl, () -> {
            this.plugin.data().set("structure-revision." + game.id(), (Object)1);
            this.plugin.markBuilt(game.id(), true);
            this.queued.remove(game.id());
            game.state = Game.State.WAITING;
            this.building = false;
            this.plugin.getLogger().info("Arena " + game.id() + " selesai.");
            this.pump();
        });
    }

    public void rebuild(String string) {
        for (Map.Entry<String, List<Game>> entry : this.games.entrySet()) {
            if (!string.equals("all") && !entry.getKey().equals(string)) continue;
            for (Game game : entry.getValue()) {
                if (!game.players.isEmpty() || this.queued.contains(game.id())) continue;
                this.plugin.markBuilt(game.id(), false);
                this.queueBuild(game);
            }
        }
        this.pump();
    }

    public void shutdown() {
        for (List<Game> list : this.games.values()) {
            for (Game game : list) {
                game.shutdown();
            }
        }
        this.inGame.clear();
    }

    public Game of(Player player) {
        return this.inGame.get(player.getUniqueId());
    }

    public void forget(UUID uUID) {
        this.inGame.remove(uUID);
    }

    public List<Game> list(String string) {
        return this.games.get(string);
    }

    public Set<String> keys() {
        return this.games.keySet();
    }

    public Game gameAt(Location location) {
        if (this.world == null || location.getWorld() != this.world) {
            return null;
        }
        for (List<Game> list : this.games.values()) {
            for (Game game : list) {
                if (!(Math.abs(location.getX() - (double)game.cx) < 140.0) || !(Math.abs(location.getZ() - (double)game.cz) < 140.0)) continue;
                return game;
            }
        }
        return null;
    }

    public void join(Player player, String string) {
        if (this.world == null) {
            Msg.send(player, "&cPlugin masih memuat world, coba beberapa detik lagi.");
            return;
        }
        if (this.inGame.containsKey(player.getUniqueId())) {
            Msg.send(player, "&cKamu sudah ada di dalam game. Pakai &e/zm leave&c.");
            return;
        }
        List<Game> list = this.games.get(string);
        if (list == null) {
            Msg.send(player, "&cGame tidak ditemukan atau dimatikan.");
            return;
        }
        if (string.equals("practice")) {
            this.openKitMenu(player);
            return;
        }
        Game object = null;
        for (Game object2 : list) {
            if (!object2.joinable() || object != null && object2.players.size() <= object.players.size()) continue;
            object = object2;
        }
        if (object == null) {
            boolean bl = false;
            for (Game game : list) {
                if (game.state != Game.State.RESETTING) continue;
                bl = true;
            }
            Msg.send(player, bl ? "&eArena &f" + list.get((int)0).name + " &esedang disiapkan, tunggu sebentar." : "&cSemua arena &f" + list.get((int)0).name + " &csedang berjalan atau penuh.");
            return;
        }
        if (object.join(player)) {
            this.inGame.put(player.getUniqueId(), object);
        }
    }

    public boolean leave(Player player) {
        Game game = this.inGame.remove(player.getUniqueId());
        if (game == null) {
            return false;
        }
        game.leave(player);
        return true;
    }

    public void setOpen(String string, boolean bl) {
        List<Game> list = this.games.get(string);
        if (list != null) {
            for (Game game : list) {
                game.open = bl;
            }
        }
    }

    public int botLevel(UUID uUID) {
        return this.botPref.getOrDefault(uUID, 0);
    }

    public void setBot(Player player, int n) {
        if (this.of(player) instanceof PracticeGame) {
            Msg.send(player, "&cKeluar dari arena terlebih dahulu untuk mengganti mode bot.");
            return;
        }
        this.botPref.put(player.getUniqueId(), n);
    }

    public int cycleBot(Player player) {
        int n = (this.botLevel(player.getUniqueId()) + 1) % PracticeGame.LEVELS.length;
        this.setBot(player, n);
        return n;
    }

    private static List<String> wrap(String string, int n) {
        ArrayList<String> arrayList = new ArrayList<String>();
        StringBuilder stringBuilder = new StringBuilder();
        for (String string2 : string.split(" ")) {
            if (stringBuilder.length() > 0 && stringBuilder.length() + string2.length() + 1 > n) {
                arrayList.add(stringBuilder.toString());
                stringBuilder.setLength(0);
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.append(' ');
            }
            stringBuilder.append(string2);
        }
        if (stringBuilder.length() > 0) {
            arrayList.add(stringBuilder.toString());
        }
        return arrayList;
    }

    private ItemStack named(ItemStack itemStack, String string, List<String> list, boolean bl) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.displayName(Msg.c(string));
        ArrayList<Component> arrayList = new ArrayList<Component>();
        for (String string2 : list) {
            arrayList.add(Msg.c(string2));
        }
        itemMeta.lore(arrayList);
        itemMeta.addItemFlags(ItemFlag.values());
        if (bl) {
            itemMeta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack pane(Material material) {
        return this.named(new ItemStack(material), " ", List.of(), false);
    }

    private void frame(Inventory inventory, int n) {
        ItemStack itemStack = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack itemStack2 = this.pane(Material.CYAN_STAINED_GLASS_PANE);
        ItemStack itemStack3 = this.pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < n * 9; ++i) {
            boolean bl;
            int n2 = i / 9;
            int n3 = i % 9;
            boolean bl2 = bl = n2 == 0 || n2 == n - 1 || n3 == 0 || n3 == 8;
            inventory.setItem(i, bl ? ((n2 == 0 || n2 == n - 1) && n3 % 2 == 0 ? itemStack2 : itemStack) : itemStack3);
        }
    }

    private int totalPlayers() {
        int n = 0;
        for (List<Game> list : this.games.values()) {
            for (Game game : list) {
                n += game.players.size();
            }
        }
        return n;
    }

    public void openMenu(Player player) {
        Game object;
        Map.Entry<String, List<Game>> entry;
        Inventory inventory;
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)54, (Component)Msg.c("&b&lZentra &3&lMinigames"));
        this.frame(inventory, 6);
        inventory.setItem(4, this.named(new ItemStack(Material.NETHER_STAR), "&b&lZENTRA MINIGAMES", List.of("&7Pilih game lalu klik untuk bergabung.", " ", "&8\u00bb &fSedang bermain &a" + this.totalPlayers() + " &fpemain", "&8\u00bb &7Klik kanan pada game = lihat aturan"), true));
        menuHolder.keys.put(4, "_info");
        int[] nArray = new int[]{19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int n = 0;
        Iterator<Map.Entry<String, List<Game>>> object2 = this.games.entrySet().iterator();
        while (object2.hasNext()) {
            entry = object2.next();
            if (entry.getKey().equals("practice") || entry.getKey().equals("practicebot") || entry.getKey().equals("parkourrace") || entry.getKey().endsWith("parkour")) continue;
            if (n >= nArray.length) break;
            List<Game> list = entry.getValue();
            object = list.get(0);
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            boolean bl = false;
            for (Game game : list) {
                n2 += game.players.size();
                if (game.joinable()) {
                    ++n3;
                    if (game.state == Game.State.COUNTDOWN) {
                        n4 = 1;
                    }
                }
                if (game.state != Game.State.RESETTING) continue;
                bl = true;
            }
            String string = n3 > 0 ? (n4 != 0 ? "&eHitung mundur" : (n2 > 0 ? "&aMenunggu pemain" : "&aSiap dimainkan")) : (bl ? "&7Menyiapkan arena" : "&cSedang berjalan");
            ArrayList<String> object32 = new ArrayList<String>();
            object32.add("&8" + CATEGORY.getOrDefault(entry.getKey(), "Minigame") + " \u2022 " + ((Game)object).min + "-" + ((Game)object).max + " pemain");
            object32.add(" ");
            for (String string2 : GameManager.wrap(((Game)object).rules.get(0), 34)) {
                object32.add("&7" + string2);
            }
            object32.add(" ");
            object32.add("&8\u00bb &fPemain &a" + n2);
            object32.add("&8\u00bb &fStatus " + (String)string);
            object32.add("&8\u00bb &fArena &b" + n3 + "&7/&b" + list.size() + " &7terbuka");
            object32.add(" ");
            object32.add(n3 > 0 ? "&a\u25b6 Klik kiri &7untuk bergabung" : "&c\u2716 Belum bisa bergabung");
            object32.add("&e\u25b6 Klik kanan &7untuk lihat aturan");
            inventory.setItem(nArray[n], this.named(new ItemStack(((Game)object).icon), "&b&l" + ((Game)object).name, object32, n3 > 0));
            menuHolder.keys.put(nArray[n], (String)entry.getKey());
            ++n;
        }
        if (n < nArray.length && (this.games.containsKey("skyparkour") || this.games.containsKey("iceparkour") || this.games.containsKey("netherparkour"))) {
            inventory.setItem(nArray[n], this.named(new ItemStack(this.parkourMaterial("FEATHER")), "&b&lParkour", List.of("&7Pilih map dan tantanganmu sendiri!", "&7Checkpoint, waktu dan catatan pribadi.", " ", "&aKlik untuk memilih map"), true));
            menuHolder.keys.put(nArray[n], "parkour:select");
        }
        List<Game> practiceList = this.games.get("practice");
        if (practiceList != null) {
            int n5 = 0;
            int n6 = 0;
            for (Game game : practiceList) { n5 += game.players.size(); n6 += game.max; }
            ArrayList<String> lore = new ArrayList<>();
            lore.add("&8PvP Bebas \u2022 tanpa ronde");
            lore.add(" ");
            for (String string : GameManager.wrap(practiceList.get(0).rules.get(0), 34)) {
                lore.add("&7" + string);
            }
            lore.add(" ");
            lore.add("&fKit tersedia:");
            for (Kit kit : Kit.values()) {
                lore.add("&8\u00bb " + kit.colored());
            }
            lore.add(" ");
            lore.add("&8\u00bb &fSedang berlatih &a" + n5 + "&7/&f" + n6);
            lore.add(" ");
            lore.add("&a\u25b6 Klik kiri &7untuk memilih kit");
            lore.add("&e\u25b6 Klik kanan &7untuk lihat aturan");
            inventory.setItem(40, this.named(new ItemStack(Material.END_CRYSTAL), "&c&lPractice PvP", lore, true));
            menuHolder.keys.put(40, "practice");
        }
        inventory.setItem(38, this.named(new ItemStack(Material.BOOK), "&e&lCara Bermain", List.of("&7Klik game untuk masuk ke arena", "&7yang paling ramai.", " ", "&7Di ruang tunggu, pakai item hotbar:", "&8\u00bb &fAturan Main, Panggil Teman, Vote Mulai"), false));
        menuHolder.keys.put(38, "_info");
        if (this.inGame.containsKey(player.getUniqueId())) {
            Game entryGame = this.inGame.get(player.getUniqueId());
            inventory.setItem(49, this.named(new ItemStack(Material.BARRIER), "&c&lKeluar dari game", List.of("&7Sedang di: &f" + entryGame.name, "&7Kembali ke tempat semula"), false));
            menuHolder.keys.put(49, "_leave");
        }
        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.6f, 1.3f);
    }

    private Material parkourMaterial(String string) {
        return XMaterial.matchXMaterial(string).map(XMaterial::parseMaterial).orElseThrow();
    }

    public void openParkourSelect(Player player) {
        Inventory inventory;
        if (this.of(player) != null) {
            Msg.send(player, "&cKeluar dari game dahulu dengan /zm leave.");
            return;
        }
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&b&lParkour &8\u00bb &fPilih permainan"));
        this.frame(inventory, 3);
        inventory.setItem(11, this.named(new ItemStack(this.parkourMaterial("FEATHER")), "&a&lSolo", List.of("&7Pilih map dan mode sendiri.", "&7Tanpa pengumuman kemenangan global.", "&aKlik untuk memilih map"), true));
        menuHolder.keys.put(11, "parkour:maps");
        inventory.setItem(15, this.named(new ItemStack(this.parkourMaterial("CLOCK")), "&e&lBalapan 1v1", List.of("&7Cari lawan, lalu vote map dan mode.", "&7Pemain pertama yang selesai menang.", "&aKlik untuk mencari lawan"), true));
        menuHolder.keys.put(15, "parkour:race");
        inventory.setItem(22, this.named(new ItemStack(this.parkourMaterial("ARROW")), "&eKembali", List.of(), false));
        menuHolder.keys.put(22, "_back");
        player.openInventory(inventory);
    }

    public void openRaceVote(Player player, ParkourRaceGame parkourRaceGame) {
        int n;
        Inventory inventory;
        if (!parkourRaceGame.canVote(player)) {
            Msg.send(player, "&eVoting tersedia setelah lawan ditemukan.");
            return;
        }
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&b&lParkour 1v1 &8\u00bb &fVote"));
        this.frame(inventory, 3);
        String[] stringArray = new String[]{"Sky", "Ice", "Nether"};
        String[] stringArray2 = new String[]{"FEATHER", "ICE", "BLAZE_POWDER"};
        for (n = 0; n < stringArray.length; ++n) {
            inventory.setItem(10 + n, this.named(new ItemStack(this.parkourMaterial(stringArray2[n])), "&b" + stringArray[n], List.of("&7Suara: &f" + parkourRaceGame.mapVotes(stringArray[n]), "&aKlik untuk vote map"), false));
            menuHolder.keys.put(10 + n, "race:map:" + stringArray[n]);
        }
        for (n = 0; n < ParkourGame.Mode.values().length; ++n) {
            String string = ParkourGame.Mode.values()[n].name();
            inventory.setItem(14 + n, this.named(new ItemStack(this.parkourMaterial("CLOCK")), "&e" + string, List.of("&7Suara: &f" + parkourRaceGame.modeVotes(string), "&aKlik untuk vote mode"), false));
            menuHolder.keys.put(14 + n, "race:mode:" + string);
        }
        player.openInventory(inventory);
    }

    public void openParkourMaps(Player player) {
        Inventory inventory;
        if (this.of(player) != null) {
            Msg.send(player, "&cKeluar dari game dahulu dengan /zm leave.");
            return;
        }
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&b&lParkour &8\u00bb &fPilih Map"));
        this.frame(inventory, 3);
        String[] stringArray = new String[]{"skyparkour", "iceparkour", "netherparkour"};
        String[] stringArray2 = new String[]{"&7Lompatan di atas awan", "&7Lintasan es yang licin", "&7Mendaki lintasan Nether"};
        for (int i = 0; i < stringArray.length; ++i) {
            List<Game> list = this.games.get(stringArray[i]);
            if (list == null) continue;
            Game game = list.get(0);
            int n = 11 + i * 2;
            inventory.setItem(n, this.named(new ItemStack(game.icon), "&b&l" + game.name, List.of(stringArray2[i], "&7Tiga checkpoint dan garis akhir", " ", "&aKlik untuk memilih mode"), true));
            menuHolder.keys.put(n, "parkour:map:" + stringArray[i]);
        }
        inventory.setItem(22, this.named(new ItemStack(this.parkourMaterial("ARROW")), "&eKembali", List.of("&7Menu utama"), false));
        menuHolder.keys.put(22, "_back");
        player.openInventory(inventory);
    }

    public void openParkourModes(Player player, String string) {
        Inventory inventory;
        List<Game> list = this.games.get(string);
        if (this.of(player) != null || list == null || !(list.get(0) instanceof ParkourGame)) {
            Msg.send(player, "&cMap tidak tersedia atau kamu masih berada di game.");
            return;
        }
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&bParkour &8\u00bb &f" + list.get((int)0).name));
        this.frame(inventory, 3);
        String[] stringArray = new String[]{"CLASSIC", "SPEEDRUN", "HARDCORE"};
        String[] stringArray2 = new String[]{"LIME_DYE", "CLOCK", "BLAZE_POWDER"};
        String[] stringArray3 = new String[]{"&7Jatuh kembali ke checkpoint.", "&7Tanpa checkpoint; jatuh kembali ke awal.", "&7Tanpa checkpoint; jatuh mengulang waktu."};
        for (int i = 0; i < stringArray.length; ++i) {
            int n = 11 + i * 2;
            inventory.setItem(n, this.named(new ItemStack(this.parkourMaterial(stringArray2[i])), "&e&l" + stringArray[i], List.of(stringArray3[i], "&7Catatan waktu dipisahkan per mode.", " ", "&aKlik untuk mulai"), true));
            menuHolder.keys.put(n, "parkour:play:" + string + ":" + stringArray[i]);
        }
        inventory.setItem(22, this.named(new ItemStack(this.parkourMaterial("ARROW")), "&eKembali", List.of("&7Pilih map lain"), false));
        menuHolder.keys.put(22, "parkour:maps");
        player.openInventory(inventory);
    }

    public void joinParkour(Player player, String string, String string2) {
        ParkourGame.Mode mode;
        if (this.world == null || this.of(player) != null) {
            Msg.send(player, "&cWorld belum siap atau kamu masih bermain.");
            return;
        }
        List<Game> list = this.games.get(string);
        if (list == null) {
            Msg.send(player, "&cMap tidak tersedia.");
            return;
        }
        try {
            mode = ParkourGame.Mode.valueOf(string2);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Msg.send(player, "&cMode tidak tersedia.");
            return;
        }
        for (Game game : list) {
            ParkourGame parkourGame;
            if (!(game instanceof ParkourGame) || !(parkourGame = (ParkourGame)game).joinable() || !parkourGame.joinWith(player, mode)) continue;
            this.inGame.put(player.getUniqueId(), parkourGame);
            return;
        }
        Msg.send(player, "&eMap sedang disiapkan atau penuh. Coba lagi nanti.");
    }

    public void openInvites(Player player, int n) {
        Game game = this.of(player);
        if (game == null || !game.joinable()) {
            return;
        }
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (Player player22 : Bukkit.getOnlinePlayers()) {
            if (player22.equals((Object)player) || this.of(player22) != null) continue;
            arrayList.add(player22);
        }
        arrayList.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        n = Math.max(0, Math.min(n, Math.max(0, (arrayList.size() - 1) / 45)));
        MenuHolder menuHolder = new MenuHolder();
        Inventory player22 = Bukkit.createInventory((InventoryHolder)menuHolder, (int)54, (Component)Msg.c("&b&lUndang Pemain &8\u00bb &7" + (n + 1)));
        menuHolder.inv = player22;
        for (int i = n * 45; i < Math.min(arrayList.size(), n * 45 + 45); ++i) {
            Player player3 = (Player)arrayList.get(i);
            int n2 = i - n * 45;
            player22.setItem(n2, this.named(new ItemStack(Material.PLAYER_HEAD), "&b" + player3.getName(), List.of("&7Klik untuk mengundang"), false));
            menuHolder.keys.put(n2, "invite:" + String.valueOf(player3.getUniqueId()));
        }
        if (n > 0) {
            player22.setItem(45, this.named(new ItemStack(Material.ARROW), "&eSebelumnya", List.of(), false));
            menuHolder.keys.put(45, "invitepage:" + (n - 1));
        }
        if ((n + 1) * 45 < arrayList.size()) {
            player22.setItem(53, this.named(new ItemStack(Material.ARROW), "&eBerikutnya", List.of(), false));
            menuHolder.keys.put(53, "invitepage:" + (n + 1));
        }
        player.openInventory(player22);
    }

    public void invite(Player player, UUID uUID) {
        Game game = this.of(player);
        Player player2 = Bukkit.getPlayer((UUID)uUID);
        if (game == null || player2 == null || this.of(player2) != null || !game.joinable()) {
            return;
        }
        game.invite(player, player2);
    }

    public void recordInvite(Player player, Player player2) {
        this.invitations.put(player.getUniqueId(), player2.getUniqueId());
    }

    public void acceptInvite(Player player, UUID uUID) {
        Game game;
        if (!uUID.equals(this.invitations.remove(player.getUniqueId()))) {
            Msg.send(player, "&cUndangan tidak tersedia.");
            return;
        }
        Player player2 = Bukkit.getPlayer((UUID)uUID);
        Game game2 = game = player2 == null ? null : this.of(player2);
        if (this.of(player) != null || game == null || !game.joinable()) {
            Msg.send(player, "&cArena undangan tidak tersedia.");
            return;
        }
        if (game.join(player)) {
            this.inGame.put(player.getUniqueId(), game);
        }
    }

    public void openDuelVote(Player player, DuelGame duelGame) {
        Inventory inventory;
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&e&lVote Kit Duel"));
        this.frame(inventory, 3);
        String[] stringArray = new String[]{"Sword", "Mace", "NoDebuff"};
        for (int i = 0; i < stringArray.length; ++i) {
            String string = stringArray[i];
            int n = 11 + i * 2;
            inventory.setItem(n, this.named(new ItemStack(Material.BOOK), "&e" + string, List.of("&7Suara: &f" + duelGame.votesFor(string), "&aKlik untuk memilih"), false));
            menuHolder.keys.put(n, "vote:" + string);
        }
        player.openInventory(inventory);
    }

    public void openKitMenu(Player player) {
        int n;
        Inventory inventory;
        if (this.world == null) {
            Msg.send(player, "&cPlugin masih memuat world, coba beberapa detik lagi.");
            return;
        }
        List<Game> list = this.games.get("practice");
        if (list == null) {
            Msg.send(player, "&cPractice PvP tidak aktif.");
            return;
        }
        MenuHolder menuHolder = new MenuHolder();
        menuHolder.inv = inventory = Bukkit.createInventory((InventoryHolder)menuHolder, (int)27, (Component)Msg.c("&c&lPractice PvP &8\u00bb &7Pilih Kit"));
        this.frame(inventory, 3);
        int n2 = 0;
        int n3 = 0;
        for (Game object2 : list) {
            n2 += object2.players.size();
            n3 += object2.max;
        }
        inventory.setItem(4, this.named(new ItemStack(Material.END_CRYSTAL), "&c&lPractice PvP", List.of("&7Arena datar luas, respawn instan.", " ", "&8\u00bb &fSedang berlatih &a" + n2 + "&7/&f" + n3, "&8\u00bb &7Pilih kit di bawah untuk masuk"), true));
        menuHolder.keys.put(4, "_info");
        boolean bl = this.of(player) instanceof PracticeGame;
        int[] nArray = new int[]{10, 12, 14, 16};
        Kit[] kitArray = Kit.values();
        for (n = 0; n < kitArray.length && n < nArray.length; ++n) {
            ArrayList<String> arrayList = new ArrayList<String>(kitArray[n].lore);
            arrayList.add(" ");
            arrayList.add(bl ? "&e\u25b6 Klik untuk ganti kit &8(respawn)" : "&a\u25b6 Klik untuk masuk arena");
            inventory.setItem(nArray[n], this.named(kitArray[n].icon(), kitArray[n].color + "&l" + kitArray[n].display, arrayList, true));
            menuHolder.keys.put(nArray[n], "kit:" + kitArray[n].name());
        }
        n = this.botLevel(player.getUniqueId());
        inventory.setItem(22, this.named(new ItemStack(Material.ZOMBIE_HEAD), "&a&lLawan Bot: " + PracticeGame.LEVEL_COLORS[n] + "&l" + PracticeGame.LEVELS[n], List.of("&7Bot bertarung di arena terpisah untuk satu pemain.", "&7Tingkat: &aMudah &8/ &eSedang &8/ &cSulit", "&7Ganti mode sebelum masuk arena.", " ", "&e\u25b6 Klik untuk ganti tingkat"), n > 0));
        menuHolder.keys.put(22, "_bot");
        inventory.setItem(20, this.named(new ItemStack(Material.ARROW), "&7\u00ab Kembali", List.of("&7Ke menu utama"), false));
        menuHolder.keys.put(20, "_back");
        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
    }

    public void pickKit(Player player, Kit kit) {
        Game game = this.of(player);
        if (game instanceof PracticeGame) {
            PracticeGame practiceGame = (PracticeGame)game;
            practiceGame.changeKit(player, kit);
            return;
        }
        if (game != null) {
            Msg.send(player, "&cKamu sudah ada di dalam game. Pakai &e/zm leave&c.");
            return;
        }
        List<Game> list = this.games.get(this.botLevel(player.getUniqueId()) > 0 ? "practicebot" : "practice");
        if (this.world == null || list == null) {
            Msg.send(player, "&cPractice PvP belum siap.");
            return;
        }
        PracticeGame practiceGame = null;
        for (Game game2 : list) {
            if (!(game2 instanceof PracticeGame)) continue;
            PracticeGame practiceGame2 = (PracticeGame)game2;
            if (!game2.joinable()) continue;
            practiceGame = practiceGame2;
            break;
        }
        if (practiceGame == null) {
            Msg.send(player, "&eArena Practice sedang disiapkan atau penuh, coba lagi sebentar.");
            return;
        }
        if (practiceGame.joinWith(player, kit)) {
            this.inGame.put(player.getUniqueId(), practiceGame);
        }
    }

    public void showRules(Player player, String string) {
        List<Game> list = this.games.get(string);
        if (list != null) {
            list.get(0).showRules(player);
        }
    }

    public static final class MenuHolder
    implements InventoryHolder {
        public Inventory inv;
        public final Map<Integer, String> keys = new HashMap<Integer, String>();

        public Inventory getInventory() {
            return this.inv;
        }
    }
}

