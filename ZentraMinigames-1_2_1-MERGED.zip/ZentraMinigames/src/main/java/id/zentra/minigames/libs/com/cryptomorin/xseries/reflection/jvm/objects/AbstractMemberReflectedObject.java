/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.AbstractReflectedObject;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Member;
import org.jspecify.annotations.NonNull;

abstract class AbstractMemberReflectedObject
extends AbstractReflectedObject {
    AbstractMemberReflectedObject() {
    }

    @Override
    public abstract @NonNull AnnotatedElement unreflect();

    protected abstract Member member();

    @Override
    public @NonNull String name() {
        return this.member().getName();
    }

    @Override
    public final Class<?> getDeclaringClass() {
        return this.member().getDeclaringClass();
    }

    @Override
    public final int getModifiers() {
        return this.member().getModifiers();
    }
}

