/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Experimental
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.constraint;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XAccessFlag;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.constraint.ReflectiveConstraint;
import java.lang.reflect.Member;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Experimental
public enum VisibilityConstraint implements ReflectiveConstraint
{
    PUBLIC(XAccessFlag.PUBLIC),
    PRIVATE(XAccessFlag.PRIVATE),
    PROTECTED(XAccessFlag.PROTECTED);

    private final XAccessFlag accessFlag;

    private VisibilityConstraint(XAccessFlag accessFlag) {
        this.accessFlag = accessFlag;
    }

    @ApiStatus.Internal
    public XAccessFlag getAccessFlag() {
        return this.accessFlag;
    }

    @Override
    public ReflectiveConstraint.Result appliesTo(ReflectiveHandle<?> handle, Object jvm) {
        int mods;
        if (jvm instanceof Class) {
            mods = ((Class)jvm).getModifiers();
            if (this == PRIVATE) {
                return ReflectiveConstraint.Result.INCOMPATIBLE;
            }
            if (this == PROTECTED) {
                return ReflectiveConstraint.Result.of(!XAccessFlag.PUBLIC.isSet(mods));
            }
        } else if (jvm instanceof Member) {
            mods = ((Member)jvm).getModifiers();
        } else {
            return ReflectiveConstraint.Result.INCOMPATIBLE;
        }
        return ReflectiveConstraint.Result.of(this.accessFlag.isSet(mods));
    }

    @Override
    public String category() {
        return "Visibility";
    }

    public String toString() {
        return this.getClass().getSimpleName() + "::" + this.name();
    }
}

