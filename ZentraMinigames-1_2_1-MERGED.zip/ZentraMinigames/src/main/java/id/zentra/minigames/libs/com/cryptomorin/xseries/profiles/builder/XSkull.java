/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Skull
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.jetbrains.annotations.ApiStatus$Experimental
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.builder;

import id.zentra.minigames.libs.com.cryptomorin.xseries.XMaterial;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.PlayerProfiles;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.builder.ProfileInstruction;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.MojangGameProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.ProfileContainer;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.ProfileInputType;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.Profileable;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Skull;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class XSkull {
    private static final MojangGameProfile DEFAULT_PROFILE = PlayerProfiles.signXSeries(ProfileInputType.BASE64.getProfile("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzEwNTkxZTY5MDllNmEyODFiMzcxODM2ZTQ2MmQ2N2EyYzc4ZmEwOTUyZTkxMGYzMmI0MWEyNmM0OGMxNzU3YyJ9fX0="));

    @NotNull
    @Contract(value="-> new", pure=true)
    public static ProfileInstruction<ItemStack> createItem() {
        return XSkull.of(XMaterial.PLAYER_HEAD.parseItem());
    }

    @NotNull
    @Contract(value="_ -> new", pure=true)
    public static ProfileInstruction<ItemStack> of(@NotNull ItemStack item) {
        return new ProfileInstruction<ItemStack>(new ProfileContainer.ItemStackProfileContainer(item));
    }

    @NotNull
    @Contract(value="_ -> new", pure=true)
    public static ProfileInstruction<ItemMeta> of(@NotNull ItemMeta meta) {
        return new ProfileInstruction<ItemMeta>(new ProfileContainer.ItemMetaProfileContainer((SkullMeta)meta));
    }

    @NotNull
    @Contract(value="_ -> new", pure=true)
    public static ProfileInstruction<Block> of(@NotNull Block block) {
        return new ProfileInstruction<Block>(new ProfileContainer.BlockProfileContainer(block));
    }

    @NotNull
    @Contract(value="_ -> new", pure=true)
    public static ProfileInstruction<Skull> of(@NotNull BlockState state) {
        return new ProfileInstruction<Skull>(new ProfileContainer.BlockStateProfileContainer((Skull)state));
    }

    @NotNull
    @Contract(value="_ -> new", pure=true)
    @ApiStatus.Experimental
    static ProfileInstruction<Player> of(@NotNull Player player) {
        return new ProfileInstruction<Player>(new ProfileContainer.PlayerContainer(player));
    }

    @NotNull
    @Contract(value="-> new", pure=true)
    static Profileable getDefaultProfile() {
        return Profileable.of(DEFAULT_PROFILE.copy(), false);
    }
}

