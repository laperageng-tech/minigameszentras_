/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.potion.PotionType
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

public final class DuelGame
extends Game {
    private static final String[] KITS = new String[]{"Crystal", "Sword", "Mace", "NoDebuff"};
    private String kit = "Sword";
    private final Map<UUID, String> kitVotes = new HashMap<UUID, String>();

    public void voteKit(Player player, String string) {
        if (this.state != Game.State.WAITING && this.state != Game.State.COUNTDOWN || !this.players.contains(player.getUniqueId())) {
            return;
        }
        for (String string2 : KITS) {
            if (!string2.equals(string)) continue;
            this.kitVotes.put(player.getUniqueId(), string);
            Msg.send(player, "&aPilihan kit: &e" + string);
            return;
        }
    }

    public int votesFor(String string) {
        return (int)this.kitVotes.values().stream().filter(string::equals).count();
    }

    public void clearVote(UUID uUID) {
        this.kitVotes.remove(uUID);
    }

    @Override
    protected void onLeave(Player player, boolean bl) {
        this.kitVotes.remove(player.getUniqueId());
    }

    public DuelGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "duel", "Arena Duel", Material.DIAMOND_SWORD, n, n2, n3, n4, 2, 2, List.of("Duel 1 lawan 1 di arena melayang, vote kit sebelum mulai!", "Kit: Sword (klasik), Mace (smash dengan Wind Charge), NoDebuff (potion penyembuh).", "Kalah kalau HP habis atau jatuh dari arena. Ender pearl boleh, tapi hati-hati meleset!", "Ada 3 detik membeku di awal untuk bersiap."));
        this.voidY = n3 - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        blueprint.cone(this.cx, this.by - 14, this.cz, 17, 12, Material.BLACKSTONE);
        blueprint.disc(this.cx, this.by, this.cz, 16, Material.DEEPSLATE_TILES);
        blueprint.ring(this.cx, this.by, this.cz, 14, 15, Material.POLISHED_BLACKSTONE_BRICKS);
        blueprint.ring(this.cx, this.by, this.cz, 15, 16, Material.GILDED_BLACKSTONE);
        blueprint.disc(this.cx, this.by, this.cz, 2, Material.CRYING_OBSIDIAN);
        for (int[] nArray : new int[][]{{7, 0}, {-7, 0}}) {
            blueprint.fill(this.cx + nArray[0], this.by + 1, this.cz - 2, this.cx + nArray[0], this.by + 3, this.cz + 2, Material.BLACKSTONE);
        }
        for (int[] nArray : new int[][]{{0, 8}, {0, -8}}) {
            blueprint.fill(this.cx - 1, this.by + 1, this.cz + nArray[1], this.cx + 1, this.by + 2, this.cz + nArray[1], Material.POLISHED_BLACKSTONE_BRICKS);
        }
        for (int[] nArray : new int[][]{{13, 13}, {-13, 13}, {13, -13}, {-13, -13}}) {
            blueprint.fill(this.cx + nArray[0], this.by + 1, this.cz + nArray[1], this.cx + nArray[0], this.by + 5, this.cz + nArray[1], Material.CRYING_OBSIDIAN);
            blueprint.set(this.cx + nArray[0], this.by + 6, this.cz + nArray[1], Material.SEA_LANTERN);
        }
    }

    @Override
    protected void onStart() {
        this.kitVotes.keySet().retainAll(this.players);
        int n = 0;
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string : KITS) {
            int n2 = this.votesFor(string);
            if (n2 > n) {
                n = n2;
                arrayList.clear();
            }
            if (n2 != n) continue;
            arrayList.add(string);
        }
        this.kit = (String)arrayList.get(this.rnd.nextInt(arrayList.size()));
        this.kitVotes.clear();
        List<Player> list = this.alivePlayers();
        this.spreadRing(list, 11.0, this.by + 1);
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Player player = (Player)iterator.next();
            this.giveKit(player);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 9, false, false));
            Msg.title(player, "&c&lDUEL", "&7Kit: &e" + this.kit, 5, 50, 10);
        }
        this.bc("&7Kit terpilih: &e" + this.kit);
    }

    private void giveKit(Player player) {
        Kit kit = switch (this.kit) {
            case "Crystal" -> Kit.CRYSTAL;
            case "Mace" -> Kit.MACE;
            case "NoDebuff" -> Kit.NODEBUFF;
            default -> Kit.SWORD;
        };
        kit.give(player);
    }

    private ItemStack healPotion() {
        ItemStack itemStack = new ItemStack(Material.SPLASH_POTION);
        PotionMeta potionMeta = (PotionMeta)itemStack.getItemMeta();
        potionMeta.setBasePotionType(PotionType.STRONG_HEALING);
        itemStack.setItemMeta((ItemMeta)potionMeta);
        return itemStack;
    }

    @Override
    protected String barText() {
        return "&cArena Duel &8| &fKit: &e" + this.kit;
    }
}

