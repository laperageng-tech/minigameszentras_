/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.aggregate;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XReflection;
import java.util.concurrent.Callable;
import org.jetbrains.annotations.ApiStatus;

public final class VersionHandle<T> {
    private int major;
    private int minor;
    private int patch;
    private T handle;

    private String stringVersion() {
        return this.major + "." + this.minor + "." + this.patch;
    }

    @ApiStatus.Internal
    public VersionHandle(int major, int minor, int patch, T handle) {
        if (XReflection.supports(major, minor, patch)) {
            this.major = major;
            this.minor = minor;
            this.patch = patch;
            this.handle = handle;
        }
    }

    @ApiStatus.Internal
    public VersionHandle(int major, int minor, int patch, Callable<T> handle) {
        if (XReflection.supports(major, minor, patch)) {
            this.major = major;
            this.minor = minor;
            this.patch = patch;
            try {
                this.handle = handle.call();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private boolean checkVersion(int major, int minor, int patch) {
        if (major == this.major && minor == this.minor && patch == this.patch) {
            throw new IllegalArgumentException("Cannot have duplicate version handles for version: " + this.stringVersion());
        }
        return XReflection.supports(major, minor, patch) && major > this.major && minor > this.minor && patch >= this.patch;
    }

    public VersionHandle<T> v(int major, int minor, int patch, Callable<T> handle) {
        if (!this.checkVersion(major, minor, patch)) {
            return this;
        }
        try {
            this.handle = handle.call();
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.major = major;
        this.minor = minor;
        this.patch = patch;
        return this;
    }

    public VersionHandle<T> v(int major, int minor, Callable<T> handle) {
        return this.v(major, minor, 0, (T)handle);
    }

    public VersionHandle<T> v(int major, int minor, int patch, T handle) {
        if (this.checkVersion(major, minor, patch)) {
            this.major = major;
            this.minor = minor;
            this.patch = patch;
            this.handle = handle;
        }
        return this;
    }

    public VersionHandle<T> v(int major, int minor, T handle) {
        return this.v(major, minor, 0, handle);
    }

    public T orElse(T handle) {
        return this.major == 0 ? handle : this.handle;
    }

    public T orElse(Callable<T> handle) {
        if (this.major == 0) {
            try {
                return handle.call();
            }
            catch (Exception e) {
                throw new IllegalArgumentException("The last handle also failed", e);
            }
        }
        return this.handle;
    }
}

