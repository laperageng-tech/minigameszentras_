/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;

public final class ProfileChangeException
extends ProfileException {
    public ProfileChangeException(String message) {
        super(message);
    }
}

