/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.cache;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.cache.CacheableProfileable;
import java.time.Duration;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

@ApiStatus.Internal
public abstract class TimedCacheableProfileable
extends CacheableProfileable {
    private long lastUpdate;

    @NotNull
    protected Duration expiresAfter() {
        return Duration.ofHours(6L);
    }

    @Override
    public final boolean hasExpired(boolean renew) {
        Duration expiresAfter = this.expiresAfter();
        if (expiresAfter.isZero()) {
            return false;
        }
        if (super.hasExpired(renew)) {
            return true;
        }
        if (this.cache == null && this.lastError == null) {
            return true;
        }
        long now = System.currentTimeMillis();
        if (this.lastUpdate == 0L) {
            if (renew) {
                this.lastUpdate = now;
            }
            return true;
        }
        long diff = now - this.lastUpdate;
        if (diff >= expiresAfter.toMillis()) {
            if (renew) {
                this.lastUpdate = now;
            }
            return true;
        }
        return false;
    }
}

