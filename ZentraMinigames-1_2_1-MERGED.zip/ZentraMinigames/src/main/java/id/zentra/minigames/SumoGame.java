/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.util.Vector
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public final class SumoGame
extends Game {
    private static final int R = 14;
    private static final int RINGS = 7;
    private int stage;
    private final Map<UUID, Integer> heat = new HashMap<UUID, Integer>();

    public SumoGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "sumo", "Void Sumo", Material.SLIME_BALL, n, n2, n3, n4, 2, 12, List.of("Dorong semua lawan jatuh ke void!", "Pukulanmu tidak melukai, tapi menaikkan PANAS lawan. Makin panas, makin jauh terpental.", "Tiap 25 detik satu cincin platform runtuh. Ruang gerak makin sempit!", "Orang terakhir yang berdiri menang."));
        this.voidY = n3 - 8;
        this.pvp = false;
        this.envDamage = false;
        this.fallDamage = false;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        Material[] materialArray = new Material[]{Material.RED_CONCRETE, Material.ORANGE_CONCRETE, Material.YELLOW_CONCRETE, Material.LIME_CONCRETE, Material.CYAN_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.PURPLE_CONCRETE};
        blueprint.cone(this.cx, this.by - 10, this.cz, 15, 12, Material.DEEPSLATE_BRICKS);
        for (int i = 0; i < 7; ++i) {
            blueprint.ring(this.cx, this.by, this.cz, i == 6 ? -1 : 14 - 2 * (i + 1), 14 - 2 * i, materialArray[i]);
        }
        for (int[] nArray : new int[][]{{16, 0}, {-16, 0}, {0, 16}, {0, -16}}) {
            int n = this.cx + nArray[0];
            int n2 = this.cz + nArray[1];
            blueprint.fill(n, this.by - 10, n2, n, this.by + 9, n2, Material.CRYING_OBSIDIAN);
            blueprint.set(n, this.by + 10, n2, Material.SEA_LANTERN);
        }
        blueprint.ring(this.cx, this.by + 10, this.cz, 15, 16, Material.AMETHYST_BLOCK);
    }

    @Override
    protected void onStart() {
        this.heat.clear();
        this.stage = 0;
        List<Player> list = this.alivePlayers();
        this.spreadRing(list, 9.0, this.by + 1);
        for (Player player : list) {
            player.getInventory().clear();
        }
        this.bc("&eCincin luar runtuh tiap 25 detik. Bertahan!");
    }

    @Override
    protected void onHit(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setDamage(0.0);
        int n = this.heat.merge(player.getUniqueId(), 1, Integer::sum);
        Vector vector = player.getLocation().toVector().subtract(player2.getLocation().toVector()).setY(0);
        if (vector.lengthSquared() > 0.01) {
            Vector vector2 = vector.normalize().multiply(Math.min(1.6, 0.35 + 0.07 * (double)n)).setY(0.25);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> player.setVelocity(player.getVelocity().add(vector2)));
        }
        Msg.bar(player, "&cPanas: &f" + n * 8 + "%");
        player2.playSound(player2.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 1.0f);
    }

    @Override
    protected void onSecond() {
        if (this.stage < 6) {
            int n = this.runSecs % 25;
            if (n == 20) {
                this.bc("&cPlatform menyusut dalam &f5 &cdetik!");
            }
            if (n == 0 && this.runSecs > 0) {
                this.removeRing(this.stage++);
            }
        }
        if (this.runSecs >= 240) {
            this.end(this.alivePlayers());
        }
    }

    private void removeRing(int n) {
        int n2 = 14 - 2 * (n + 1);
        int n3 = 14 - 2 * n;
        for (int i = -n3; i <= n3; ++i) {
            for (int j = -n3; j <= n3; ++j) {
                Block block;
                if (!Blueprint.inRing(i, j, n2, n3) || (block = this.world.getBlockAt(this.cx + i, this.by, this.cz + j)).getType() == Material.AIR) continue;
                block.setType(Material.AIR, false);
                if (this.rnd.nextInt(5) != 0) continue;
                this.world.spawnParticle(Particle.CLOUD, block.getLocation().add(0.5, 1.0, 0.5), 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
        this.bc("&6Satu cincin platform runtuh!");
        this.sound(Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.7f);
    }

    @Override
    protected String barText() {
        return "&6Void Sumo &8| &fHidup: &a" + this.alive.size() + " &8| &fCincin tersisa: &e" + (7 - this.stage);
    }
}

