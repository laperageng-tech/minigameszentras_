package id.zentra.minigames;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Practice Bridge - 1v1 bridge duel (like Hypixel Bridge).
 * Two islands connected by a narrow bridge; knock the opponent into the void.
 * Full-enchant Sword kit, building allowed (obsidian etc.), no fall damage.
 */
public final class BridgeGame extends Game {
    public BridgeGame(ZentraMinigames plugin, int instance, int cx, int by, int cz) {
        super(plugin, "bridge", "Practice Bridge", Material.OAK_PLANKS, instance, cx, by, cz, 2, 2,
            List.of("Jembatan sempit di atas void! Dorong lawan jatuh ke void.",
                    "Kit Sword full enchant. Bangun jembatan / pertahanan dengan block (obsidian boleh).",
                    "Tidak ada fall damage. Orang terakhir yang berdiri menang.",
                    "Ada 3 detik membeku di awal untuk bersiap."));
        this.voidY = by - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
    }

    @Override
    protected void buildArena(Blueprint bp) {
        bp.cone(cx, by - 14, cz, 17, 12, Material.BLACKSTONE);
        // two islands
        bp.disc(cx - 12, by, cz, 7, Material.DEEPSLATE_TILES);
        bp.disc(cx + 12, by, cz, 7, Material.DEEPSLATE_TILES);
        bp.ring(cx - 12, by, cz, 6, 7, Material.POLISHED_BLACKSTONE_BRICKS);
        bp.ring(cx + 12, by, cz, 6, 7, Material.POLISHED_BLACKSTONE_BRICKS);
        // narrow bridge (1 wide) connecting islands
        bp.fill(cx - 5, by, cz, cx + 5, by, cz, Material.OAK_PLANKS);
        // side pillars / decoration
        for (int[] o : new int[][]{{-12, 5}, {-12, -5}, {12, 5}, {12, -5}}) {
            bp.fill(cx + o[0], by + 1, cz + o[1], cx + o[0], by + 4, cz + o[1], Material.CRYING_OBSIDIAN);
            bp.set(cx + o[0], by + 5, cz + o[1], Material.SEA_LANTERN);
        }
        bp.disc(cx - 12, by, cz, 2, Material.CRYING_OBSIDIAN);
        bp.disc(cx + 12, by, cz, 2, Material.CRYING_OBSIDIAN);
    }

    @Override
    protected void onStart() {
        List<Player> list = alivePlayers();
        // spawn on opposite islands facing each other
        for (int i = 0; i < list.size(); i++) {
            Player p = list.get(i);
            int sx = i == 0 ? cx - 12 : cx + 12;
            org.bukkit.Location loc = new org.bukkit.Location(world, sx + 0.5, by + 1, cz + 0.5);
            loc.setDirection(new org.bukkit.util.Vector(i == 0 ? 1 : -1, 0, 0));
            p.teleport(loc);
            Kit.SWORD.give(p);
            p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 60, 9, false, false));
            Msg.title(p, "&c&lBRIDGE", "&7Kit: " + Kit.SWORD.colored(), 5, 50, 10);
        }
        bc("&7Bridge dimulai! Bangun & serang lawan ke void.");
    }

    @Override
    protected void onReset() {
        clearPlacedBlocks();
    }

    @Override
    protected String barText() {
        return "&bPractice Bridge &8| &fHidup: &a" + alive.size();
    }
}
