/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Registry
 *  org.bukkit.World
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.boss.BarColor
 *  org.bukkit.boss.BarFlag
 *  org.bukkit.boss.BarStyle
 *  org.bukkit.boss.BossBar
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package id.zentra.minigames;

import id.zentra.minigames.GameListener;
import id.zentra.minigames.GameManager;
import id.zentra.minigames.MinigamesCommand;
import id.zentra.minigames.Msg;
import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class ZentraMinigames
extends JavaPlugin
implements Listener {
    private GameManager manager;
    private NamespacedKey itemKey;
    private File dataFile;
    private YamlConfiguration data;
    private final Queue<String> winAnnouncements = new ArrayDeque<String>();
    private BossBar winBar;
    private int announcementTicks;

    public void onEnable() {
        this.saveDefaultConfig();
        this.itemKey = new NamespacedKey((Plugin)this, "lobby_item");
        this.dataFile = new File(this.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration((File)this.dataFile);
        this.manager = new GameManager(this);
        this.getServer().getPluginManager().registerEvents((Listener)new GameListener(this, this.manager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        Bukkit.getScheduler().runTaskTimer((Plugin)this, this::tickWinAnnouncements, 0L, 5L);
        MinigamesCommand minigamesCommand = new MinigamesCommand(this, this.manager);
        this.getCommand("zm").setExecutor((CommandExecutor)minigamesCommand);
        this.getCommand("zm").setTabCompleter((TabCompleter)minigamesCommand);
        Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.tryInit(0), 60L);
    }

    private void tryInit(int n) {
        String string = this.getConfig().getString("world", "pvp");
        World world = Bukkit.getWorld((String)string);
        if (world == null) {
            if (n < 30) {
                Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.tryInit(n + 1), 100L);
            } else {
                this.getLogger().severe("World '" + string + "' tidak ditemukan. Pastikan world itu sudah dibuat di Multiverse, lalu restart server.");
            }
            return;
        }
        this.applyExtraRules(world);
        this.manager.init(world);
    }

    /** Gamerule tambahan untuk world minigame + command opsional dari config (hooks.on-init). */
    private void applyExtraRules(World world) {
        try {
            world.setGameRule(org.bukkit.GameRule.SHOW_DEATH_MESSAGES, false);
            world.setGameRule(org.bukkit.GameRule.DO_INSOMNIA, false);
            world.setGameRule(org.bukkit.GameRule.DO_PATROL_SPAWNING, false);
            world.setGameRule(org.bukkit.GameRule.DO_TRADER_SPAWNING, false);
            world.setGameRule(org.bukkit.GameRule.DO_ENTITY_DROPS, false);
            world.setGameRule(org.bukkit.GameRule.DO_TILE_DROPS, false);
            world.setTime(6000L);
        }
        catch (Exception exception) {
            this.getLogger().warning("Gagal menerapkan gamerule tambahan: " + exception.getMessage());
        }
        for (String string : this.getConfig().getStringList("hooks.on-init")) {
            Bukkit.dispatchCommand((org.bukkit.command.CommandSender)Bukkit.getConsoleSender(), string);
        }
    }

    public void onDisable() {
        if (this.manager != null) {
            this.manager.shutdown();
        }
        if (this.winBar != null) {
            this.winBar.removeAll();
        }
        this.winAnnouncements.clear();
    }

    public GameManager manager() {
        return this.manager;
    }

    public void announceWin(String string, String string2) {
        this.winAnnouncements.add(ChatColor.translateAlternateColorCodes((char)'&', (String)("&6&l\u2605 &e" + string + " &a&lWIN &f" + string2 + " &6&l\u2605")));
    }

    private void tickWinAnnouncements() {
        String string;
        if (this.winBar != null) {
            this.announcementTicks -= 5;
            if (this.announcementTicks > 0) {
                this.winBar.setProgress((double)this.announcementTicks / 100.0);
                return;
            }
            this.winBar.removeAll();
            this.winBar = null;
        }
        if ((string = this.winAnnouncements.poll()) == null) {
            return;
        }
        this.announcementTicks = 100;
        this.winBar = Bukkit.createBossBar((String)string, (BarColor)BarColor.YELLOW, (BarStyle)BarStyle.SOLID, (BarFlag[])new BarFlag[0]);
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.winBar.addPlayer(player);
        }
    }

    @EventHandler
    public void onAnnouncementJoin(PlayerJoinEvent playerJoinEvent) {
        if (this.winBar != null) {
            this.winBar.addPlayer(playerJoinEvent.getPlayer());
        }
    }

    @EventHandler
    public void onAnnouncementQuit(PlayerQuitEvent playerQuitEvent) {
        if (this.winBar != null) {
            this.winBar.removePlayer(playerQuitEvent.getPlayer());
        }
    }

    public YamlConfiguration data() {
        return this.data;
    }

    public boolean isBuilt(String string) {
        return this.data.getBoolean("built." + string, false);
    }

    public void markBuilt(String string, boolean bl) {
        this.data.set("built." + string, (Object)bl);
        this.saveData();
    }

    public void saveData() {
        try {
            this.data.save(this.dataFile);
        }
        catch (IOException iOException) {
            this.getLogger().warning("Gagal menyimpan data.yml: " + iOException.getMessage());
        }
    }

    public void setScale(Player player, double d) {
        Attribute attribute = (Attribute)Registry.ATTRIBUTE.get(NamespacedKey.minecraft((String)"scale"));
        if (attribute == null) {
            return;
        }
        AttributeInstance attributeInstance = player.getAttribute(attribute);
        if (attributeInstance != null && attributeInstance.getBaseValue() != d) {
            attributeInstance.setBaseValue(d);
        }
    }

    public ItemStack lobbyItem(Material material, String string, String string2, String ... stringArray) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.displayName(Msg.c(string));
        if (stringArray.length > 0) {
            ArrayList<Component> arrayList = new ArrayList<Component>();
            for (String string3 : stringArray) {
                arrayList.add(Msg.c(string3));
            }
            itemMeta.lore(arrayList);
        }
        itemMeta.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, string2);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public ItemStack leaveItem() {
        return this.lobbyItem(Material.RED_DYE, "&c&lKeluar &7(klik kanan)", "leave", "&7Kembali ke tempat semula");
    }

    public String itemId(ItemStack itemStack) {
        if (itemStack == null || !itemStack.hasItemMeta()) {
            return null;
        }
        return (String)itemStack.getItemMeta().getPersistentDataContainer().get(this.itemKey, PersistentDataType.STRING);
    }
}

