/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import org.jetbrains.annotations.NotNull;

public final class ReflectedObjectHandle
implements ReflectiveHandle<ReflectedObject> {
    private final ReflectiveOperation jvmGetter;

    public ReflectedObjectHandle(ReflectiveOperation jvmGetter) {
        this.jvmGetter = jvmGetter;
    }

    @Override
    public ReflectiveHandle<ReflectedObject> copy() {
        return new ReflectedObjectHandle(this.jvmGetter);
    }

    @Override
    @NotNull
    public ReflectedObject reflect() throws ReflectiveOperationException {
        return this.jvmGetter.get();
    }

    @Override
    @NotNull
    public ReflectiveHandle<ReflectedObject> jvm() {
        return this;
    }

    @FunctionalInterface
    public static interface ReflectiveOperation {
        public ReflectedObject get() throws ReflectiveOperationException;
    }
}

