package id.zentra.minigames.libs.com.cryptomorin.xseries.art;

import id.zentra.minigames.libs.com.cryptomorin.xseries.AbstractReferencedClass;
import org.bukkit.Art;

public abstract class BukkitArt extends AbstractReferencedClass<Art> {
   public abstract int getBlockWidth();

   public abstract int getBlockHeight();

   public abstract String getKey();

   public abstract int getId();
}
