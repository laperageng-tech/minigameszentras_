/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.inventory.ItemStack
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

public final class ColorRushGame
extends Game {
    private static final String[] C = new String[]{"WHITE", "ORANGE", "MAGENTA", "LIGHT_BLUE", "YELLOW", "LIME", "PINK", "CYAN", "PURPLE", "BLUE", "GREEN", "RED"};
    private static final String[] N = new String[]{"Putih", "Oranye", "Magenta", "Biru Muda", "Kuning", "Hijau Muda", "Pink", "Sian", "Ungu", "Biru", "Hijau", "Merah"};
    private static final Material[] M = new Material[12];
    private static final int HALF = 18;
    private static final int TILE = 3;
    private static final int T = 12;
    private final int[][] tiles = new int[12][12];
    private int phase;
    private int timer;
    private int round;
    private int target;

    public ColorRushGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "colorrush", "Color Rush", Material.LIME_CONCRETE, n, n2, n3, n4, 2, 16, List.of("Berdiri di warna yang diminta sebelum musik berhenti!", "Tiap ronde sebuah warna ditampilkan di hotbar dan layarmu. Warna lain akan lenyap.", "Waktu berpikir makin singkat setiap ronde. Dorong lawan dari warna aman dengan pukulan!", "Yang jatuh ke void tersingkir. Bertahan sampai ronde ke-25 atau jadi satu-satunya."));
        this.voidY = n3 - 8;
    }

    private void randomTiles() {
        for (int i = 0; i < 12; ++i) {
            for (int j = 0; j < 12; ++j) {
                this.tiles[i][j] = this.rnd.nextInt(12);
            }
        }
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        this.randomTiles();
        blueprint.cone(this.cx, this.by - 16, this.cz, 19, 12, Material.AMETHYST_BLOCK);
        for (int i = 0; i < 12; ++i) {
            for (int j = 0; j < 12; ++j) {
                int n = this.cx - 18 + i * 3;
                int n2 = this.cz - 18 + j * 3;
                blueprint.fill(n, this.by, n2, n + 3 - 1, this.by, n2 + 3 - 1, M[this.tiles[i][j]]);
            }
        }
        for (int[] nArray : new int[][]{{24, 24}, {-24, 24}, {24, -24}, {-24, -24}}) {
            int n = this.cx + nArray[0];
            int n3 = this.cz + nArray[1];
            blueprint.fill(n, this.by - 12, n3, n, this.by + 8, n3, Material.BLACK_CONCRETE);
            blueprint.set(n, this.by + 9, n3, Material.NOTE_BLOCK);
            blueprint.set(n, this.by + 10, n3, Material.SEA_LANTERN);
        }
    }

    private void paintFloor() {
        this.randomTiles();
        for (int i = 0; i < 12; ++i) {
            for (int j = 0; j < 12; ++j) {
                for (int k = 0; k < 3; ++k) {
                    for (int i2 = 0; i2 < 3; ++i2) {
                        this.world.getBlockAt(this.cx - 18 + i * 3 + k, this.by, this.cz - 18 + j * 3 + i2).setType(M[this.tiles[i][j]], false);
                    }
                }
            }
        }
    }

    private void clearOthers() {
        for (int i = 0; i < 12; ++i) {
            for (int j = 0; j < 12; ++j) {
                if (this.tiles[i][j] == this.target) continue;
                for (int k = 0; k < 3; ++k) {
                    for (int i2 = 0; i2 < 3; ++i2) {
                        this.world.getBlockAt(this.cx - 18 + i * 3 + k, this.by, this.cz - 18 + j * 3 + i2).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    @Override
    protected void onStart() {
        this.round = 0;
        this.phase = 0;
        this.timer = 3;
        this.paintFloor();
        this.spreadRing(this.alivePlayers(), 12.0, this.by + 1);
    }

    @Override
    protected void onSecond() {
        block10: {
            block11: {
                block9: {
                    --this.timer;
                    if (this.phase != 0) break block9;
                    if (this.timer <= 0) {
                        ++this.round;
                        this.target = this.tiles[this.rnd.nextInt(12)][this.rnd.nextInt(12)];
                        this.phase = 1;
                        this.timer = Math.max(2, 8 - this.round / 2);
                        for (Player player : this.alivePlayers()) {
                            ItemStack itemStack = this.item(M[this.target], 1, "&f&lBerdiri di: " + N[this.target], new String[0]);
                            for (int i = 0; i < 9; ++i) {
                                player.getInventory().setItem(i, itemStack);
                            }
                            Msg.title(player, "&e&lRONDE " + this.round, "&fBerdiri di warna &b&l" + N[this.target], 0, 30, 5);
                        }
                        this.sound(Sound.BLOCK_NOTE_BLOCK_BIT, 1.0f, 1.2f);
                    } else {
                        for (Player player : this.alivePlayers()) {
                            Msg.bar(player, "&eBersiap...");
                        }
                    }
                    break block10;
                }
                if (this.phase != 1) break block11;
                for (Player player : this.alivePlayers()) {
                    Msg.bar(player, "&fBerdiri di &b&l" + N[this.target] + " &8| &c" + Math.max(0, this.timer) + "s");
                    player.setLevel(Math.max(0, this.timer));
                }
                this.sound(Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 1.0f + (1.0f - (float)this.timer / 8.0f));
                if (this.timer > 0) break block10;
                this.clearOthers();
                this.sound(Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1.5f);
                this.phase = 2;
                this.timer = 3;
                break block10;
            }
            if (this.timer <= 0) {
                if (this.round >= 25) {
                    this.end(this.alivePlayers());
                    return;
                }
                this.paintFloor();
                this.phase = 0;
                this.timer = 2;
                for (Player player : this.alivePlayers()) {
                    player.getInventory().clear();
                    player.setLevel(0);
                }
            }
        }
    }

    @Override
    protected void onHit(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setDamage(0.0);
    }

    @Override
    protected String barText() {
        return "&dColor Rush &8| &fRonde &e" + this.round + " &8| &fHidup: &a" + this.alive.size();
    }

    static {
        for (int i = 0; i < 12; ++i) {
            ColorRushGame.M[i] = Material.valueOf((String)(C[i] + "_CONCRETE"));
        }
    }
}

