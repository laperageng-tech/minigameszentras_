/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Experimental
 *  org.jetbrains.annotations.ApiStatus$NonExtendable
 *  org.jetbrains.annotations.ApiStatus$OverrideOnly
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 *  org.jetbrains.annotations.Range
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations.Ignore;
import java.lang.reflect.Array;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Range;

@ApiStatus.Experimental
public interface ReflectiveProxyObject {
    @Ignore
    @NotNull
    @ApiStatus.NonExtendable
    @Contract(pure=true)
    public Object instance();

    @Ignore
    @NotNull
    @ApiStatus.NonExtendable
    @Contract(pure=true)
    public Class<?> getTargetClass();

    @Ignore
    @ApiStatus.NonExtendable
    @Contract(pure=true)
    default public boolean isInstance(@Nullable Object object) {
        return object != null && this.getTargetClass().isInstance(object.getClass());
    }

    @Ignore
    @NotNull
    @ApiStatus.NonExtendable
    @Contract(pure=true)
    default public Object[] newArray(@Range(from=0L, to=0x7FFFFFFFL) int length) {
        return (Object[])Array.newInstance(this.getTargetClass(), length);
    }

    @Ignore
    @NotNull
    @ApiStatus.NonExtendable
    @Contract(pure=true)
    default public Object[] newArray(int ... dimensions) {
        return (Object[])Array.newInstance(this.getTargetClass(), dimensions);
    }

    @Ignore
    @NotNull
    @ApiStatus.OverrideOnly
    @Contract(value="_ -> new", pure=true)
    public ReflectiveProxyObject bindTo(@NotNull Object var1);
}

