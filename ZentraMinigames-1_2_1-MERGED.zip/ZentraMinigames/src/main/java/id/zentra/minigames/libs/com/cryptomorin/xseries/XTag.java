package id.zentra.minigames.libs.com.cryptomorin.xseries;

import id.zentra.minigames.libs.com.cryptomorin.xseries.base.XBase;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import org.bukkit.Material;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class XTag<T extends XBase<?, ?>> {
   @NotNull
   public static final XTag<XMaterial> AIR;
   @NotNull
   public static final XTag<XMaterial> INVENTORY_NOT_DISPLAYABLE;
   @NotNull
   public static final XTag<XMaterial> ACACIA_LOGS;
   @NotNull
   public static final XTag<XMaterial> CORAL_FANS;
   @NotNull
   public static final XTag<XMaterial> ALIVE_CORAL_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> ALIVE_CORAL_FANS;
   @NotNull
   public static final XTag<XMaterial> ALIVE_CORAL_PLANTS;
   @NotNull
   public static final XTag<XMaterial> ALIVE_CORAL_WALL_FANS;
   @NotNull
   public static final XTag<XMaterial> SPAWN_EGGS;
   @NotNull
   public static final XTag<XMaterial> ANIMALS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> ANVIL;
   @NotNull
   public static final XTag<XMaterial> AXOLOTL_TEMPT_ITEMS;
   @NotNull
   public static final XTag<XMaterial> AXOLOTLS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> AZALEA_GROWS_ON;
   @NotNull
   public static final XTag<XMaterial> AZALEA_ROOT_REPLACEABLE;
   @NotNull
   public static final XTag<XMaterial> BAMBOO_LOGS;
   @NotNull
   public static final XTag<XMaterial> BAMBOO_PLANTABLE_ON;
   @NotNull
   public static final XTag<XMaterial> BANNERS;
   @NotNull
   public static final XTag<XMaterial> BASE_STONE_NETHER;
   @NotNull
   public static final XTag<XMaterial> BASE_STONE_OVERWORLD;
   @NotNull
   public static final XTag<XMaterial> BEACON_BASE_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> BEDS;
   @NotNull
   public static final XTag<XMaterial> BEE_GROWABLES;
   @NotNull
   public static final XTag<XMaterial> BIG_DRIPLEAF_PLACEABLE;
   @NotNull
   public static final XTag<XMaterial> BIRCH_LOGS;
   @NotNull
   public static final XTag<XMaterial> BUTTONS;
   @NotNull
   public static final XTag<XMaterial> CAMPFIRES;
   @NotNull
   public static final XTag<XMaterial> CANDLE_CAKES;
   @NotNull
   public static final XTag<XMaterial> CANDLES;
   @NotNull
   public static final XTag<XMaterial> CARPETS;
   @NotNull
   public static final XTag<XMaterial> CAULDRONS;
   @NotNull
   public static final XTag<XMaterial> CAVE_VINES;
   @NotNull
   public static final XTag<XMaterial> CHERRY_LOGS;
   @NotNull
   public static final XTag<XMaterial> CLIMBABLE;
   @NotNull
   public static final XTag<XMaterial> CLUSTER_MAX_HARVESTABLES;
   @NotNull
   public static final XTag<XMaterial> COAL_ORES;
   @NotNull
   public static final XTag<XMaterial> CONCRETE;
   @NotNull
   public static final XTag<XMaterial> CONCRETE_POWDER;
   @NotNull
   public static final XTag<XMaterial> COPPER_ORES;
   @NotNull
   public static final XTag<XMaterial> CORALS;
   @NotNull
   public static final XTag<XMaterial> CRIMSON_STEMS;
   @NotNull
   public static final XTag<XMaterial> CROPS;
   @NotNull
   public static final XTag<XMaterial> CRYSTAL_SOUND_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> DARK_OAK_LOGS;
   @NotNull
   public static final XTag<XMaterial> DEAD_CORAL_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> DEAD_CORAL_FANS;
   @NotNull
   public static final XTag<XMaterial> DEAD_CORAL_PLANTS;
   @NotNull
   public static final XTag<XMaterial> DEAD_CORAL_WALL_FANS;
   @NotNull
   public static final XTag<XMaterial> DEEPSLATE_ORE_REPLACEABLES;
   @NotNull
   public static final XTag<XMaterial> DIAMOND_ORES;
   @NotNull
   public static final XTag<XMaterial> DIRT;
   @NotNull
   public static final XTag<XMaterial> DOORS;
   @NotNull
   public static final XTag<XMaterial> DRAGON_IMMUNE;
   @NotNull
   public static final XTag<XMaterial> DRIPSTONE_REPLACEABLE;
   @NotNull
   public static final XTag<XMaterial> WALL_HEADS;
   @NotNull
   public static final XTag<XMaterial> EMERALD_ORES;
   @NotNull
   public static final XTag<XMaterial> ENDERMAN_HOLDABLE;
   @NotNull
   public static final XTag<XMaterial> FEATURES_CANNOT_REPLACE;
   @NotNull
   public static final XTag<XMaterial> FENCE_GATES;
   @NotNull
   public static final XTag<XMaterial> FENCES;
   @NotNull
   public static final XTag<XMaterial> FILLED_CAULDRONS;
   @NotNull
   public static final XTag<XMaterial> FIRE;
   @NotNull
   public static final XTag<XMaterial> FLOWER_POTS;
   @NotNull
   public static final XTag<XMaterial> FLOWERS;
   @NotNull
   public static final XTag<XMaterial> FOX_FOOD;
   @NotNull
   public static final XTag<XMaterial> FOXES_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> FREEZE_IMMUNE_WEARABLES;
   @NotNull
   public static final XTag<XMaterial> GEODE_INVALID_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> GLASS;
   @NotNull
   public static final XTag<XMaterial> GLAZED_TERRACOTTA;
   @NotNull
   public static final XTag<XMaterial> GOATS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> GOLD_ORES;
   @NotNull
   public static final XTag<XMaterial> GUARDED_BY_PIGLINS;
   @NotNull
   public static final XTag<XMaterial> HANGING_SIGNS;
   @NotNull
   public static final XTag<XMaterial> HOGLIN_REPELLENTS;
   @NotNull
   public static final XTag<XMaterial> ICE;
   @NotNull
   public static final XTag<XMaterial> IGNORED_BY_PIGLIN_BABIES;
   @NotNull
   public static final XTag<XMaterial> IMPERMEABLE;
   @NotNull
   public static final XTag<XMaterial> INFINIBURN_END;
   @NotNull
   public static final XTag<XMaterial> INFINIBURN_NETHER;
   @NotNull
   public static final XTag<XMaterial> INFINIBURN_OVERWORLD;
   @NotNull
   public static final XTag<XMaterial> INSIDE_STEP_SOUND_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> IRON_ORES;
   @NotNull
   public static final XTag<XMaterial> ITEMS_ARROWS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_BANNERS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_BEACON_PAYMENT_ITEMS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_BOATS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_COALS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_CREEPER_DROP_MUSIC_DISCS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_FISHES;
   @NotNull
   public static final XTag<XMaterial> ITEMS_FURNACE_MATERIALS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_LECTERN_BOOKS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_MUSIC_DISCS;
   @NotNull
   public static final XTag<XMaterial> ITEMS_PIGLIN_LOVED;
   @NotNull
   public static final XTag<XMaterial> ITEMS_STONE_TOOL_MATERIALS;
   @NotNull
   public static final XTag<XMaterial> WALL_BANNERS;
   @NotNull
   public static final XTag<XMaterial> JUNGLE_LOGS;
   @NotNull
   public static final XTag<XMaterial> LAPIS_ORES;
   @NotNull
   public static final XTag<XMaterial> LAVA_POOL_STONE_CANNOT_REPLACE;
   @NotNull
   public static final XTag<XMaterial> LEAVES;
   @NotNull
   public static final XTag<XMaterial> LOGS;
   @NotNull
   public static final XTag<XMaterial> LOGS_THAT_BURN;
   @NotNull
   public static final XTag<XMaterial> LUSH_GROUND_REPLACEABLE;
   @NotNull
   public static final XTag<XMaterial> MANGROVE_LOGS;
   @NotNull
   public static final XTag<XMaterial> MINEABLE_AXE;
   @NotNull
   public static final XTag<XMaterial> MINEABLE_HOE;
   @NotNull
   public static final XTag<XMaterial> MINEABLE_PICKAXE;
   @NotNull
   public static final XTag<XMaterial> MINEABLE_SHOVEL;
   @NotNull
   public static final XTag<XMaterial> MOOSHROOMS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> MOSS_REPLACEABLE;
   @NotNull
   public static final XTag<XMaterial> MUSHROOM_GROW_BLOCK;
   @NotNull
   public static final XTag<XMaterial> NEEDS_DIAMOND_TOOL;
   @NotNull
   public static final XTag<XMaterial> NEEDS_IRON_TOOL;
   @NotNull
   public static final XTag<XMaterial> NEEDS_STONE_TOOL;
   @NotNull
   public static final XTag<XMaterial> NON_FLAMMABLE_WOOD;
   @NotNull
   public static final XTag<XMaterial> NON_WOODEN_STAIRS;
   @NotNull
   public static final XTag<XMaterial> NON_WOODEN_SLABS;
   @NotNull
   public static final XTag<XMaterial> NYLIUM;
   @NotNull
   public static final XTag<XMaterial> OAK_LOGS;
   @NotNull
   public static final XTag<XMaterial> OCCLUDES_VIBRATION_SIGNALS;
   @NotNull
   public static final XTag<XMaterial> ORES;
   @NotNull
   public static final XTag<XMaterial> PALE_OAK_LOGS;
   @NotNull
   public static final XTag<XMaterial> PARROTS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> PIGLIN_FOOD;
   @NotNull
   public static final XTag<XMaterial> PIGLIN_REPELLENTS;
   @NotNull
   public static final XTag<XMaterial> PLANKS;
   @NotNull
   public static final XTag<XMaterial> POLAR_BEARS_SPAWNABLE_ON_IN_FROZEN_OCEAN;
   @NotNull
   public static final XTag<XMaterial> PORTALS;
   @NotNull
   public static final XTag<XMaterial> POTTERY_SHERDS;
   @NotNull
   public static final XTag<XMaterial> PRESSURE_PLATES;
   @NotNull
   public static final XTag<XMaterial> PREVENT_MOB_SPAWNING_INSIDE;
   @NotNull
   public static final XTag<XMaterial> RABBITS_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> RAILS;
   @NotNull
   public static final XTag<XMaterial> REDSTONE_ORES;
   @NotNull
   public static final XTag<XMaterial> REPLACEABLE_PLANTS;
   @NotNull
   public static final XTag<XMaterial> SAND;
   @NotNull
   public static final XTag<XMaterial> SAPLINGS;
   @NotNull
   public static final XTag<XMaterial> SHULKER_BOXES;
   @NotNull
   public static final XTag<XMaterial> SIGNS;
   @NotNull
   public static final XTag<XMaterial> SMALL_DRIPLEAF_PLACEABLE;
   @NotNull
   public static final XTag<XMaterial> SMALL_FLOWERS;
   @NotNull
   public static final XTag<XMaterial> SMITHING_TEMPLATES;
   @NotNull
   public static final XTag<XMaterial> SNOW;
   @NotNull
   public static final XTag<XMaterial> SOUL_FIRE_BASE_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> SOUL_SPEED_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> SPRUCE_LOGS;
   @NotNull
   public static final XTag<XMaterial> STAIRS;
   @NotNull
   public static final XTag<XMaterial> STANDING_SIGNS;
   @NotNull
   public static final XTag<XMaterial> STONE_BRICKS;
   @NotNull
   public static final XTag<XMaterial> STONE_ORE_REPLACEABLES;
   @NotNull
   public static final XTag<XMaterial> STONE_PRESSURE_PLATES;
   @NotNull
   public static final XTag<XMaterial> STRIDER_WARM_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> TALL_FLOWERS;
   @NotNull
   public static final XTag<XMaterial> TERRACOTTA;
   @NotNull
   public static final XTag<XMaterial> TRAPDOORS;
   @NotNull
   public static final XTag<XMaterial> UNDERWATER_BONEMEALS;
   @NotNull
   public static final XTag<XMaterial> UNSTABLE_BOTTOM_CENTER;
   @NotNull
   public static final XTag<XMaterial> VALID_SPAWN;
   @NotNull
   public static final XTag<XMaterial> WALL_HANGING_SIGNS;
   @NotNull
   public static final XTag<XMaterial> WALL_POST_OVERRIDE;
   @NotNull
   public static final XTag<XMaterial> WALL_SIGNS;
   @NotNull
   public static final XTag<XMaterial> WALL_TORCHES;
   @NotNull
   public static final XTag<XMaterial> WALLS;
   @NotNull
   public static final XTag<XMaterial> WARPED_STEMS;
   @NotNull
   public static final XTag<XMaterial> WITHER_IMMUNE;
   @NotNull
   public static final XTag<XMaterial> WITHER_SUMMON_BASE_BLOCKS;
   @NotNull
   public static final XTag<XMaterial> WOLVES_SPAWNABLE_ON;
   @NotNull
   public static final XTag<XMaterial> WOODEN_BUTTONS;
   @NotNull
   public static final XTag<XMaterial> WOODEN_DOORS;
   @NotNull
   public static final XTag<XMaterial> WOODEN_FENCE_GATES;
   @NotNull
   public static final XTag<XMaterial> WOODEN_FENCES;
   @NotNull
   public static final XTag<XMaterial> WOODEN_PRESSURE_PLATES;
   @NotNull
   public static final XTag<XMaterial> WOODEN_SLABS;
   @NotNull
   public static final XTag<XMaterial> WOODEN_STAIRS;
   @NotNull
   public static final XTag<XMaterial> WOODEN_TRAPDOORS;
   @NotNull
   public static final XTag<XMaterial> WOOL;
   @NotNull
   public static final XTag<XMaterial> LEATHER_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> IRON_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> CHAINMAIL_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> COPPER_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> GOLDEN_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> DIAMOND_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> NETHERITE_ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> ARMOR_PIECES;
   @NotNull
   public static final XTag<XMaterial> WOODEN_TOOLS;
   @NotNull
   public static final XTag<XMaterial> FLUID;
   @NotNull
   public static final XTag<XMaterial> STONE_TOOLS;
   @NotNull
   public static final XTag<XMaterial> COPPER_TOOLS;
   @NotNull
   public static final XTag<XMaterial> IRON_TOOLS;
   @NotNull
   public static final XTag<XMaterial> GOLDEN_TOOLS;
   @NotNull
   public static final XTag<XMaterial> DIAMOND_TOOLS;
   @NotNull
   public static final XTag<XMaterial> NETHERITE_TOOLS;
   @NotNull
   public static final XTag<XMaterial> SWORDS;
   @NotNull
   public static final XTag<XMaterial> PICKAXES;
   @NotNull
   public static final XTag<XMaterial> AXES;
   @NotNull
   public static final XTag<XMaterial> SHOVELS;
   @NotNull
   public static final XTag<XMaterial> HOES;
   @NotNull
   public static final XTag<XMaterial> DANGEROUS_BLOCKS;
   @NotNull
   public static final XTag<XEnchantment> ARMOR_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> HELEMT_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> CHESTPLATE_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> LEGGINGS_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> BOOTS_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> ELYTRA_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> SWORD_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> AXE_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> HOE_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> PICKAXE_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> SHOVEL_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> SHEARS_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> BOW_ENCHANTS;
   @NotNull
   public static final XTag<XEnchantment> CROSSBOW_ENCHANTS;
   @NotNull
   public static final XTag<XEntityType> EFFECTIVE_SMITE_ENTITIES;
   @NotNull
   public static final XTag<XEntityType> EFFECTIVE_BANE_OF_ARTHROPODS_ENTITIES;
   @NotNull
   public static final XTag<XPotion> DEBUFFS;
   public static final Map<XMaterial, XEntityType> MATERIAL_TO_ENTITY;
   @NotNull
   private final Set<T> values;
   private static final Map<String, XTag<?>> TAGS;

   private XTag(@NotNull Set<T> values) {
      this.values = values;
   }

   public static <E> List<XTag.Matcher<E>> stringMatcher(@Nullable Collection<String> elements) {
      return stringMatcher(elements, null);
   }

   public static <E> List<XTag.Matcher<E>> stringMatcher(@Nullable Collection<String> elements, @Nullable Collection<XTag.Matcher.Error> errors) {
      if (elements != null && !elements.isEmpty()) {
         List<XTag.Matcher<E>> matchers = new ArrayList<>(elements.size());

         for (String comp : elements) {
            String checker = comp.toUpperCase(Locale.ENGLISH);
            if (checker.startsWith("CONTAINS:")) {
               comp = XMaterial.format(checker.substring(9));
               matchers.add(new XTag.Matcher.TextMatcher(comp, true));
            } else if (checker.startsWith("REGEX:")) {
               comp = comp.substring(6);

               try {
                  matchers.add(new XTag.Matcher.RegexMatcher(Pattern.compile(comp)));
               } catch (Throwable var7) {
                  if (errors != null) {
                     errors.add(new XTag.Matcher.Error(comp, "REGEX", var7));
                  }
               }
            } else {
               if (checker.startsWith("TAG:")) {
                  comp = XMaterial.format(comp.substring(4));
                  Optional<XTag<?>> tag = getTag(comp);
                  if (tag.isPresent()) {
                     matchers.add((XTag.Matcher<E>)(new XTag.Matcher.XTagMatcher<>(tag.get())));
                  } else {
                     errors.add(new XTag.Matcher.Error("Cannot find tag: " + comp, "TAG"));
                  }
               }

               matchers.add(new XTag.Matcher.TextMatcher(comp, false));
            }
         }

         return matchers;
      } else {
         return new ArrayList<>();
      }
   }

   public static <T> boolean anyMatchString(T target, Collection<String> matchers) {
      return anyMatch(target, stringMatcher(matchers));
   }

   public static <T> boolean anyMatch(T target, Collection<XTag.Matcher<T>> matchers) {
      return matchers.stream().anyMatch(x -> x.matches(target));
   }

   private static XMaterial[] findAllColors(String material) {
      String[] colorPrefixes = new String[]{
         "ORANGE", "LIGHT_BLUE", "GRAY", "BLACK", "MAGENTA", "PINK", "BLUE", "GREEN", "CYAN", "PURPLE", "YELLOW", "LIME", "LIGHT_GRAY", "WHITE", "BROWN", "RED"
      };
      List<XMaterial> list = new ArrayList<>();
      XMaterial.matchXMaterial(material).ifPresent(list::add);

      for (String color : colorPrefixes) {
         XMaterial.matchXMaterial(color + '_' + material).ifPresent(list::add);
      }

      return list.toArray(new XMaterial[0]);
   }

   private static XMaterial[] findAllWoodTypes(String material) {
      String[] woodPrefixes = new String[]{
         "ACACIA", "DARK_OAK", "PALE_OAK", "JUNGLE", "BIRCH", "WARPED", "OAK", "SPRUCE", "CRIMSON", "MANGROVE", "CHERRY", "BAMBOO"
      };
      List<XMaterial> list = new ArrayList<>();

      for (String wood : woodPrefixes) {
         XMaterial.matchXMaterial(wood + '_' + material).ifPresent(list::add);
      }

      return list.toArray(new XMaterial[0]);
   }

   private static XMaterial[] findMaterialsEndingWith(String material) {
      return Arrays.stream(XMaterial.VALUES).filter(x -> x.name().endsWith(material)).toArray(XMaterial[]::new);
   }

   private static XMaterial[] findMaterialsStartingWith(String material) {
      return Arrays.stream(XMaterial.VALUES).filter(x -> x.name().startsWith(material)).toArray(XMaterial[]::new);
   }

   private static XMaterial[] findAllCorals(boolean alive, boolean block, boolean fan, boolean wall) {
      String[] materials = new String[]{"FIRE", "TUBE", "BRAIN", "HORN", "BUBBLE"};
      List<XMaterial> list = new ArrayList<>();

      for (String material : materials) {
         StringBuilder builder = new StringBuilder();
         if (!alive) {
            builder.append("DEAD_");
         }

         builder.append(material).append("_CORAL");
         if (block) {
            builder.append("_BLOCK");
         }

         if (fan) {
            if (wall) {
               builder.append("_WALL");
            }

            builder.append("_FAN");
         }

         XMaterial.matchXMaterial(builder.toString()).ifPresent(list::add);
      }

      return list.toArray(new XMaterial[0]);
   }

   public static boolean isItem(XMaterial material) {
      if (!XMaterial.supports(1, 13)) {
         switch (material) {
            case ATTACHED_MELON_STEM:
            case ATTACHED_PUMPKIN_STEM:
            case BEETROOTS:
            case BLACK_WALL_BANNER:
            case BLUE_WALL_BANNER:
            case BROWN_WALL_BANNER:
            case CARROTS:
            case COCOA:
            case CREEPER_WALL_HEAD:
            case CYAN_WALL_BANNER:
            case DRAGON_WALL_HEAD:
            case END_GATEWAY:
            case END_PORTAL:
            case FIRE:
            case FIRE_CORAL_WALL_FAN:
            case FROSTED_ICE:
            case GRAY_WALL_BANNER:
            case GREEN_WALL_BANNER:
            case HORN_CORAL_WALL_FAN:
            case LAVA:
            case LIGHT_BLUE_WALL_BANNER:
            case LIGHT_GRAY_WALL_BANNER:
            case LIME_WALL_BANNER:
            case MAGENTA_WALL_BANNER:
            case MELON_STEM:
            case MOVING_PISTON:
            case NETHER_PORTAL:
            case ORANGE_WALL_BANNER:
            case PINK_WALL_BANNER:
            case PISTON_HEAD:
            case PLAYER_WALL_HEAD:
            case POTATOES:
            case POTTED_ACACIA_SAPLING:
            case POTTED_ALLIUM:
            case POTTED_AZURE_BLUET:
            case POTTED_BIRCH_SAPLING:
            case POTTED_BLUE_ORCHID:
            case POTTED_BROWN_MUSHROOM:
            case POTTED_CACTUS:
            case POTTED_DANDELION:
            case POTTED_DARK_OAK_SAPLING:
            case POTTED_PALE_OAK_SAPLING:
            case POTTED_DEAD_BUSH:
            case POTTED_FERN:
            case POTTED_JUNGLE_SAPLING:
            case POTTED_OAK_SAPLING:
            case POTTED_ORANGE_TULIP:
            case POTTED_OXEYE_DAISY:
            case POTTED_PINK_TULIP:
            case POTTED_POPPY:
            case POTTED_RED_MUSHROOM:
            case POTTED_RED_TULIP:
            case POTTED_SPRUCE_SAPLING:
            case POTTED_WHITE_TULIP:
            case PUMPKIN_STEM:
            case PURPLE_WALL_BANNER:
            case REDSTONE_WALL_TORCH:
            case REDSTONE_WIRE:
            case RED_WALL_BANNER:
            case SKELETON_WALL_SKULL:
            case TRIPWIRE:
            case ACACIA_WALL_SIGN:
            case OAK_WALL_SIGN:
            case BIRCH_WALL_SIGN:
            case JUNGLE_WALL_SIGN:
            case SPRUCE_WALL_SIGN:
            case DARK_OAK_WALL_SIGN:
            case PALE_OAK_WALL_SIGN:
            case WALL_TORCH:
            case WATER:
            case WHITE_WALL_BANNER:
            case WITHER_SKELETON_WALL_SKULL:
            case YELLOW_WALL_BANNER:
            case ZOMBIE_WALL_HEAD:
               return false;
            default:
               return true;
         }
      } else {
         Material mat = material.get();
         return mat != null && mat.isItem();
      }
   }

   public static boolean isInteractable(XMaterial material) {
      if (XMaterial.supports(1, 13)) {
         return material.get().isInteractable();
      } else {
         switch (material) {
            case MOVING_PISTON:
            case POTTED_ACACIA_SAPLING:
            case POTTED_ALLIUM:
            case POTTED_AZURE_BLUET:
            case POTTED_BIRCH_SAPLING:
            case POTTED_BLUE_ORCHID:
            case POTTED_BROWN_MUSHROOM:
            case POTTED_CACTUS:
            case POTTED_DANDELION:
            case POTTED_DARK_OAK_SAPLING:
            case POTTED_PALE_OAK_SAPLING:
            case POTTED_DEAD_BUSH:
            case POTTED_FERN:
            case POTTED_JUNGLE_SAPLING:
            case POTTED_OAK_SAPLING:
            case POTTED_ORANGE_TULIP:
            case POTTED_OXEYE_DAISY:
            case POTTED_PINK_TULIP:
            case POTTED_POPPY:
            case POTTED_RED_MUSHROOM:
            case POTTED_RED_TULIP:
            case POTTED_SPRUCE_SAPLING:
            case POTTED_WHITE_TULIP:
            case ACACIA_WALL_SIGN:
            case OAK_WALL_SIGN:
            case BIRCH_WALL_SIGN:
            case JUNGLE_WALL_SIGN:
            case SPRUCE_WALL_SIGN:
            case DARK_OAK_WALL_SIGN:
            case PALE_OAK_WALL_SIGN:
            case ACACIA_BUTTON:
            case ACACIA_DOOR:
            case ACACIA_FENCE:
            case ACACIA_FENCE_GATE:
            case ACACIA_STAIRS:
            case ACACIA_TRAPDOOR:
            case ANVIL:
            case BEACON:
            case BIRCH_BUTTON:
            case BIRCH_DOOR:
            case BIRCH_FENCE:
            case PALE_OAK_BUTTON:
            case PALE_OAK_DOOR:
            case PALE_OAK_FENCE:
            case PALE_OAK_FENCE_GATE:
            case PALE_OAK_STAIRS:
            case PALE_OAK_TRAPDOOR:
            case BIRCH_FENCE_GATE:
            case BIRCH_STAIRS:
            case BIRCH_TRAPDOOR:
            case BLACK_BED:
            case BLACK_SHULKER_BOX:
            case BLUE_BED:
            case BLUE_SHULKER_BOX:
            case BREWING_STAND:
            case BRICK_STAIRS:
            case BROWN_BED:
            case BROWN_SHULKER_BOX:
            case CAKE:
            case CAULDRON:
            case CHAIN_COMMAND_BLOCK:
            case CHEST:
            case CHIPPED_ANVIL:
            case COBBLESTONE_STAIRS:
            case COMMAND_BLOCK:
            case COMPARATOR:
            case CRAFTING_TABLE:
            case CYAN_BED:
            case CYAN_SHULKER_BOX:
            case DAMAGED_ANVIL:
            case DARK_OAK_BUTTON:
            case DARK_OAK_DOOR:
            case DARK_OAK_FENCE:
            case DARK_OAK_FENCE_GATE:
            case DARK_OAK_STAIRS:
            case DARK_OAK_TRAPDOOR:
            case DARK_PRISMARINE_STAIRS:
            case DAYLIGHT_DETECTOR:
            case DISPENSER:
            case DRAGON_EGG:
            case DROPPER:
            case ENCHANTING_TABLE:
            case ENDER_CHEST:
            case FLOWER_POT:
            case FURNACE:
            case GRAY_BED:
            case GRAY_SHULKER_BOX:
            case GREEN_BED:
            case GREEN_SHULKER_BOX:
            case HOPPER:
            case IRON_DOOR:
            case IRON_TRAPDOOR:
            case JUKEBOX:
            case JUNGLE_BUTTON:
            case JUNGLE_DOOR:
            case JUNGLE_FENCE:
            case JUNGLE_FENCE_GATE:
            case JUNGLE_STAIRS:
            case JUNGLE_TRAPDOOR:
            case LEVER:
            case LIGHT_BLUE_BED:
            case LIGHT_BLUE_SHULKER_BOX:
            case LIGHT_GRAY_BED:
            case LIGHT_GRAY_SHULKER_BOX:
            case LIME_BED:
            case LIME_SHULKER_BOX:
            case MAGENTA_BED:
            case MAGENTA_SHULKER_BOX:
            case NETHER_BRICK_FENCE:
            case NETHER_BRICK_STAIRS:
            case NOTE_BLOCK:
            case OAK_BUTTON:
            case OAK_DOOR:
            case OAK_FENCE:
            case OAK_FENCE_GATE:
            case OAK_STAIRS:
            case OAK_TRAPDOOR:
            case ORANGE_BED:
            case ORANGE_SHULKER_BOX:
            case PINK_BED:
            case PINK_SHULKER_BOX:
            case PRISMARINE_BRICK_STAIRS:
            case PRISMARINE_STAIRS:
            case PUMPKIN:
            case PURPLE_BED:
            case PURPLE_SHULKER_BOX:
            case PURPUR_STAIRS:
            case QUARTZ_STAIRS:
            case REDSTONE_ORE:
            case RED_BED:
            case RED_SANDSTONE_STAIRS:
            case RED_SHULKER_BOX:
            case REPEATER:
            case REPEATING_COMMAND_BLOCK:
            case SANDSTONE_STAIRS:
            case SHULKER_BOX:
            case ACACIA_SIGN:
            case BIRCH_SIGN:
            case DARK_OAK_SIGN:
            case JUNGLE_SIGN:
            case OAK_SIGN:
            case SPRUCE_SIGN:
            case SPRUCE_BUTTON:
            case SPRUCE_DOOR:
            case SPRUCE_FENCE:
            case SPRUCE_FENCE_GATE:
            case SPRUCE_STAIRS:
            case SPRUCE_TRAPDOOR:
            case STONE_BRICK_STAIRS:
            case STONE_BUTTON:
            case STRUCTURE_BLOCK:
            case TNT:
            case TRAPPED_CHEST:
            case WHITE_BED:
            case WHITE_SHULKER_BOX:
            case YELLOW_BED:
            case YELLOW_SHULKER_BOX:
               return true;
            case NETHER_PORTAL:
            case ORANGE_WALL_BANNER:
            case PINK_WALL_BANNER:
            case PISTON_HEAD:
            case PLAYER_WALL_HEAD:
            case POTATOES:
            case PUMPKIN_STEM:
            case PURPLE_WALL_BANNER:
            case REDSTONE_WALL_TORCH:
            case REDSTONE_WIRE:
            case RED_WALL_BANNER:
            case SKELETON_WALL_SKULL:
            case TRIPWIRE:
            case WALL_TORCH:
            case WATER:
            case WHITE_WALL_BANNER:
            case WITHER_SKELETON_WALL_SKULL:
            case YELLOW_WALL_BANNER:
            case ZOMBIE_WALL_HEAD:
            default:
               return false;
         }
      }
   }

   @NotNull
   public Set<T> getValues() {
      return this.values;
   }

   public boolean isTagged(@Nullable T value) {
      return value != null && this.values.contains(value);
   }

   @SafeVarargs
   private final XTag<T> without(T... without) {
      Set<T> newSet = new HashSet<>(this.values);

      for (T value : without) {
         newSet.remove(value);
      }

      return new XTag<>(newSet);
   }

   public static Optional<XTag<?>> getTag(String name) {
      return Optional.ofNullable(TAGS.get(name));
   }

   static {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      //
      // Bytecode:
      // 0000: bipush 3
      // 0001: anewarray 338
      // 0004: dup
      // 0005: bipush 0
      // 0006: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0009: aastore
      // 000a: dup
      // 000b: bipush 1
      // 000c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAVE_AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 000f: aastore
      // 0010: dup
      // 0011: bipush 2
      // 0012: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.VOID_AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0015: aastore
      // 0016: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0019: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 001c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.values ()[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 001f: invokestatic java/util/Arrays.stream ([Ljava/lang/Object;)Ljava/util/stream/Stream;
      // 0022: invokedynamic test ()Ljava/util/function/Predicate; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ (Ljava/lang/Object;)Z, id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.lambda$static$0 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;)Z, (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;)Z ]
      // 0027: invokeinterface java/util/stream/Stream.filter (Ljava/util/function/Predicate;)Ljava/util/stream/Stream; 2
      // 002c: invokedynamic apply ()Ljava/util/function/IntFunction; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ (I)Ljava/lang/Object;, id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.lambda$SPAWN_EGGS$0 (I)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;, (I)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial; ]
      // 0031: invokeinterface java/util/stream/Stream.toArray (Ljava/util/function/IntFunction;)[Ljava/lang/Object; 2
      // 0036: checkcast [Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0039: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 003c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 003f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SPAWN_EGGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0042: bipush 2
      // 0043: anewarray 338
      // 0046: dup
      // 0047: bipush 0
      // 0048: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 004b: aastore
      // 004c: dup
      // 004d: bipush 1
      // 004e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0051: aastore
      // 0052: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0055: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0058: bipush 3
      // 0059: anewarray 338
      // 005c: dup
      // 005d: bipush 0
      // 005e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_GATEWAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0061: aastore
      // 0062: dup
      // 0063: bipush 1
      // 0064: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_PORTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0067: aastore
      // 0068: dup
      // 0069: bipush 2
      // 006a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_PORTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 006d: aastore
      // 006e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0071: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PORTALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0074: bipush 2
      // 0075: anewarray 338
      // 0078: dup
      // 0079: bipush 0
      // 007a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 007d: aastore
      // 007e: dup
      // 007f: bipush 1
      // 0080: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WATER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0083: aastore
      // 0084: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0087: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FLUID Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 008a: bipush 5
      // 008b: anewarray 338
      // 008e: dup
      // 008f: bipush 0
      // 0090: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MAGMA_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0093: aastore
      // 0094: dup
      // 0095: bipush 1
      // 0096: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0099: aastore
      // 009a: dup
      // 009b: bipush 2
      // 009c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAMPFIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 009f: aastore
      // 00a0: dup
      // 00a1: bipush 3
      // 00a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 00a5: aastore
      // 00a6: dup
      // 00a7: bipush 4
      // 00a8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 00ab: aastore
      // 00ac: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 00af: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DANGEROUS_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 00b2: bipush 10
      // 00b4: anewarray 817
      // 00b7: dup
      // 00b8: bipush 0
      // 00b9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.ZOMBIE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00bc: aastore
      // 00bd: dup
      // 00be: bipush 1
      // 00bf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.SKELETON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00c2: aastore
      // 00c3: dup
      // 00c4: bipush 2
      // 00c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.WITHER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00c8: aastore
      // 00c9: dup
      // 00ca: bipush 3
      // 00cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.BEE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00ce: aastore
      // 00cf: dup
      // 00d0: bipush 4
      // 00d1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.PHANTOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00d4: aastore
      // 00d5: dup
      // 00d6: bipush 5
      // 00d7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.DROWNED Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00da: aastore
      // 00db: dup
      // 00dc: bipush 6
      // 00de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.WITHER_SKELETON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00e1: aastore
      // 00e2: dup
      // 00e3: bipush 7
      // 00e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.SKELETON_HORSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00e8: aastore
      // 00e9: dup
      // 00ea: bipush 8
      // 00ec: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.STRAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00ef: aastore
      // 00f0: dup
      // 00f1: bipush 9
      // 00f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.HUSK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 00f6: aastore
      // 00f7: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 00fa: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.EFFECTIVE_SMITE_ENTITIES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 00fd: bipush 4
      // 00fe: anewarray 817
      // 0101: dup
      // 0102: bipush 0
      // 0103: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.SPIDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 0106: aastore
      // 0107: dup
      // 0108: bipush 1
      // 0109: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.CAVE_SPIDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 010c: aastore
      // 010d: dup
      // 010e: bipush 2
      // 010f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.SILVERFISH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 0112: aastore
      // 0113: dup
      // 0114: bipush 3
      // 0115: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.ENDERMITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 0118: aastore
      // 0119: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 011c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.EFFECTIVE_BANE_OF_ARTHROPODS_ENTITIES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 011f: bipush 12
      // 0121: anewarray 866
      // 0124: dup
      // 0125: bipush 0
      // 0126: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.BAD_OMEN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0129: aastore
      // 012a: dup
      // 012b: bipush 1
      // 012c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.BLINDNESS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 012f: aastore
      // 0130: dup
      // 0131: bipush 2
      // 0132: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.NAUSEA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0135: aastore
      // 0136: dup
      // 0137: bipush 3
      // 0138: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.INSTANT_DAMAGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 013b: aastore
      // 013c: dup
      // 013d: bipush 4
      // 013e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.HUNGER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0141: aastore
      // 0142: dup
      // 0143: bipush 5
      // 0144: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.LEVITATION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0147: aastore
      // 0148: dup
      // 0149: bipush 6
      // 014b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.POISON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 014e: aastore
      // 014f: dup
      // 0150: bipush 7
      // 0152: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.SLOWNESS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0155: aastore
      // 0156: dup
      // 0157: bipush 8
      // 0159: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.MINING_FATIGUE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 015c: aastore
      // 015d: dup
      // 015e: bipush 9
      // 0160: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.UNLUCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0163: aastore
      // 0164: dup
      // 0165: bipush 10
      // 0167: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.WEAKNESS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 016a: aastore
      // 016b: dup
      // 016c: bipush 11
      // 016e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XPotion.WITHER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XPotion;
      // 0171: aastore
      // 0172: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0175: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEBUFFS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0178: new java/util/HashMap
      // 017b: dup
      // 017c: invokespecial java/util/HashMap.<init> ()V
      // 017f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 0182: bipush 4
      // 0183: anewarray 338
      // 0186: dup
      // 0187: bipush 0
      // 0188: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_ACACIA_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 018b: aastore
      // 018c: dup
      // 018d: bipush 1
      // 018e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0191: aastore
      // 0192: dup
      // 0193: bipush 2
      // 0194: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0197: aastore
      // 0198: dup
      // 0199: bipush 3
      // 019a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_ACACIA_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 019d: aastore
      // 019e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01a1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ACACIA_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01a4: bipush 4
      // 01a5: anewarray 338
      // 01a8: dup
      // 01a9: bipush 0
      // 01aa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_BIRCH_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01ad: aastore
      // 01ae: dup
      // 01af: bipush 1
      // 01b0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01b3: aastore
      // 01b4: dup
      // 01b5: bipush 2
      // 01b6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01b9: aastore
      // 01ba: dup
      // 01bb: bipush 3
      // 01bc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_BIRCH_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01bf: aastore
      // 01c0: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01c3: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BIRCH_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01c6: bipush 4
      // 01c7: anewarray 338
      // 01ca: dup
      // 01cb: bipush 0
      // 01cc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_DARK_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01cf: aastore
      // 01d0: dup
      // 01d1: bipush 1
      // 01d2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01d5: aastore
      // 01d6: dup
      // 01d7: bipush 2
      // 01d8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01db: aastore
      // 01dc: dup
      // 01dd: bipush 3
      // 01de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_DARK_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01e1: aastore
      // 01e2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01e5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DARK_OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 01e8: bipush 4
      // 01e9: anewarray 338
      // 01ec: dup
      // 01ed: bipush 0
      // 01ee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_JUNGLE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01f1: aastore
      // 01f2: dup
      // 01f3: bipush 1
      // 01f4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01f7: aastore
      // 01f8: dup
      // 01f9: bipush 2
      // 01fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 01fd: aastore
      // 01fe: dup
      // 01ff: bipush 3
      // 0200: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_JUNGLE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0203: aastore
      // 0204: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0207: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.JUNGLE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 020a: bipush 4
      // 020b: anewarray 338
      // 020e: dup
      // 020f: bipush 0
      // 0210: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_MANGROVE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0213: aastore
      // 0214: dup
      // 0215: bipush 1
      // 0216: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0219: aastore
      // 021a: dup
      // 021b: bipush 2
      // 021c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 021f: aastore
      // 0220: dup
      // 0221: bipush 3
      // 0222: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_MANGROVE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0225: aastore
      // 0226: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0229: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MANGROVE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 022c: bipush 4
      // 022d: anewarray 338
      // 0230: dup
      // 0231: bipush 0
      // 0232: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0235: aastore
      // 0236: dup
      // 0237: bipush 1
      // 0238: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 023b: aastore
      // 023c: dup
      // 023d: bipush 2
      // 023e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0241: aastore
      // 0242: dup
      // 0243: bipush 3
      // 0244: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0247: aastore
      // 0248: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 024b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 024e: bipush 4
      // 024f: anewarray 338
      // 0252: dup
      // 0253: bipush 0
      // 0254: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_PALE_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0257: aastore
      // 0258: dup
      // 0259: bipush 1
      // 025a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 025d: aastore
      // 025e: dup
      // 025f: bipush 2
      // 0260: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0263: aastore
      // 0264: dup
      // 0265: bipush 3
      // 0266: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_PALE_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0269: aastore
      // 026a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 026d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PALE_OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0270: bipush 4
      // 0271: anewarray 338
      // 0274: dup
      // 0275: bipush 0
      // 0276: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_SPRUCE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0279: aastore
      // 027a: dup
      // 027b: bipush 1
      // 027c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 027f: aastore
      // 0280: dup
      // 0281: bipush 2
      // 0282: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0285: aastore
      // 0286: dup
      // 0287: bipush 3
      // 0288: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_SPRUCE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 028b: aastore
      // 028c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 028f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SPRUCE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0292: bipush 4
      // 0293: anewarray 338
      // 0296: dup
      // 0297: bipush 0
      // 0298: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CHERRY_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 029b: aastore
      // 029c: dup
      // 029d: bipush 1
      // 029e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02a1: aastore
      // 02a2: dup
      // 02a3: bipush 2
      // 02a4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02a7: aastore
      // 02a8: dup
      // 02a9: bipush 3
      // 02aa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CHERRY_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02ad: aastore
      // 02ae: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02b1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CHERRY_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02b4: bipush 4
      // 02b5: anewarray 338
      // 02b8: dup
      // 02b9: bipush 0
      // 02ba: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_BAMBOO_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02bd: aastore
      // 02be: dup
      // 02bf: bipush 1
      // 02c0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02c3: aastore
      // 02c4: dup
      // 02c5: bipush 2
      // 02c6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_MOSAIC Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02c9: aastore
      // 02ca: dup
      // 02cb: bipush 3
      // 02cc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02cf: aastore
      // 02d0: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02d3: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BAMBOO_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02d6: ldc_w "CANDLE_CAKE"
      // 02d9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02dc: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02df: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CANDLE_CAKES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02e2: ldc_w "CANDLE"
      // 02e5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02e8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02eb: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CANDLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02ee: ldc_w "TERRACOTTA"
      // 02f1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 02f4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02f7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TERRACOTTA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 02fa: ldc_w "GLAZED_TERRACOTTA"
      // 02fd: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0300: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0303: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GLAZED_TERRACOTTA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0306: ldc_w "SHULKER_BOX"
      // 0309: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 030c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 030f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHULKER_BOXES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0312: ldc_w "CARPET"
      // 0315: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0318: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 031b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CARPETS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 031e: ldc_w "WOOL"
      // 0321: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0324: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0327: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 032a: ldc_w "GLASS"
      // 032d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0330: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0333: bipush 1
      // 0334: anewarray 2
      // 0337: dup
      // 0338: bipush 0
      // 0339: bipush 1
      // 033a: anewarray 338
      // 033d: dup
      // 033e: bipush 0
      // 033f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TINTED_GLASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0342: aastore
      // 0343: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0346: aastore
      // 0347: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 034a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 034d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GLASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0350: ldc_w "BANNER"
      // 0353: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0356: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0359: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 035c: ldc_w "WALL_BANNER"
      // 035f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0362: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0365: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0368: bipush 2
      // 0369: anewarray 2
      // 036c: dup
      // 036d: bipush 0
      // 036e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0371: aastore
      // 0372: dup
      // 0373: bipush 1
      // 0374: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0377: aastore
      // 0378: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 037b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 037e: ldc_w "BED"
      // 0381: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0384: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0387: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BEDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 038a: ldc_w "CONCRETE"
      // 038d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0390: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0393: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CONCRETE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0396: ldc_w "CONCRETE_POWDER"
      // 0399: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllColors (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 039c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 039f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CONCRETE_POWDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03a2: ldc_w "SIGN"
      // 03a5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03a8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03ab: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STANDING_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03ae: ldc_w "WALL_SIGN"
      // 03b1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03b4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03b7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03ba: ldc_w "WALL_HANGING_SIGN"
      // 03bd: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03c0: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03c3: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_HANGING_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03c6: ldc_w "HANGING_SIGN"
      // 03c9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03cc: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03cf: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.HANGING_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03d2: ldc_w "PRESSURE_PLATE"
      // 03d5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03d8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03db: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03de: ldc_w "DOOR"
      // 03e1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03e4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03e7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_DOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03ea: ldc_w "FENCE_GATE"
      // 03ed: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03f0: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03f3: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCE_GATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03f6: ldc_w "FENCE"
      // 03f9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 03fc: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 03ff: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0402: ldc_w "SLAB"
      // 0405: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0408: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 040b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_SLABS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 040e: ldc_w "STAIRS"
      // 0411: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0414: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0417: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 041a: ldc_w "TRAPDOOR"
      // 041d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0420: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0423: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_TRAPDOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0426: ldc_w "PLANKS"
      // 0429: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 042c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 042f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0432: ldc_w "BUTTON"
      // 0435: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllWoodTypes (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0438: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 043b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_BUTTONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 043e: bipush 2
      // 043f: anewarray 338
      // 0442: dup
      // 0443: bipush 0
      // 0444: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAL_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0447: aastore
      // 0448: dup
      // 0449: bipush 1
      // 044a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_COAL_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 044d: aastore
      // 044e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0451: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COAL_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0454: bipush 2
      // 0455: anewarray 338
      // 0458: dup
      // 0459: bipush 0
      // 045a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 045d: aastore
      // 045e: dup
      // 045f: bipush 1
      // 0460: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_IRON_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0463: aastore
      // 0464: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0467: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 046a: bipush 2
      // 046b: anewarray 338
      // 046e: dup
      // 046f: bipush 0
      // 0470: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0473: aastore
      // 0474: dup
      // 0475: bipush 1
      // 0476: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_COPPER_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0479: aastore
      // 047a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 047d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0480: bipush 2
      // 0481: anewarray 338
      // 0484: dup
      // 0485: bipush 0
      // 0486: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0489: aastore
      // 048a: dup
      // 048b: bipush 1
      // 048c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_REDSTONE_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 048f: aastore
      // 0490: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0493: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.REDSTONE_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0496: bipush 2
      // 0497: anewarray 338
      // 049a: dup
      // 049b: bipush 0
      // 049c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAPIS_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 049f: aastore
      // 04a0: dup
      // 04a1: bipush 1
      // 04a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_LAPIS_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04a5: aastore
      // 04a6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04a9: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LAPIS_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04ac: bipush 3
      // 04ad: anewarray 338
      // 04b0: dup
      // 04b1: bipush 0
      // 04b2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04b5: aastore
      // 04b6: dup
      // 04b7: bipush 1
      // 04b8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_GOLD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04bb: aastore
      // 04bc: dup
      // 04bd: bipush 2
      // 04be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_GOLD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04c1: aastore
      // 04c2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04c5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04c8: bipush 2
      // 04c9: anewarray 338
      // 04cc: dup
      // 04cd: bipush 0
      // 04ce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04d1: aastore
      // 04d2: dup
      // 04d3: bipush 1
      // 04d4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_DIAMOND_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04d7: aastore
      // 04d8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04db: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04de: bipush 2
      // 04df: anewarray 338
      // 04e2: dup
      // 04e3: bipush 0
      // 04e4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04e7: aastore
      // 04e8: dup
      // 04e9: bipush 1
      // 04ea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_EMERALD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04ed: aastore
      // 04ee: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04f1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.EMERALD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 04f4: bipush 2
      // 04f5: anewarray 338
      // 04f8: dup
      // 04f9: bipush 0
      // 04fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANCIENT_DEBRIS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 04fd: aastore
      // 04fe: dup
      // 04ff: bipush 1
      // 0500: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_QUARTZ_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0503: aastore
      // 0504: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0507: bipush 8
      // 0509: anewarray 2
      // 050c: dup
      // 050d: bipush 0
      // 050e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COAL_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0511: aastore
      // 0512: dup
      // 0513: bipush 1
      // 0514: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0517: aastore
      // 0518: dup
      // 0519: bipush 2
      // 051a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 051d: aastore
      // 051e: dup
      // 051f: bipush 3
      // 0520: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.REDSTONE_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0523: aastore
      // 0524: dup
      // 0525: bipush 4
      // 0526: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LAPIS_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0529: aastore
      // 052a: dup
      // 052b: bipush 5
      // 052c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 052f: aastore
      // 0530: dup
      // 0531: bipush 6
      // 0533: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0536: aastore
      // 0537: dup
      // 0538: bipush 7
      // 053a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.EMERALD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 053d: aastore
      // 053e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0541: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0544: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0547: bipush 1
      // 0548: bipush 0
      // 0549: bipush 1
      // 054a: bipush 1
      // 054b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 054e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0551: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0554: bipush 1
      // 0555: bipush 0
      // 0556: bipush 1
      // 0557: bipush 0
      // 0558: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 055b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 055e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0561: bipush 1
      // 0562: bipush 1
      // 0563: bipush 0
      // 0564: bipush 0
      // 0565: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0568: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 056b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 056e: bipush 1
      // 056f: bipush 0
      // 0570: bipush 0
      // 0571: bipush 0
      // 0572: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0575: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0578: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_PLANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 057b: bipush 0
      // 057c: bipush 0
      // 057d: bipush 1
      // 057e: bipush 1
      // 057f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0582: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0585: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0588: bipush 0
      // 0589: bipush 0
      // 058a: bipush 1
      // 058b: bipush 0
      // 058c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 058f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0592: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0595: bipush 0
      // 0596: bipush 1
      // 0597: bipush 0
      // 0598: bipush 0
      // 0599: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 059c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 059f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05a2: bipush 0
      // 05a3: bipush 0
      // 05a4: bipush 0
      // 05a5: bipush 0
      // 05a6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findAllCorals (ZZZZ)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 05a9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05ac: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_PLANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05af: bipush 4
      // 05b0: anewarray 2
      // 05b3: dup
      // 05b4: bipush 0
      // 05b5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05b8: aastore
      // 05b9: dup
      // 05ba: bipush 1
      // 05bb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05be: aastore
      // 05bf: dup
      // 05c0: bipush 2
      // 05c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05c4: aastore
      // 05c5: dup
      // 05c6: bipush 3
      // 05c7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05ca: aastore
      // 05cb: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05ce: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05d1: bipush 8
      // 05d3: anewarray 2
      // 05d6: dup
      // 05d7: bipush 0
      // 05d8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05db: aastore
      // 05dc: dup
      // 05dd: bipush 1
      // 05de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05e1: aastore
      // 05e2: dup
      // 05e3: bipush 2
      // 05e4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05e7: aastore
      // 05e8: dup
      // 05e9: bipush 3
      // 05ea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_PLANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05ed: aastore
      // 05ee: dup
      // 05ef: bipush 4
      // 05f0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05f3: aastore
      // 05f4: dup
      // 05f5: bipush 5
      // 05f6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 05f9: aastore
      // 05fa: dup
      // 05fb: bipush 6
      // 05fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0600: aastore
      // 0601: dup
      // 0602: bipush 7
      // 0604: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_PLANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0607: aastore
      // 0608: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 060b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CORALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 060e: bipush 2
      // 060f: anewarray 2
      // 0612: dup
      // 0613: bipush 0
      // 0614: ldc_w "WALL_HEAD"
      // 0617: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.findMaterialsEndingWith (Ljava/lang/String;)[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 061a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 061d: aastore
      // 061e: dup
      // 061f: bipush 1
      // 0620: bipush 2
      // 0621: anewarray 338
      // 0624: dup
      // 0625: bipush 0
      // 0626: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WITHER_SKELETON_WALL_SKULL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0629: aastore
      // 062a: dup
      // 062b: bipush 1
      // 062c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SKELETON_WALL_SKULL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 062f: aastore
      // 0630: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0633: aastore
      // 0634: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0637: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_HEADS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 063a: bipush 3
      // 063b: anewarray 338
      // 063e: dup
      // 063f: bipush 0
      // 0640: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WALL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0643: aastore
      // 0644: dup
      // 0645: bipush 1
      // 0646: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_WALL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0649: aastore
      // 064a: dup
      // 064b: bipush 2
      // 064c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_WALL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 064f: aastore
      // 0650: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0653: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_TORCHES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0656: bipush 21
      // 0658: anewarray 338
      // 065b: dup
      // 065c: bipush 0
      // 065d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DEEPSLATE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0660: aastore
      // 0661: dup
      // 0662: bipush 1
      // 0663: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0666: aastore
      // 0667: dup
      // 0668: bipush 2
      // 0669: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 066c: aastore
      // 066d: dup
      // 066e: bipush 3
      // 066f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0672: aastore
      // 0673: dup
      // 0674: bipush 4
      // 0675: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SANDSTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0678: aastore
      // 0679: dup
      // 067a: bipush 5
      // 067b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 067e: aastore
      // 067f: dup
      // 0680: bipush 6
      // 0682: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLESTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0685: aastore
      // 0686: dup
      // 0687: bipush 7
      // 0689: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 068c: aastore
      // 068d: dup
      // 068e: bipush 8
      // 0690: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0693: aastore
      // 0694: dup
      // 0695: bipush 9
      // 0697: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SANDSTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 069a: aastore
      // 069b: dup
      // 069c: bipush 10
      // 069e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06a1: aastore
      // 06a2: dup
      // 06a3: bipush 11
      // 06a5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_TILE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06a8: aastore
      // 06a9: dup
      // 06aa: bipush 12
      // 06ac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06af: aastore
      // 06b0: dup
      // 06b1: bipush 13
      // 06b3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06b6: aastore
      // 06b7: dup
      // 06b8: bipush 14
      // 06ba: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_NETHER_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06bd: aastore
      // 06be: dup
      // 06bf: bipush 15
      // 06c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06c4: aastore
      // 06c5: dup
      // 06c6: bipush 16
      // 06c8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_COBBLESTONE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06cb: aastore
      // 06cc: dup
      // 06cd: bipush 17
      // 06cf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06d2: aastore
      // 06d3: dup
      // 06d4: bipush 18
      // 06d6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_STONE_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06d9: aastore
      // 06da: dup
      // 06db: bipush 19
      // 06dd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE_BRICK_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06e0: aastore
      // 06e1: dup
      // 06e2: bipush 20
      // 06e4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLED_DEEPSLATE_WALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06e7: aastore
      // 06e8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 06eb: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 06ee: bipush 2
      // 06ef: anewarray 338
      // 06f2: dup
      // 06f3: bipush 0
      // 06f4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06f7: aastore
      // 06f8: dup
      // 06f9: bipush 1
      // 06fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 06fd: aastore
      // 06fe: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0701: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STONE_PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0704: bipush 4
      // 0705: anewarray 338
      // 0708: dup
      // 0709: bipush 0
      // 070a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 070d: aastore
      // 070e: dup
      // 070f: bipush 1
      // 0710: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACTIVATOR_RAIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0713: aastore
      // 0714: dup
      // 0715: bipush 2
      // 0716: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DETECTOR_RAIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0719: aastore
      // 071a: dup
      // 071b: bipush 3
      // 071c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWERED_RAIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 071f: aastore
      // 0720: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0723: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.RAILS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0726: bipush 1
      // 0727: anewarray 338
      // 072a: dup
      // 072b: bipush 0
      // 072c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 072f: aastore
      // 0730: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0733: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ANIMALS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0736: bipush 3
      // 0737: anewarray 338
      // 073a: dup
      // 073b: bipush 0
      // 073c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANVIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 073f: aastore
      // 0740: dup
      // 0741: bipush 1
      // 0742: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHIPPED_ANVIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0745: aastore
      // 0746: dup
      // 0747: bipush 2
      // 0748: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DAMAGED_ANVIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 074b: aastore
      // 074c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 074f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ANVIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0752: bipush 1
      // 0753: anewarray 338
      // 0756: dup
      // 0757: bipush 0
      // 0758: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TROPICAL_FISH_BUCKET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 075b: aastore
      // 075c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 075f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AXOLOTL_TEMPT_ITEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0762: bipush 1
      // 0763: anewarray 338
      // 0766: dup
      // 0767: bipush 0
      // 0768: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 076b: aastore
      // 076c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 076f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AXOLOTLS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0772: bipush 3
      // 0773: anewarray 338
      // 0776: dup
      // 0777: bipush 0
      // 0778: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 077b: aastore
      // 077c: dup
      // 077d: bipush 1
      // 077e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0781: aastore
      // 0782: dup
      // 0783: bipush 2
      // 0784: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0787: aastore
      // 0788: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 078b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 078e: bipush 2
      // 078f: anewarray 338
      // 0792: dup
      // 0793: bipush 0
      // 0794: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0797: aastore
      // 0798: dup
      // 0799: bipush 1
      // 079a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 079d: aastore
      // 079e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07a1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07a4: bipush 7
      // 07a6: anewarray 338
      // 07a9: dup
      // 07aa: bipush 0
      // 07ab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07ae: aastore
      // 07af: dup
      // 07b0: bipush 1
      // 07b1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COARSE_DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07b4: aastore
      // 07b5: dup
      // 07b6: bipush 2
      // 07b7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PODZOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07ba: aastore
      // 07bb: dup
      // 07bc: bipush 3
      // 07bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07c0: aastore
      // 07c1: dup
      // 07c2: bipush 4
      // 07c3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ROOTED_DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07c6: aastore
      // 07c7: dup
      // 07c8: bipush 5
      // 07c9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MYCELIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07cc: aastore
      // 07cd: dup
      // 07ce: bipush 6
      // 07d0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07d3: aastore
      // 07d4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07d7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07da: bipush 2
      // 07db: anewarray 338
      // 07de: dup
      // 07df: bipush 0
      // 07e0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07e3: aastore
      // 07e4: dup
      // 07e5: bipush 1
      // 07e6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAVE_VINES_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07e9: aastore
      // 07ea: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07ed: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 07f0: bipush 3
      // 07f1: anewarray 338
      // 07f4: dup
      // 07f5: bipush 0
      // 07f6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERRACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07f9: aastore
      // 07fa: dup
      // 07fb: bipush 1
      // 07fc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BASALT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 07ff: aastore
      // 0800: dup
      // 0801: bipush 2
      // 0802: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0805: aastore
      // 0806: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0809: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_NETHER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 080c: bipush 6
      // 080e: anewarray 338
      // 0811: dup
      // 0812: bipush 0
      // 0813: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TUFF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0816: aastore
      // 0817: dup
      // 0818: bipush 1
      // 0819: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 081c: aastore
      // 081d: dup
      // 081e: bipush 2
      // 081f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0822: aastore
      // 0823: dup
      // 0824: bipush 3
      // 0825: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0828: aastore
      // 0829: dup
      // 082a: bipush 4
      // 082b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 082e: aastore
      // 082f: dup
      // 0830: bipush 5
      // 0831: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0834: aastore
      // 0835: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0838: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 083b: bipush 5
      // 083c: anewarray 338
      // 083f: dup
      // 0840: bipush 0
      // 0841: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0844: aastore
      // 0845: dup
      // 0846: bipush 1
      // 0847: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 084a: aastore
      // 084b: dup
      // 084c: bipush 2
      // 084d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0850: aastore
      // 0851: dup
      // 0852: bipush 3
      // 0853: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0856: aastore
      // 0857: dup
      // 0858: bipush 4
      // 0859: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 085c: aastore
      // 085d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0860: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BEACON_BASE_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0863: bipush 24
      // 0865: anewarray 338
      // 0868: dup
      // 0869: bipush 0
      // 086a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARROT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 086d: aastore
      // 086e: dup
      // 086f: bipush 1
      // 0870: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARROTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0873: aastore
      // 0874: dup
      // 0875: bipush 2
      // 0876: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTATO Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0879: aastore
      // 087a: dup
      // 087b: bipush 3
      // 087c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTATOES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 087f: aastore
      // 0880: dup
      // 0881: bipush 4
      // 0882: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_WART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0885: aastore
      // 0886: dup
      // 0887: bipush 5
      // 0888: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUMPKIN_SEEDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 088b: aastore
      // 088c: dup
      // 088d: bipush 6
      // 088f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WHEAT_SEEDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0892: aastore
      // 0893: dup
      // 0894: bipush 7
      // 0896: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WHEAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0899: aastore
      // 089a: dup
      // 089b: bipush 8
      // 089d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MELON_SEEDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08a0: aastore
      // 08a1: dup
      // 08a2: bipush 9
      // 08a4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEETROOT_SEEDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08a7: aastore
      // 08a8: dup
      // 08a9: bipush 10
      // 08ab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEETROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08ae: aastore
      // 08af: dup
      // 08b0: bipush 11
      // 08b2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SUGAR_CANE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08b5: aastore
      // 08b6: dup
      // 08b7: bipush 12
      // 08b9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08bc: aastore
      // 08bd: dup
      // 08be: bipush 13
      // 08c0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08c3: aastore
      // 08c4: dup
      // 08c5: bipush 14
      // 08c7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHORUS_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08ca: aastore
      // 08cb: dup
      // 08cc: bipush 15
      // 08ce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.KELP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08d1: aastore
      // 08d2: dup
      // 08d3: bipush 16
      // 08d5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.KELP_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08d8: aastore
      // 08d9: dup
      // 08da: bipush 17
      // 08dc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SEA_PICKLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08df: aastore
      // 08e0: dup
      // 08e1: bipush 18
      // 08e3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BROWN_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08e6: aastore
      // 08e7: dup
      // 08e8: bipush 19
      // 08ea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08ed: aastore
      // 08ee: dup
      // 08ef: bipush 20
      // 08f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MELON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08f4: aastore
      // 08f5: dup
      // 08f6: bipush 21
      // 08f8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUMPKIN_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 08fb: aastore
      // 08fc: dup
      // 08fd: bipush 22
      // 08ff: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COCOA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0902: aastore
      // 0903: dup
      // 0904: bipush 23
      // 0906: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COCOA_BEANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0909: aastore
      // 090a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 090d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CROPS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0910: bipush 2
      // 0911: anewarray 338
      // 0914: dup
      // 0915: bipush 0
      // 0916: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAMPFIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0919: aastore
      // 091a: dup
      // 091b: bipush 1
      // 091c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_CAMPFIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 091f: aastore
      // 0920: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0923: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAMPFIRES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0926: bipush 3
      // 0927: anewarray 338
      // 092a: dup
      // 092b: bipush 0
      // 092c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 092f: aastore
      // 0930: dup
      // 0931: bipush 1
      // 0932: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0935: aastore
      // 0936: dup
      // 0937: bipush 2
      // 0938: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WATER_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 093b: aastore
      // 093c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 093f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FILLED_CAULDRONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0942: bipush 4
      // 0943: anewarray 338
      // 0946: dup
      // 0947: bipush 0
      // 0948: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 094b: aastore
      // 094c: dup
      // 094d: bipush 1
      // 094e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0951: aastore
      // 0952: dup
      // 0953: bipush 2
      // 0954: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0957: aastore
      // 0958: dup
      // 0959: bipush 3
      // 095a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WATER_CAULDRON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 095d: aastore
      // 095e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0961: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAULDRONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0964: bipush 7
      // 0966: anewarray 338
      // 0969: dup
      // 096a: bipush 0
      // 096b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SCAFFOLDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 096e: aastore
      // 096f: dup
      // 0970: bipush 1
      // 0971: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEEPING_VINES_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0974: aastore
      // 0975: dup
      // 0976: bipush 2
      // 0977: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEEPING_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 097a: aastore
      // 097b: dup
      // 097c: bipush 3
      // 097d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TWISTING_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0980: aastore
      // 0981: dup
      // 0982: bipush 4
      // 0983: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TWISTING_VINES_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0986: aastore
      // 0987: dup
      // 0988: bipush 5
      // 0989: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.VINE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 098c: aastore
      // 098d: dup
      // 098e: bipush 6
      // 0990: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LADDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0993: aastore
      // 0994: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0997: bipush 1
      // 0998: anewarray 2
      // 099b: dup
      // 099c: bipush 0
      // 099d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09a0: aastore
      // 09a1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 09a4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09a7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CLIMBABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09aa: bipush 6
      // 09ac: anewarray 338
      // 09af: dup
      // 09b0: bipush 0
      // 09b1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09b4: aastore
      // 09b5: dup
      // 09b6: bipush 1
      // 09b7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09ba: aastore
      // 09bb: dup
      // 09bc: bipush 2
      // 09bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09c0: aastore
      // 09c1: dup
      // 09c2: bipush 3
      // 09c3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09c6: aastore
      // 09c7: dup
      // 09c8: bipush 4
      // 09c9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09cc: aastore
      // 09cd: dup
      // 09ce: bipush 5
      // 09cf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09d2: aastore
      // 09d3: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09d6: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CLUSTER_MAX_HARVESTABLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09d9: bipush 4
      // 09da: anewarray 338
      // 09dd: dup
      // 09de: bipush 0
      // 09df: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09e2: aastore
      // 09e3: dup
      // 09e4: bipush 1
      // 09e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09e8: aastore
      // 09e9: dup
      // 09ea: bipush 2
      // 09eb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09ee: aastore
      // 09ef: dup
      // 09f0: bipush 3
      // 09f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 09f4: aastore
      // 09f5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09f8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CRIMSON_STEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 09fb: bipush 4
      // 09fc: anewarray 338
      // 09ff: dup
      // 0a00: bipush 0
      // 0a01: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a04: aastore
      // 0a05: dup
      // 0a06: bipush 1
      // 0a07: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a0a: aastore
      // 0a0b: dup
      // 0a0c: bipush 2
      // 0a0d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a10: aastore
      // 0a11: dup
      // 0a12: bipush 3
      // 0a13: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a16: aastore
      // 0a17: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a1a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WARPED_STEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a1d: bipush 2
      // 0a1e: anewarray 338
      // 0a21: dup
      // 0a22: bipush 0
      // 0a23: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AMETHYST_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a26: aastore
      // 0a27: dup
      // 0a28: bipush 1
      // 0a29: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BUDDING_AMETHYST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a2c: aastore
      // 0a2d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a30: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CRYSTAL_SOUND_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a33: bipush 2
      // 0a34: anewarray 338
      // 0a37: dup
      // 0a38: bipush 0
      // 0a39: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TUFF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a3c: aastore
      // 0a3d: dup
      // 0a3e: bipush 1
      // 0a3f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a42: aastore
      // 0a43: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a46: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEEPSLATE_ORE_REPLACEABLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a49: bipush 1
      // 0a4a: anewarray 338
      // 0a4d: dup
      // 0a4e: bipush 0
      // 0a4f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_DOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a52: aastore
      // 0a53: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0a56: bipush 1
      // 0a57: anewarray 2
      // 0a5a: dup
      // 0a5b: bipush 0
      // 0a5c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_DOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a5f: aastore
      // 0a60: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0a63: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a66: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0a69: bipush 11
      // 0a6b: anewarray 338
      // 0a6e: dup
      // 0a6f: bipush 0
      // 0a70: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRUCTURE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a73: aastore
      // 0a74: dup
      // 0a75: bipush 1
      // 0a76: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_GATEWAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a79: aastore
      // 0a7a: dup
      // 0a7b: bipush 2
      // 0a7c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEDROCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a7f: aastore
      // 0a80: dup
      // 0a81: bipush 3
      // 0a82: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_PORTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a85: aastore
      // 0a86: dup
      // 0a87: bipush 4
      // 0a88: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COMMAND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a8b: aastore
      // 0a8c: dup
      // 0a8d: bipush 5
      // 0a8e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REPEATING_COMMAND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a91: aastore
      // 0a92: dup
      // 0a93: bipush 6
      // 0a95: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOVING_PISTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a98: aastore
      // 0a99: dup
      // 0a9a: bipush 7
      // 0a9c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHAIN_COMMAND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0a9f: aastore
      // 0aa0: dup
      // 0aa1: bipush 8
      // 0aa3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BARRIER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0aa6: aastore
      // 0aa7: dup
      // 0aa8: bipush 9
      // 0aaa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_PORTAL_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0aad: aastore
      // 0aae: dup
      // 0aaf: bipush 10
      // 0ab1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JIGSAW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ab4: aastore
      // 0ab5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ab8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WITHER_IMMUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0abb: bipush 2
      // 0abc: anewarray 338
      // 0abf: dup
      // 0ac0: bipush 0
      // 0ac1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SOIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ac4: aastore
      // 0ac5: dup
      // 0ac6: bipush 1
      // 0ac7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0aca: aastore
      // 0acb: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ace: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WITHER_SUMMON_BASE_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ad1: bipush 2
      // 0ad2: anewarray 338
      // 0ad5: dup
      // 0ad6: bipush 0
      // 0ad7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ada: aastore
      // 0adb: dup
      // 0adc: bipush 1
      // 0add: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ae0: aastore
      // 0ae1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ae4: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ae7: bipush 13
      // 0ae9: anewarray 338
      // 0aec: dup
      // 0aed: bipush 0
      // 0aee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0af1: aastore
      // 0af2: dup
      // 0af3: bipush 1
      // 0af4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AZURE_BLUET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0af7: aastore
      // 0af8: dup
      // 0af9: bipush 2
      // 0afa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXEYE_DAISY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0afd: aastore
      // 0afe: dup
      // 0aff: bipush 3
      // 0b00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLUE_ORCHID Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b03: aastore
      // 0b04: dup
      // 0b05: bipush 4
      // 0b06: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PINK_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b09: aastore
      // 0b0a: dup
      // 0b0b: bipush 5
      // 0b0c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POPPY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b0f: aastore
      // 0b10: dup
      // 0b11: bipush 6
      // 0b13: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WHITE_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b16: aastore
      // 0b17: dup
      // 0b18: bipush 7
      // 0b1a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DANDELION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b1d: aastore
      // 0b1e: dup
      // 0b1f: bipush 8
      // 0b21: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ALLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b24: aastore
      // 0b25: dup
      // 0b26: bipush 9
      // 0b28: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CORNFLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b2b: aastore
      // 0b2c: dup
      // 0b2d: bipush 10
      // 0b2f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ORANGE_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b32: aastore
      // 0b33: dup
      // 0b34: bipush 11
      // 0b36: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LILY_OF_THE_VALLEY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b39: aastore
      // 0b3a: dup
      // 0b3b: bipush 12
      // 0b3d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WITHER_ROSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b40: aastore
      // 0b41: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b44: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SMALL_FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b47: bipush 4
      // 0b48: anewarray 338
      // 0b4b: dup
      // 0b4c: bipush 0
      // 0b4d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PEONY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b50: aastore
      // 0b51: dup
      // 0b52: bipush 1
      // 0b53: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SUNFLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b56: aastore
      // 0b57: dup
      // 0b58: bipush 2
      // 0b59: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LILAC Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b5c: aastore
      // 0b5d: dup
      // 0b5e: bipush 3
      // 0b5f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ROSE_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b62: aastore
      // 0b63: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b66: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TALL_FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b69: bipush 4
      // 0b6a: anewarray 338
      // 0b6d: dup
      // 0b6e: bipush 0
      // 0b6f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPAWNER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b72: aastore
      // 0b73: dup
      // 0b74: bipush 1
      // 0b75: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_PORTAL_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b78: aastore
      // 0b79: dup
      // 0b7a: bipush 2
      // 0b7b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEDROCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b7e: aastore
      // 0b7f: dup
      // 0b80: bipush 3
      // 0b81: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0b84: aastore
      // 0b85: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b88: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FEATURES_CANNOT_REPLACE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b8b: bipush 1
      // 0b8c: anewarray 2
      // 0b8f: dup
      // 0b90: bipush 0
      // 0b91: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCE_GATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b94: aastore
      // 0b95: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b98: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FENCE_GATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0b9b: bipush 1
      // 0b9c: anewarray 338
      // 0b9f: dup
      // 0ba0: bipush 0
      // 0ba1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICK_FENCE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ba4: aastore
      // 0ba5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0ba8: bipush 1
      // 0ba9: anewarray 2
      // 0bac: dup
      // 0bad: bipush 0
      // 0bae: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0bb1: aastore
      // 0bb2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 0bb5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0bb8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FENCES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0bbb: bipush 36
      // 0bbd: anewarray 338
      // 0bc0: dup
      // 0bc1: bipush 0
      // 0bc2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bc5: aastore
      // 0bc6: dup
      // 0bc7: bipush 1
      // 0bc8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_WITHER_ROSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bcb: aastore
      // 0bcc: dup
      // 0bcd: bipush 2
      // 0bce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_ACACIA_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bd1: aastore
      // 0bd2: dup
      // 0bd3: bipush 3
      // 0bd4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_LILY_OF_THE_VALLEY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bd7: aastore
      // 0bd8: dup
      // 0bd9: bipush 4
      // 0bda: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_WARPED_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bdd: aastore
      // 0bde: dup
      // 0bdf: bipush 5
      // 0be0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_WARPED_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0be3: aastore
      // 0be4: dup
      // 0be5: bipush 6
      // 0be7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_ALLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bea: aastore
      // 0beb: dup
      // 0bec: bipush 7
      // 0bee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_BROWN_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bf1: aastore
      // 0bf2: dup
      // 0bf3: bipush 8
      // 0bf5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_WHITE_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bf8: aastore
      // 0bf9: dup
      // 0bfa: bipush 9
      // 0bfc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_ORANGE_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0bff: aastore
      // 0c00: dup
      // 0c01: bipush 10
      // 0c03: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_DANDELION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c06: aastore
      // 0c07: dup
      // 0c08: bipush 11
      // 0c0a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_AZURE_BLUET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c0d: aastore
      // 0c0e: dup
      // 0c0f: bipush 12
      // 0c11: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_FLOWERING_AZALEA_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c14: aastore
      // 0c15: dup
      // 0c16: bipush 13
      // 0c18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_PINK_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c1b: aastore
      // 0c1c: dup
      // 0c1d: bipush 14
      // 0c1f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_CORNFLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c22: aastore
      // 0c23: dup
      // 0c24: bipush 15
      // 0c26: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_CRIMSON_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c29: aastore
      // 0c2a: dup
      // 0c2b: bipush 16
      // 0c2d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_RED_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c30: aastore
      // 0c31: dup
      // 0c32: bipush 17
      // 0c34: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_BLUE_ORCHID Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c37: aastore
      // 0c38: dup
      // 0c39: bipush 18
      // 0c3b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_FERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c3e: aastore
      // 0c3f: dup
      // 0c40: bipush 19
      // 0c42: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_POPPY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c45: aastore
      // 0c46: dup
      // 0c47: bipush 20
      // 0c49: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_CRIMSON_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c4c: aastore
      // 0c4d: dup
      // 0c4e: bipush 21
      // 0c50: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_RED_TULIP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c53: aastore
      // 0c54: dup
      // 0c55: bipush 22
      // 0c57: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_OXEYE_DAISY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c5a: aastore
      // 0c5b: dup
      // 0c5c: bipush 23
      // 0c5e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_AZALEA_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c61: aastore
      // 0c62: dup
      // 0c63: bipush 24
      // 0c65: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_BAMBOO Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c68: aastore
      // 0c69: dup
      // 0c6a: bipush 25
      // 0c6c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_CACTUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c6f: aastore
      // 0c70: dup
      // 0c71: bipush 26
      // 0c73: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWER_POT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c76: aastore
      // 0c77: dup
      // 0c78: bipush 27
      // 0c7a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_DEAD_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c7d: aastore
      // 0c7e: dup
      // 0c7f: bipush 28
      // 0c81: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_DARK_OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c84: aastore
      // 0c85: dup
      // 0c86: bipush 29
      // 0c88: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_PALE_OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c8b: aastore
      // 0c8c: dup
      // 0c8d: bipush 30
      // 0c8f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_SPRUCE_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c92: aastore
      // 0c93: dup
      // 0c94: bipush 31
      // 0c96: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_JUNGLE_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0c99: aastore
      // 0c9a: dup
      // 0c9b: bipush 32
      // 0c9d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_BIRCH_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ca0: aastore
      // 0ca1: dup
      // 0ca2: bipush 33
      // 0ca4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_MANGROVE_PROPAGULE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ca7: aastore
      // 0ca8: dup
      // 0ca9: bipush 34
      // 0cab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_CHERRY_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0cae: aastore
      // 0caf: dup
      // 0cb0: bipush 35
      // 0cb2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_TORCHFLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0cb5: aastore
      // 0cb6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0cb9: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FLOWER_POTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0cbc: bipush 2
      // 0cbd: anewarray 338
      // 0cc0: dup
      // 0cc1: bipush 0
      // 0cc2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GLOW_BERRIES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0cc5: aastore
      // 0cc6: dup
      // 0cc7: bipush 1
      // 0cc8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SWEET_BERRIES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ccb: aastore
      // 0ccc: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ccf: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FOX_FOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0cd2: bipush 5
      // 0cd3: anewarray 338
      // 0cd6: dup
      // 0cd7: bipush 0
      // 0cd8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0cdb: aastore
      // 0cdc: dup
      // 0cdd: bipush 1
      // 0cde: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ce1: aastore
      // 0ce2: dup
      // 0ce3: bipush 2
      // 0ce4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PODZOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ce7: aastore
      // 0ce8: dup
      // 0ce9: bipush 3
      // 0cea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ced: aastore
      // 0cee: dup
      // 0cef: bipush 4
      // 0cf0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COARSE_DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0cf3: aastore
      // 0cf4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0cf7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FOXES_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0cfa: bipush 5
      // 0cfb: anewarray 338
      // 0cfe: dup
      // 0cff: bipush 0
      // 0d00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d03: aastore
      // 0d04: dup
      // 0d05: bipush 1
      // 0d06: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d09: aastore
      // 0d0a: dup
      // 0d0b: bipush 2
      // 0d0c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d0f: aastore
      // 0d10: dup
      // 0d11: bipush 3
      // 0d12: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d15: aastore
      // 0d16: dup
      // 0d17: bipush 4
      // 0d18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_HORSE_ARMOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d1b: aastore
      // 0d1c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d1f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FREEZE_IMMUNE_WEARABLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d22: bipush 4
      // 0d23: anewarray 338
      // 0d26: dup
      // 0d27: bipush 0
      // 0d28: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d2b: aastore
      // 0d2c: dup
      // 0d2d: bipush 1
      // 0d2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PACKED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d31: aastore
      // 0d32: dup
      // 0d33: bipush 2
      // 0d34: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLUE_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d37: aastore
      // 0d38: dup
      // 0d39: bipush 3
      // 0d3a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FROSTED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d3d: aastore
      // 0d3e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d41: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d44: bipush 6
      // 0d46: anewarray 338
      // 0d49: dup
      // 0d4a: bipush 0
      // 0d4b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEDROCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d4e: aastore
      // 0d4f: dup
      // 0d50: bipush 1
      // 0d51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WATER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d54: aastore
      // 0d55: dup
      // 0d56: bipush 2
      // 0d57: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d5a: aastore
      // 0d5b: dup
      // 0d5c: bipush 3
      // 0d5d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d60: aastore
      // 0d61: dup
      // 0d62: bipush 4
      // 0d63: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PACKED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d66: aastore
      // 0d67: dup
      // 0d68: bipush 5
      // 0d69: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLUE_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d6c: aastore
      // 0d6d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d70: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GEODE_INVALID_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d73: bipush 4
      // 0d74: anewarray 338
      // 0d77: dup
      // 0d78: bipush 0
      // 0d79: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d7c: aastore
      // 0d7d: dup
      // 0d7e: bipush 1
      // 0d7f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_PORTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d82: aastore
      // 0d83: dup
      // 0d84: bipush 2
      // 0d85: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTTED_WARPED_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d88: aastore
      // 0d89: dup
      // 0d8a: bipush 3
      // 0d8b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RESPAWN_ANCHOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d8e: aastore
      // 0d8f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d92: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.HOGLIN_REPELLENTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0d95: bipush 1
      // 0d96: anewarray 338
      // 0d99: dup
      // 0d9a: bipush 0
      // 0d9b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0d9e: aastore
      // 0d9f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0da2: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IGNORED_BY_PIGLIN_BABIES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0da5: bipush 1
      // 0da6: anewarray 2
      // 0da9: dup
      // 0daa: bipush 0
      // 0dab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GLASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0dae: aastore
      // 0daf: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0db2: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IMPERMEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0db5: bipush 3
      // 0db6: anewarray 338
      // 0db9: dup
      // 0dba: bipush 0
      // 0dbb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEDROCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0dbe: aastore
      // 0dbf: dup
      // 0dc0: bipush 1
      // 0dc1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERRACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0dc4: aastore
      // 0dc5: dup
      // 0dc6: bipush 2
      // 0dc7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MAGMA_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0dca: aastore
      // 0dcb: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0dce: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.INFINIBURN_END Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0dd1: bipush 2
      // 0dd2: anewarray 338
      // 0dd5: dup
      // 0dd6: bipush 0
      // 0dd7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERRACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0dda: aastore
      // 0ddb: dup
      // 0ddc: bipush 1
      // 0ddd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MAGMA_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0de0: aastore
      // 0de1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0de4: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.INFINIBURN_NETHER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0de7: bipush 2
      // 0de8: anewarray 338
      // 0deb: dup
      // 0dec: bipush 0
      // 0ded: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERRACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0df0: aastore
      // 0df1: dup
      // 0df2: bipush 1
      // 0df3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MAGMA_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0df6: aastore
      // 0df7: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0dfa: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.INFINIBURN_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0dfd: bipush 2
      // 0dfe: anewarray 338
      // 0e01: dup
      // 0e02: bipush 0
      // 0e03: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e06: aastore
      // 0e07: dup
      // 0e08: bipush 1
      // 0e09: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e0c: aastore
      // 0e0d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e10: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.INSIDE_STEP_SOUND_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e13: bipush 3
      // 0e14: anewarray 338
      // 0e17: dup
      // 0e18: bipush 0
      // 0e19: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ARROW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e1c: aastore
      // 0e1d: dup
      // 0e1e: bipush 1
      // 0e1f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPECTRAL_ARROW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e22: aastore
      // 0e23: dup
      // 0e24: bipush 2
      // 0e25: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TIPPED_ARROW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e28: aastore
      // 0e29: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e2c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_ARROWS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e2f: bipush 5
      // 0e30: anewarray 338
      // 0e33: dup
      // 0e34: bipush 0
      // 0e35: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e38: aastore
      // 0e39: dup
      // 0e3a: bipush 1
      // 0e3b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e3e: aastore
      // 0e3f: dup
      // 0e40: bipush 2
      // 0e41: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_INGOT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e44: aastore
      // 0e45: dup
      // 0e46: bipush 3
      // 0e47: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_INGOT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e4a: aastore
      // 0e4b: dup
      // 0e4c: bipush 4
      // 0e4d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_INGOT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e50: aastore
      // 0e51: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e54: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_BEACON_PAYMENT_ITEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e57: bipush 10
      // 0e59: anewarray 338
      // 0e5c: dup
      // 0e5d: bipush 0
      // 0e5e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e61: aastore
      // 0e62: dup
      // 0e63: bipush 1
      // 0e64: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e67: aastore
      // 0e68: dup
      // 0e69: bipush 2
      // 0e6a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e6d: aastore
      // 0e6e: dup
      // 0e6f: bipush 3
      // 0e70: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e73: aastore
      // 0e74: dup
      // 0e75: bipush 4
      // 0e76: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e79: aastore
      // 0e7a: dup
      // 0e7b: bipush 5
      // 0e7c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e7f: aastore
      // 0e80: dup
      // 0e81: bipush 6
      // 0e83: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e86: aastore
      // 0e87: dup
      // 0e88: bipush 7
      // 0e8a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e8d: aastore
      // 0e8e: dup
      // 0e8f: bipush 8
      // 0e91: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_BOAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e94: aastore
      // 0e95: dup
      // 0e96: bipush 9
      // 0e98: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_RAFT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0e9b: aastore
      // 0e9c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0e9f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_BOATS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0ea2: bipush 2
      // 0ea3: anewarray 338
      // 0ea6: dup
      // 0ea7: bipush 0
      // 0ea8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0eab: aastore
      // 0eac: dup
      // 0ead: bipush 1
      // 0eae: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHARCOAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0eb1: aastore
      // 0eb2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0eb5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_COALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0eb8: bipush 12
      // 0eba: anewarray 338
      // 0ebd: dup
      // 0ebe: bipush 0
      // 0ebf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ec2: aastore
      // 0ec3: dup
      // 0ec4: bipush 1
      // 0ec5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_11 Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ec8: aastore
      // 0ec9: dup
      // 0eca: bipush 2
      // 0ecb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_WAIT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ece: aastore
      // 0ecf: dup
      // 0ed0: bipush 3
      // 0ed1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_MELLOHI Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ed4: aastore
      // 0ed5: dup
      // 0ed6: bipush 4
      // 0ed7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_STAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0eda: aastore
      // 0edb: dup
      // 0edc: bipush 5
      // 0edd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_WARD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ee0: aastore
      // 0ee1: dup
      // 0ee2: bipush 6
      // 0ee4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_13 Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ee7: aastore
      // 0ee8: dup
      // 0ee9: bipush 7
      // 0eeb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_CAT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0eee: aastore
      // 0eef: dup
      // 0ef0: bipush 8
      // 0ef2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_CHIRP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ef5: aastore
      // 0ef6: dup
      // 0ef7: bipush 9
      // 0ef9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_MALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0efc: aastore
      // 0efd: dup
      // 0efe: bipush 10
      // 0f00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_FAR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f03: aastore
      // 0f04: dup
      // 0f05: bipush 11
      // 0f07: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_STRAD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f0a: aastore
      // 0f0b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f0e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_CREEPER_DROP_MUSIC_DISCS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f11: bipush 6
      // 0f13: anewarray 338
      // 0f16: dup
      // 0f17: bipush 0
      // 0f18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TROPICAL_FISH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f1b: aastore
      // 0f1c: dup
      // 0f1d: bipush 1
      // 0f1e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SALMON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f21: aastore
      // 0f22: dup
      // 0f23: bipush 2
      // 0f24: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUFFERFISH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f27: aastore
      // 0f28: dup
      // 0f29: bipush 3
      // 0f2a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COOKED_COD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f2d: aastore
      // 0f2e: dup
      // 0f2f: bipush 4
      // 0f30: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f33: aastore
      // 0f34: dup
      // 0f35: bipush 5
      // 0f36: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COOKED_SALMON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f39: aastore
      // 0f3a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f3d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_FISHES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f40: bipush 2
      // 0f41: anewarray 338
      // 0f44: dup
      // 0f45: bipush 0
      // 0f46: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WRITABLE_BOOK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f49: aastore
      // 0f4a: dup
      // 0f4b: bipush 1
      // 0f4c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WRITTEN_BOOK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f4f: aastore
      // 0f50: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f53: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_LECTERN_BOOKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f56: bipush 3
      // 0f57: anewarray 338
      // 0f5a: dup
      // 0f5b: bipush 0
      // 0f5c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLED_DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f5f: aastore
      // 0f60: dup
      // 0f61: bipush 1
      // 0f62: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f65: aastore
      // 0f66: dup
      // 0f67: bipush 2
      // 0f68: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLESTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f6b: aastore
      // 0f6c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f6f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_STONE_TOOL_MATERIALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0f72: bipush 10
      // 0f74: anewarray 338
      // 0f77: dup
      // 0f78: bipush 0
      // 0f79: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f7c: aastore
      // 0f7d: dup
      // 0f7e: bipush 1
      // 0f7f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f82: aastore
      // 0f83: dup
      // 0f84: bipush 2
      // 0f85: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f88: aastore
      // 0f89: dup
      // 0f8a: bipush 3
      // 0f8b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f8e: aastore
      // 0f8f: dup
      // 0f90: bipush 4
      // 0f91: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f94: aastore
      // 0f95: dup
      // 0f96: bipush 5
      // 0f97: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0f9a: aastore
      // 0f9b: dup
      // 0f9c: bipush 6
      // 0f9e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fa1: aastore
      // 0fa2: dup
      // 0fa3: bipush 7
      // 0fa5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fa8: aastore
      // 0fa9: dup
      // 0faa: bipush 8
      // 0fac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0faf: aastore
      // 0fb0: dup
      // 0fb1: bipush 9
      // 0fb3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fb6: aastore
      // 0fb7: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0fba: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 0fbd: bipush 40
      // 0fbf: anewarray 338
      // 0fc2: dup
      // 0fc3: bipush 0
      // 0fc4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fc7: aastore
      // 0fc8: dup
      // 0fc9: bipush 1
      // 0fca: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fcd: aastore
      // 0fce: dup
      // 0fcf: bipush 2
      // 0fd0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fd3: aastore
      // 0fd4: dup
      // 0fd5: bipush 3
      // 0fd6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SANDSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fd9: aastore
      // 0fda: dup
      // 0fdb: bipush 4
      // 0fdc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fdf: aastore
      // 0fe0: dup
      // 0fe1: bipush 5
      // 0fe2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fe5: aastore
      // 0fe6: dup
      // 0fe7: bipush 6
      // 0fe9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0fec: aastore
      // 0fed: dup
      // 0fee: bipush 7
      // 0ff0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DIORITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ff3: aastore
      // 0ff4: dup
      // 0ff5: bipush 8
      // 0ff7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 0ffa: aastore
      // 0ffb: dup
      // 0ffc: bipush 9
      // 0ffe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1001: aastore
      // 1002: dup
      // 1003: bipush 10
      // 1005: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_NETHER_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1008: aastore
      // 1009: dup
      // 100a: bipush 11
      // 100c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 100f: aastore
      // 1010: dup
      // 1011: bipush 12
      // 1013: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1016: aastore
      // 1017: dup
      // 1018: bipush 13
      // 101a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_TILE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 101d: aastore
      // 101e: dup
      // 101f: bipush 14
      // 1021: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_ANDESITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1024: aastore
      // 1025: dup
      // 1026: bipush 15
      // 1028: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_RED_SANDSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 102b: aastore
      // 102c: dup
      // 102d: bipush 16
      // 102f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PURPUR_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1032: aastore
      // 1033: dup
      // 1034: bipush 17
      // 1036: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DEEPSLATE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1039: aastore
      // 103a: dup
      // 103b: bipush 18
      // 103d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.QUARTZ_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1040: aastore
      // 1041: dup
      // 1042: bipush 19
      // 1044: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_COBBLESTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1047: aastore
      // 1048: dup
      // 1049: bipush 20
      // 104b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 104e: aastore
      // 104f: dup
      // 1050: bipush 21
      // 1052: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1055: aastore
      // 1056: dup
      // 1057: bipush 22
      // 1059: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SANDSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 105c: aastore
      // 105d: dup
      // 105e: bipush 23
      // 1060: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1063: aastore
      // 1064: dup
      // 1065: bipush 24
      // 1067: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 106a: aastore
      // 106b: dup
      // 106c: bipush 25
      // 106e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLED_DEEPSLATE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1071: aastore
      // 1072: dup
      // 1073: bipush 26
      // 1075: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLESTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1078: aastore
      // 1079: dup
      // 107a: bipush 27
      // 107c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 107f: aastore
      // 1080: dup
      // 1081: bipush 28
      // 1083: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1086: aastore
      // 1087: dup
      // 1088: bipush 29
      // 108a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_QUARTZ_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 108d: aastore
      // 108e: dup
      // 108f: bipush 30
      // 1091: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1094: aastore
      // 1095: dup
      // 1096: bipush 31
      // 1098: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_PRISMARINE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 109b: aastore
      // 109c: dup
      // 109d: bipush 32
      // 109f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10a2: aastore
      // 10a3: dup
      // 10a4: bipush 33
      // 10a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10a9: aastore
      // 10aa: dup
      // 10ab: bipush 34
      // 10ad: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_GRANITE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10b0: aastore
      // 10b1: dup
      // 10b2: bipush 35
      // 10b4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_STONE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10b7: aastore
      // 10b8: dup
      // 10b9: bipush 36
      // 10bb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE_BRICK_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10be: aastore
      // 10bf: dup
      // 10c0: bipush 37
      // 10c2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10c5: aastore
      // 10c6: dup
      // 10c7: bipush 38
      // 10c9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_SANDSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10cc: aastore
      // 10cd: dup
      // 10ce: bipush 39
      // 10d0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10d3: aastore
      // 10d4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10d7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10da: bipush 2
      // 10db: anewarray 2
      // 10de: dup
      // 10df: bipush 0
      // 10e0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10e3: aastore
      // 10e4: dup
      // 10e5: bipush 1
      // 10e6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10e9: aastore
      // 10ea: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10ed: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 10f0: bipush 44
      // 10f2: anewarray 338
      // 10f5: dup
      // 10f6: bipush 0
      // 10f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_COBBLESTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 10fa: aastore
      // 10fb: dup
      // 10fc: bipush 1
      // 10fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1100: aastore
      // 1101: dup
      // 1102: bipush 2
      // 1103: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_QUARTZ_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1106: aastore
      // 1107: dup
      // 1108: bipush 3
      // 1109: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLESTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 110c: aastore
      // 110d: dup
      // 110e: bipush 4
      // 110f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1112: aastore
      // 1113: dup
      // 1114: bipush 5
      // 1115: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1118: aastore
      // 1119: dup
      // 111a: bipush 6
      // 111c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_ANDESITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 111f: aastore
      // 1120: dup
      // 1121: bipush 7
      // 1123: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1126: aastore
      // 1127: dup
      // 1128: bipush 8
      // 112a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 112d: aastore
      // 112e: dup
      // 112f: bipush 9
      // 1131: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1134: aastore
      // 1135: dup
      // 1136: bipush 10
      // 1138: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 113b: aastore
      // 113c: dup
      // 113d: bipush 11
      // 113f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLED_DEEPSLATE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1142: aastore
      // 1143: dup
      // 1144: bipush 12
      // 1146: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_RED_SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1149: aastore
      // 114a: dup
      // 114b: bipush 13
      // 114d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DIORITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1150: aastore
      // 1151: dup
      // 1152: bipush 14
      // 1154: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1157: aastore
      // 1158: dup
      // 1159: bipush 15
      // 115b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.QUARTZ_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 115e: aastore
      // 115f: dup
      // 1160: bipush 16
      // 1162: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1165: aastore
      // 1166: dup
      // 1167: bipush 17
      // 1169: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 116c: aastore
      // 116d: dup
      // 116e: bipush 18
      // 1170: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1173: aastore
      // 1174: dup
      // 1175: bipush 19
      // 1177: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 117a: aastore
      // 117b: dup
      // 117c: bipush 20
      // 117e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_NETHER_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1181: aastore
      // 1182: dup
      // 1183: bipush 21
      // 1185: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1188: aastore
      // 1189: dup
      // 118a: bipush 22
      // 118c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_STONE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 118f: aastore
      // 1190: dup
      // 1191: bipush 23
      // 1193: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_STONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1196: aastore
      // 1197: dup
      // 1198: bipush 24
      // 119a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 119d: aastore
      // 119e: dup
      // 119f: bipush 25
      // 11a1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11a4: aastore
      // 11a5: dup
      // 11a6: bipush 26
      // 11a8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11ab: aastore
      // 11ac: dup
      // 11ad: bipush 27
      // 11af: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DEEPSLATE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11b2: aastore
      // 11b3: dup
      // 11b4: bipush 28
      // 11b6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11b9: aastore
      // 11ba: dup
      // 11bb: bipush 29
      // 11bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11c0: aastore
      // 11c1: dup
      // 11c2: bipush 30
      // 11c4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11c7: aastore
      // 11c8: dup
      // 11c9: bipush 31
      // 11cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11ce: aastore
      // 11cf: dup
      // 11d0: bipush 32
      // 11d2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11d5: aastore
      // 11d6: dup
      // 11d7: bipush 33
      // 11d9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11dc: aastore
      // 11dd: dup
      // 11de: bipush 34
      // 11e0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_RED_SANDSTONE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11e3: aastore
      // 11e4: dup
      // 11e5: bipush 35
      // 11e7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PURPUR_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11ea: aastore
      // 11eb: dup
      // 11ec: bipush 36
      // 11ee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11f1: aastore
      // 11f2: dup
      // 11f3: bipush 37
      // 11f5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11f8: aastore
      // 11f9: dup
      // 11fa: bipush 38
      // 11fc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_TILE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 11ff: aastore
      // 1200: dup
      // 1201: bipush 39
      // 1203: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_PRISMARINE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1206: aastore
      // 1207: dup
      // 1208: bipush 40
      // 120a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PETRIFIED_OAK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 120d: aastore
      // 120e: dup
      // 120f: bipush 41
      // 1211: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1214: aastore
      // 1215: dup
      // 1216: bipush 42
      // 1218: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BRICK_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 121b: aastore
      // 121c: dup
      // 121d: bipush 43
      // 121f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_GRANITE_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1222: aastore
      // 1223: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1226: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_WOODEN_SLABS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1229: bipush 23
      // 122b: anewarray 338
      // 122e: dup
      // 122f: bipush 0
      // 1230: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANGLER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1233: aastore
      // 1234: dup
      // 1235: bipush 1
      // 1236: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ARCHER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1239: aastore
      // 123a: dup
      // 123b: bipush 2
      // 123c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ARMS_UP_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 123f: aastore
      // 1240: dup
      // 1241: bipush 3
      // 1242: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLADE_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1245: aastore
      // 1246: dup
      // 1247: bipush 4
      // 1248: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BREWER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 124b: aastore
      // 124c: dup
      // 124d: bipush 5
      // 124e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BURN_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1251: aastore
      // 1252: dup
      // 1253: bipush 6
      // 1255: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DANGER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1258: aastore
      // 1259: dup
      // 125a: bipush 7
      // 125c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPLORER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 125f: aastore
      // 1260: dup
      // 1261: bipush 8
      // 1263: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOW_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1266: aastore
      // 1267: dup
      // 1268: bipush 9
      // 126a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FRIEND_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 126d: aastore
      // 126e: dup
      // 126f: bipush 10
      // 1271: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GUSTER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1274: aastore
      // 1275: dup
      // 1276: bipush 11
      // 1278: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HEART_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 127b: aastore
      // 127c: dup
      // 127d: bipush 12
      // 127f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HEARTBREAK_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1282: aastore
      // 1283: dup
      // 1284: bipush 13
      // 1286: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HOWL_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1289: aastore
      // 128a: dup
      // 128b: bipush 14
      // 128d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MINER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1290: aastore
      // 1291: dup
      // 1292: bipush 15
      // 1294: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOURNER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1297: aastore
      // 1298: dup
      // 1299: bipush 16
      // 129b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PLENTY_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 129e: aastore
      // 129f: dup
      // 12a0: bipush 17
      // 12a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRIZE_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12a5: aastore
      // 12a6: dup
      // 12a7: bipush 18
      // 12a9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SCRAPE_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12ac: aastore
      // 12ad: dup
      // 12ae: bipush 19
      // 12b0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHEAF_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12b3: aastore
      // 12b4: dup
      // 12b5: bipush 20
      // 12b7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHELTER_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12ba: aastore
      // 12bb: dup
      // 12bc: bipush 21
      // 12be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SKULL_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12c1: aastore
      // 12c2: dup
      // 12c3: bipush 22
      // 12c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNORT_POTTERY_SHERD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12c8: aastore
      // 12c9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12cc: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.POTTERY_SHERDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12cf: bipush 2
      // 12d0: anewarray 338
      // 12d3: dup
      // 12d4: bipush 0
      // 12d5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SOIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12d8: aastore
      // 12d9: dup
      // 12da: bipush 1
      // 12db: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12de: aastore
      // 12df: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12e2: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SOUL_FIRE_BASE_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12e5: bipush 2
      // 12e6: anewarray 338
      // 12e9: dup
      // 12ea: bipush 0
      // 12eb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SOIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12ee: aastore
      // 12ef: dup
      // 12f0: bipush 1
      // 12f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 12f4: aastore
      // 12f5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12f8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SOUL_SPEED_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 12fb: bipush 4
      // 12fc: anewarray 338
      // 12ff: dup
      // 1300: bipush 0
      // 1301: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1304: aastore
      // 1305: dup
      // 1306: bipush 1
      // 1307: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 130a: aastore
      // 130b: dup
      // 130c: bipush 2
      // 130d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1310: aastore
      // 1311: dup
      // 1312: bipush 3
      // 1313: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1316: aastore
      // 1317: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 131a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STONE_ORE_REPLACEABLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 131d: bipush 1
      // 131e: anewarray 338
      // 1321: dup
      // 1322: bipush 0
      // 1323: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAVA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1326: aastore
      // 1327: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 132a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STRIDER_WARM_BLOCKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 132d: bipush 2
      // 132e: anewarray 338
      // 1331: dup
      // 1332: bipush 0
      // 1333: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PODZOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1336: aastore
      // 1337: dup
      // 1338: bipush 1
      // 1339: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 133c: aastore
      // 133d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1340: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.VALID_SPAWN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1343: bipush 4
      // 1344: anewarray 338
      // 1347: dup
      // 1348: bipush 0
      // 1349: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 134c: aastore
      // 134d: dup
      // 134e: bipush 1
      // 134f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1352: aastore
      // 1353: dup
      // 1354: bipush 2
      // 1355: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1358: aastore
      // 1359: dup
      // 135a: bipush 3
      // 135b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 135e: aastore
      // 135f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1362: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1365: bipush 11
      // 1367: anewarray 338
      // 136a: dup
      // 136b: bipush 0
      // 136c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 136f: aastore
      // 1370: dup
      // 1371: bipush 1
      // 1372: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1375: aastore
      // 1376: dup
      // 1377: bipush 2
      // 1378: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 137b: aastore
      // 137c: dup
      // 137d: bipush 3
      // 137e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1381: aastore
      // 1382: dup
      // 1383: bipush 4
      // 1384: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1387: aastore
      // 1388: dup
      // 1389: bipush 5
      // 138a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AZALEA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 138d: aastore
      // 138e: dup
      // 138f: bipush 6
      // 1391: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1394: aastore
      // 1395: dup
      // 1396: bipush 7
      // 1398: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 139b: aastore
      // 139c: dup
      // 139d: bipush 8
      // 139f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13a2: aastore
      // 13a3: dup
      // 13a4: bipush 9
      // 13a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_PROPAGULE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13a9: aastore
      // 13aa: dup
      // 13ab: bipush 10
      // 13ad: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13b0: aastore
      // 13b1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13b4: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAPLINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13b7: bipush 3
      // 13b8: anewarray 338
      // 13bb: dup
      // 13bc: bipush 0
      // 13bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13c0: aastore
      // 13c1: dup
      // 13c2: bipush 1
      // 13c3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13c6: aastore
      // 13c7: dup
      // 13c8: bipush 2
      // 13c9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13cc: aastore
      // 13cd: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13d0: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOLVES_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13d3: bipush 1
      // 13d4: anewarray 338
      // 13d7: dup
      // 13d8: bipush 0
      // 13d9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13dc: aastore
      // 13dd: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13e0: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.POLAR_BEARS_SPAWNABLE_ON_IN_FROZEN_OCEAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 13e3: bipush 4
      // 13e4: anewarray 338
      // 13e7: dup
      // 13e8: bipush 0
      // 13e9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13ec: aastore
      // 13ed: dup
      // 13ee: bipush 1
      // 13ef: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13f2: aastore
      // 13f3: dup
      // 13f4: bipush 2
      // 13f5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13f8: aastore
      // 13f9: dup
      // 13fa: bipush 3
      // 13fb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 13fe: aastore
      // 13ff: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1402: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.RABBITS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1405: bipush 2
      // 1406: anewarray 338
      // 1409: dup
      // 140a: bipush 0
      // 140b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COOKED_PORKCHOP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 140e: aastore
      // 140f: dup
      // 1410: bipush 1
      // 1411: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PORKCHOP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1414: aastore
      // 1415: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1418: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PIGLIN_FOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 141b: bipush 5
      // 141c: anewarray 338
      // 141f: dup
      // 1420: bipush 0
      // 1421: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_WALL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1424: aastore
      // 1425: dup
      // 1426: bipush 1
      // 1427: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 142a: aastore
      // 142b: dup
      // 142c: bipush 2
      // 142d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_CAMPFIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1430: aastore
      // 1431: dup
      // 1432: bipush 3
      // 1433: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_LANTERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1436: aastore
      // 1437: dup
      // 1438: bipush 4
      // 1439: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 143c: aastore
      // 143d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1440: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PIGLIN_REPELLENTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1443: bipush 12
      // 1445: anewarray 338
      // 1448: dup
      // 1449: bipush 0
      // 144a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 144d: aastore
      // 144e: dup
      // 144f: bipush 1
      // 1450: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GLOW_LICHEN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1453: aastore
      // 1454: dup
      // 1455: bipush 2
      // 1456: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEAD_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1459: aastore
      // 145a: dup
      // 145b: bipush 3
      // 145c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PEONY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 145f: aastore
      // 1460: dup
      // 1461: bipush 4
      // 1462: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TALL_GRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1465: aastore
      // 1466: dup
      // 1467: bipush 5
      // 1468: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HANGING_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 146b: aastore
      // 146c: dup
      // 146d: bipush 6
      // 146f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.VINE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1472: aastore
      // 1473: dup
      // 1474: bipush 7
      // 1476: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SUNFLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1479: aastore
      // 147a: dup
      // 147b: bipush 8
      // 147d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LARGE_FERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1480: aastore
      // 1481: dup
      // 1482: bipush 9
      // 1484: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LILAC Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1487: aastore
      // 1488: dup
      // 1489: bipush 10
      // 148b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ROSE_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 148e: aastore
      // 148f: dup
      // 1490: bipush 11
      // 1492: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHORT_GRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1495: aastore
      // 1496: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1499: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.REPLACEABLE_PLANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 149c: bipush 2
      // 149d: anewarray 338
      // 14a0: dup
      // 14a1: bipush 0
      // 14a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14a5: aastore
      // 14a6: dup
      // 14a7: bipush 1
      // 14a8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14ab: aastore
      // 14ac: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 14af: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SMALL_DRIPLEAF_PLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 14b2: bipush 30
      // 14b4: anewarray 338
      // 14b7: dup
      // 14b8: bipush 0
      // 14b9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14bc: aastore
      // 14bd: dup
      // 14be: bipush 1
      // 14bf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_WALL_SIGN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14c2: aastore
      // 14c3: dup
      // 14c4: bipush 2
      // 14c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_FENCE_GATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14c8: aastore
      // 14c9: dup
      // 14ca: bipush 3
      // 14cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14ce: aastore
      // 14cf: dup
      // 14d0: bipush 4
      // 14d1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14d4: aastore
      // 14d5: dup
      // 14d6: bipush 5
      // 14d7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14da: aastore
      // 14db: dup
      // 14dc: bipush 6
      // 14de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_TRAPDOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14e1: aastore
      // 14e2: dup
      // 14e3: bipush 7
      // 14e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14e8: aastore
      // 14e9: dup
      // 14ea: bipush 8
      // 14ec: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14ef: aastore
      // 14f0: dup
      // 14f1: bipush 9
      // 14f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14f6: aastore
      // 14f7: dup
      // 14f8: bipush 10
      // 14fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_SIGN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 14fd: aastore
      // 14fe: dup
      // 14ff: bipush 11
      // 1501: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1504: aastore
      // 1505: dup
      // 1506: bipush 12
      // 1508: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 150b: aastore
      // 150c: dup
      // 150d: bipush 13
      // 150f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_FENCE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1512: aastore
      // 1513: dup
      // 1514: bipush 14
      // 1516: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_FENCE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1519: aastore
      // 151a: dup
      // 151b: bipush 15
      // 151d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_TRAPDOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1520: aastore
      // 1521: dup
      // 1522: bipush 16
      // 1524: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1527: aastore
      // 1528: dup
      // 1529: bipush 17
      // 152b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_DOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 152e: aastore
      // 152f: dup
      // 1530: bipush 18
      // 1532: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1535: aastore
      // 1536: dup
      // 1537: bipush 19
      // 1539: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 153c: aastore
      // 153d: dup
      // 153e: bipush 20
      // 1540: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1543: aastore
      // 1544: dup
      // 1545: bipush 21
      // 1547: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 154a: aastore
      // 154b: dup
      // 154c: bipush 22
      // 154e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1551: aastore
      // 1552: dup
      // 1553: bipush 23
      // 1555: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_WALL_SIGN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1558: aastore
      // 1559: dup
      // 155a: bipush 24
      // 155c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_FENCE_GATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 155f: aastore
      // 1560: dup
      // 1561: bipush 25
      // 1563: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_BUTTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1566: aastore
      // 1567: dup
      // 1568: bipush 26
      // 156a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 156d: aastore
      // 156e: dup
      // 156f: bipush 27
      // 1571: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_DOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1574: aastore
      // 1575: dup
      // 1576: bipush 28
      // 1578: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_BUTTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 157b: aastore
      // 157c: dup
      // 157d: bipush 29
      // 157f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_SIGN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1582: aastore
      // 1583: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1586: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_FLAMMABLE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1589: bipush 1
      // 158a: anewarray 338
      // 158d: dup
      // 158e: bipush 0
      // 158f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MYCELIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1592: aastore
      // 1593: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1596: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MOOSHROOMS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1599: bipush 43
      // 159b: anewarray 338
      // 159e: dup
      // 159f: bipush 0
      // 15a0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15a3: aastore
      // 15a4: dup
      // 15a5: bipush 1
      // 15a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_COPPER_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15a9: aastore
      // 15aa: dup
      // 15ab: bipush 2
      // 15ac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15af: aastore
      // 15b0: dup
      // 15b1: bipush 3
      // 15b2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15b5: aastore
      // 15b6: dup
      // 15b7: bipush 4
      // 15b8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15bb: aastore
      // 15bc: dup
      // 15bd: bipush 5
      // 15be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15c1: aastore
      // 15c2: dup
      // 15c3: bipush 6
      // 15c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15c8: aastore
      // 15c9: dup
      // 15ca: bipush 7
      // 15cc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15cf: aastore
      // 15d0: dup
      // 15d1: bipush 8
      // 15d3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15d6: aastore
      // 15d7: dup
      // 15d8: bipush 9
      // 15da: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15dd: aastore
      // 15de: dup
      // 15df: bipush 10
      // 15e1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15e4: aastore
      // 15e5: dup
      // 15e6: bipush 11
      // 15e8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_LAPIS_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15eb: aastore
      // 15ec: dup
      // 15ed: bipush 12
      // 15ef: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15f2: aastore
      // 15f3: dup
      // 15f4: bipush 13
      // 15f6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 15f9: aastore
      // 15fa: dup
      // 15fb: bipush 14
      // 15fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1600: aastore
      // 1601: dup
      // 1602: bipush 15
      // 1604: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1607: aastore
      // 1608: dup
      // 1609: bipush 16
      // 160b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 160e: aastore
      // 160f: dup
      // 1610: bipush 17
      // 1612: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1615: aastore
      // 1616: dup
      // 1617: bipush 18
      // 1619: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_IRON_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 161c: aastore
      // 161d: dup
      // 161e: bipush 19
      // 1620: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAPIS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1623: aastore
      // 1624: dup
      // 1625: bipush 20
      // 1627: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_IRON_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 162a: aastore
      // 162b: dup
      // 162c: bipush 21
      // 162e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1631: aastore
      // 1632: dup
      // 1633: bipush 22
      // 1635: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1638: aastore
      // 1639: dup
      // 163a: bipush 23
      // 163c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 163f: aastore
      // 1640: dup
      // 1641: bipush 24
      // 1643: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1646: aastore
      // 1647: dup
      // 1648: bipush 25
      // 164a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 164d: aastore
      // 164e: dup
      // 164f: bipush 26
      // 1651: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1654: aastore
      // 1655: dup
      // 1656: bipush 27
      // 1658: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAPIS_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 165b: aastore
      // 165c: dup
      // 165d: bipush 28
      // 165f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1662: aastore
      // 1663: dup
      // 1664: bipush 29
      // 1666: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1669: aastore
      // 166a: dup
      // 166b: bipush 30
      // 166d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1670: aastore
      // 1671: dup
      // 1672: bipush 31
      // 1674: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1677: aastore
      // 1678: dup
      // 1679: bipush 32
      // 167b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 167e: aastore
      // 167f: dup
      // 1680: bipush 33
      // 1682: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1685: aastore
      // 1686: dup
      // 1687: bipush 34
      // 1689: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 168c: aastore
      // 168d: dup
      // 168e: bipush 35
      // 1690: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER_SLAB Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1693: aastore
      // 1694: dup
      // 1695: bipush 36
      // 1697: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 169a: aastore
      // 169b: dup
      // 169c: bipush 37
      // 169e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16a1: aastore
      // 16a2: dup
      // 16a3: bipush 38
      // 16a5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16a8: aastore
      // 16a9: dup
      // 16aa: bipush 39
      // 16ac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16af: aastore
      // 16b0: dup
      // 16b1: bipush 40
      // 16b3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LIGHTNING_ROD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16b6: aastore
      // 16b7: dup
      // 16b8: bipush 41
      // 16ba: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16bd: aastore
      // 16be: dup
      // 16bf: bipush 42
      // 16c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16c4: aastore
      // 16c5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 16c8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NEEDS_STONE_TOOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 16cb: bipush 12
      // 16cd: anewarray 338
      // 16d0: dup
      // 16d1: bipush 0
      // 16d2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16d5: aastore
      // 16d6: dup
      // 16d7: bipush 1
      // 16d8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16db: aastore
      // 16dc: dup
      // 16dd: bipush 2
      // 16de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16e1: aastore
      // 16e2: dup
      // 16e3: bipush 3
      // 16e4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16e7: aastore
      // 16e8: dup
      // 16e9: bipush 4
      // 16ea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16ed: aastore
      // 16ee: dup
      // 16ef: bipush 5
      // 16f0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16f3: aastore
      // 16f4: dup
      // 16f5: bipush 6
      // 16f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 16fa: aastore
      // 16fb: dup
      // 16fc: bipush 7
      // 16fe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_EMERALD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1701: aastore
      // 1702: dup
      // 1703: bipush 8
      // 1705: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_GOLD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1708: aastore
      // 1709: dup
      // 170a: bipush 9
      // 170c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 170f: aastore
      // 1710: dup
      // 1711: bipush 10
      // 1713: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_REDSTONE_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1716: aastore
      // 1717: dup
      // 1718: bipush 11
      // 171a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_DIAMOND_ORE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 171d: aastore
      // 171e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1721: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NEEDS_IRON_TOOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1724: bipush 5
      // 1725: anewarray 338
      // 1728: dup
      // 1729: bipush 0
      // 172a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 172d: aastore
      // 172e: dup
      // 172f: bipush 1
      // 1730: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1733: aastore
      // 1734: dup
      // 1735: bipush 2
      // 1736: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANCIENT_DEBRIS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1739: aastore
      // 173a: dup
      // 173b: bipush 3
      // 173c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RESPAWN_ANCHOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 173f: aastore
      // 1740: dup
      // 1741: bipush 4
      // 1742: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRYING_OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1745: aastore
      // 1746: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1749: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NEEDS_DIAMOND_TOOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 174c: sipush 143
      // 174f: anewarray 338
      // 1752: dup
      // 1753: bipush 0
      // 1754: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1757: aastore
      // 1758: dup
      // 1759: bipush 1
      // 175a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 175d: aastore
      // 175e: dup
      // 175f: bipush 2
      // 1760: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1763: aastore
      // 1764: dup
      // 1765: bipush 3
      // 1766: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_DOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1769: aastore
      // 176a: dup
      // 176b: bipush 4
      // 176c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLESTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 176f: aastore
      // 1770: dup
      // 1771: bipush 5
      // 1772: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DRIPSTONE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1775: aastore
      // 1776: dup
      // 1777: bipush 6
      // 1779: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 177c: aastore
      // 177d: dup
      // 177e: bipush 7
      // 1780: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1783: aastore
      // 1784: dup
      // 1785: bipush 8
      // 1787: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.QUARTZ_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 178a: aastore
      // 178b: dup
      // 178c: bipush 9
      // 178e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1791: aastore
      // 1792: dup
      // 1793: bipush 10
      // 1795: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1798: aastore
      // 1799: dup
      // 179a: bipush 11
      // 179c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_POLISHED_BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 179f: aastore
      // 17a0: dup
      // 17a1: bipush 12
      // 17a3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DISPENSER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17a6: aastore
      // 17a7: dup
      // 17a8: bipush 13
      // 17aa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17ad: aastore
      // 17ae: dup
      // 17af: bipush 14
      // 17b1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HEAVY_WEIGHTED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17b4: aastore
      // 17b5: dup
      // 17b6: bipush 15
      // 17b8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17bb: aastore
      // 17bc: dup
      // 17bd: bipush 16
      // 17bf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17c2: aastore
      // 17c3: dup
      // 17c4: bipush 17
      // 17c6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_QUARTZ Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17c9: aastore
      // 17ca: dup
      // 17cb: bipush 18
      // 17cd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_RED_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17d0: aastore
      // 17d1: dup
      // 17d2: bipush 19
      // 17d4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17d7: aastore
      // 17d8: dup
      // 17d9: bipush 20
      // 17db: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_COBBLESTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17de: aastore
      // 17df: dup
      // 17e0: bipush 21
      // 17e2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17e5: aastore
      // 17e6: dup
      // 17e7: bipush 22
      // 17e9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17ec: aastore
      // 17ed: dup
      // 17ee: bipush 23
      // 17f0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PISTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17f3: aastore
      // 17f4: dup
      // 17f5: bipush 24
      // 17f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 17fa: aastore
      // 17fb: dup
      // 17fc: bipush 25
      // 17fe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_QUARTZ_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1801: aastore
      // 1802: dup
      // 1803: bipush 26
      // 1805: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1808: aastore
      // 1809: dup
      // 180a: bipush 27
      // 180c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EMERALD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 180f: aastore
      // 1810: dup
      // 1811: bipush 28
      // 1813: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BELL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1816: aastore
      // 1817: dup
      // 1818: bipush 29
      // 181a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AMETHYST_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 181d: aastore
      // 181e: dup
      // 181f: bipush 30
      // 1821: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GILDED_BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1824: aastore
      // 1825: dup
      // 1826: bipush 31
      // 1828: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_NETHER_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 182b: aastore
      // 182c: dup
      // 182d: bipush 32
      // 182f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1832: aastore
      // 1833: dup
      // 1834: bipush 33
      // 1836: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1839: aastore
      // 183a: dup
      // 183b: bipush 34
      // 183d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BUDDING_AMETHYST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1840: aastore
      // 1841: dup
      // 1842: bipush 35
      // 1844: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1847: aastore
      // 1848: dup
      // 1849: bipush 36
      // 184b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HOPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 184e: aastore
      // 184f: dup
      // 1850: bipush 37
      // 1852: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_RED_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1855: aastore
      // 1856: dup
      // 1857: bipush 38
      // 1859: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.QUARTZ_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 185c: aastore
      // 185d: dup
      // 185e: bipush 39
      // 1860: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1863: aastore
      // 1864: dup
      // 1865: bipush 40
      // 1867: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENDER_CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 186a: aastore
      // 186b: dup
      // 186c: bipush 41
      // 186e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1871: aastore
      // 1872: dup
      // 1873: bipush 42
      // 1875: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERRACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1878: aastore
      // 1879: dup
      // 187a: bipush 43
      // 187c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 187f: aastore
      // 1880: dup
      // 1881: bipush 44
      // 1883: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1886: aastore
      // 1887: dup
      // 1888: bipush 45
      // 188a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LIGHT_WEIGHTED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 188d: aastore
      // 188e: dup
      // 188f: bipush 46
      // 1891: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1894: aastore
      // 1895: dup
      // 1896: bipush 47
      // 1898: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_CHAIN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 189b: aastore
      // 189c: dup
      // 189d: bipush 48
      // 189f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MAGMA_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18a2: aastore
      // 18a3: dup
      // 18a4: bipush 49
      // 18a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18a9: aastore
      // 18aa: dup
      // 18ab: bipush 50
      // 18ad: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_PRISMARINE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18b0: aastore
      // 18b1: dup
      // 18b2: bipush 51
      // 18b4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MEDIUM_AMETHYST_BUD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18b7: aastore
      // 18b8: dup
      // 18b9: bipush 52
      // 18bb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LANTERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18be: aastore
      // 18bf: dup
      // 18c0: bipush 53
      // 18c2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18c5: aastore
      // 18c6: dup
      // 18c7: bipush 54
      // 18c9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIORITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18cc: aastore
      // 18cd: dup
      // 18ce: bipush 55
      // 18d0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DROPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18d3: aastore
      // 18d4: dup
      // 18d5: bipush 56
      // 18d7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_NETHER_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18da: aastore
      // 18db: dup
      // 18dc: bipush 57
      // 18de: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BREWING_STAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18e1: aastore
      // 18e2: dup
      // 18e3: bipush 58
      // 18e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_RED_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18e8: aastore
      // 18e9: dup
      // 18ea: bipush 59
      // 18ec: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CALCITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18ef: aastore
      // 18f0: dup
      // 18f1: bipush 60
      // 18f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CUT_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18f6: aastore
      // 18f7: dup
      // 18f8: bipush 61
      // 18fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BASALT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 18fd: aastore
      // 18fe: dup
      // 18ff: bipush 62
      // 1901: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE_TILES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1904: aastore
      // 1905: dup
      // 1906: bipush 63
      // 1908: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.QUARTZ_PILLAR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 190b: aastore
      // 190c: dup
      // 190d: bipush 64
      // 190f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LODESTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1912: aastore
      // 1913: dup
      // 1914: bipush 65
      // 1916: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_GRANITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1919: aastore
      // 191a: dup
      // 191b: bipush 66
      // 191d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_ANDESITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1920: aastore
      // 1921: dup
      // 1922: bipush 67
      // 1924: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OBSERVER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1927: aastore
      // 1928: dup
      // 1929: bipush 68
      // 192b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHISELED_DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 192e: aastore
      // 192f: dup
      // 1930: bipush 69
      // 1932: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1935: aastore
      // 1936: dup
      // 1937: bipush 70
      // 1939: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_POLISHED_BLACKSTONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 193c: aastore
      // 193d: dup
      // 193e: bipush 71
      // 1940: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1943: aastore
      // 1944: dup
      // 1945: bipush 72
      // 1947: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMALL_AMETHYST_BUD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 194a: aastore
      // 194b: dup
      // 194c: bipush 73
      // 194e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OXIDIZED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1951: aastore
      // 1952: dup
      // 1953: bipush 74
      // 1955: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1958: aastore
      // 1959: dup
      // 195a: bipush 75
      // 195c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_IRON_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 195f: aastore
      // 1960: dup
      // 1961: bipush 76
      // 1963: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1966: aastore
      // 1967: dup
      // 1968: bipush 77
      // 196a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 196d: aastore
      // 196e: dup
      // 196f: bipush 78
      // 1971: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_COPPER_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1974: aastore
      // 1975: dup
      // 1976: bipush 79
      // 1978: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 197b: aastore
      // 197c: dup
      // 197d: bipush 80
      // 197f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AMETHYST_CLUSTER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1982: aastore
      // 1983: dup
      // 1984: bipush 81
      // 1986: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRINDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1989: aastore
      // 198a: dup
      // 198b: bipush 82
      // 198d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_EXPOSED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1990: aastore
      // 1991: dup
      // 1992: bipush 83
      // 1994: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1997: aastore
      // 1998: dup
      // 1999: bipush 84
      // 199b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LIGHTNING_ROD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 199e: aastore
      // 199f: dup
      // 19a0: bipush 85
      // 19a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_LANTERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19a5: aastore
      // 19a6: dup
      // 19a7: bipush 86
      // 19a9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19ac: aastore
      // 19ad: dup
      // 19ae: bipush 87
      // 19b0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BARS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19b3: aastore
      // 19b4: dup
      // 19b5: bipush 88
      // 19b7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PURPUR_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19ba: aastore
      // 19bb: dup
      // 19bc: bipush 89
      // 19be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FURNACE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19c1: aastore
      // 19c2: dup
      // 19c3: bipush 90
      // 19c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CONDUIT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19c8: aastore
      // 19c9: dup
      // 19ca: bipush 91
      // 19cc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPAWNER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19cf: aastore
      // 19d0: dup
      // 19d1: bipush 92
      // 19d3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAL_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19d6: aastore
      // 19d7: dup
      // 19d8: bipush 93
      // 19da: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BONE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19dd: aastore
      // 19de: dup
      // 19df: bipush 94
      // 19e1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19e4: aastore
      // 19e5: dup
      // 19e6: bipush 95
      // 19e8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19eb: aastore
      // 19ec: dup
      // 19ed: bipush 96
      // 19ef: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEATHERED_CUT_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19f2: aastore
      // 19f3: dup
      // 19f4: bipush 97
      // 19f6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSSY_COBBLESTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 19f9: aastore
      // 19fa: dup
      // 19fb: bipush 98
      // 19fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOKER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a00: aastore
      // 1a01: dup
      // 1a02: bipush 99
      // 1a04: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COBBLED_DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a07: aastore
      // 1a08: dup
      // 1a09: bipush 100
      // 1a0b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_BASALT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a0e: aastore
      // 1a0f: dup
      // 1a10: bipush 101
      // 1a12: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BUTTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a15: aastore
      // 1a16: dup
      // 1a17: bipush 102
      // 1a19: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a1c: aastore
      // 1a1d: dup
      // 1a1e: bipush 103
      // 1a20: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a23: aastore
      // 1a24: dup
      // 1a25: bipush 104
      // 1a27: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_NETHER_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a2a: aastore
      // 1a2b: dup
      // 1a2c: bipush 105
      // 1a2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMOOTH_STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a31: aastore
      // 1a32: dup
      // 1a33: bipush 106
      // 1a35: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ANDESITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a38: aastore
      // 1a39: dup
      // 1a3a: bipush 107
      // 1a3c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BASALT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a3f: aastore
      // 1a40: dup
      // 1a41: bipush 108
      // 1a43: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TUFF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a46: aastore
      // 1a47: dup
      // 1a48: bipush 109
      // 1a4a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a4d: aastore
      // 1a4e: dup
      // 1a4f: bipush 110
      // 1a51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_OXIDIZED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a54: aastore
      // 1a55: dup
      // 1a56: bipush 111
      // 1a58: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_CHISELED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a5b: aastore
      // 1a5c: dup
      // 1a5d: bipush 112
      // 1a5f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PRISMARINE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a62: aastore
      // 1a63: dup
      // 1a64: bipush 113
      // 1a66: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRYING_OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a69: aastore
      // 1a6a: dup
      // 1a6b: bipush 114
      // 1a6d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_DEEPSLATE_TILES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a70: aastore
      // 1a71: dup
      // 1a72: bipush 115
      // 1a74: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a77: aastore
      // 1a78: dup
      // 1a79: bipush 116
      // 1a7b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_TRAPDOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a7e: aastore
      // 1a7f: dup
      // 1a80: bipush 117
      // 1a82: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_MOSSY_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a85: aastore
      // 1a86: dup
      // 1a87: bipush 118
      // 1a89: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RESPAWN_ANCHOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a8c: aastore
      // 1a8d: dup
      // 1a8e: bipush 119
      // 1a90: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLUE_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a93: aastore
      // 1a94: dup
      // 1a95: bipush 120
      // 1a97: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_DIORITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1a9a: aastore
      // 1a9b: dup
      // 1a9c: bipush 121
      // 1a9e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_BRICK_FENCE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1aa1: aastore
      // 1aa2: dup
      // 1aa3: bipush 122
      // 1aa5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.INFESTED_CRACKED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1aa8: aastore
      // 1aa9: dup
      // 1aaa: bipush 123
      // 1aac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SANDSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1aaf: aastore
      // 1ab0: dup
      // 1ab1: bipush 124
      // 1ab3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EXPOSED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ab6: aastore
      // 1ab7: dup
      // 1ab8: bipush 125
      // 1aba: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAXED_WEATHERED_COPPER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1abd: aastore
      // 1abe: dup
      // 1abf: bipush 126
      // 1ac1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_DEEPSLATE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ac4: aastore
      // 1ac5: dup
      // 1ac6: bipush 127
      // 1ac8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LARGE_AMETHYST_BUD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1acb: aastore
      // 1acc: dup
      // 1acd: sipush 128
      // 1ad0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PISTON_HEAD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ad3: aastore
      // 1ad4: dup
      // 1ad5: sipush 129
      // 1ad8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1adb: aastore
      // 1adc: dup
      // 1add: sipush 130
      // 1ae0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PURPUR_PILLAR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ae3: aastore
      // 1ae4: dup
      // 1ae5: sipush 131
      // 1ae8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRANITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1aeb: aastore
      // 1aec: dup
      // 1aed: sipush 132
      // 1af0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONECUTTER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1af3: aastore
      // 1af4: dup
      // 1af5: sipush 133
      // 1af8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BLAST_FURNACE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1afb: aastore
      // 1afc: dup
      // 1afd: sipush 134
      // 1b00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENCHANTING_TABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b03: aastore
      // 1b04: dup
      // 1b05: sipush 135
      // 1b08: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LAPIS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b0b: aastore
      // 1b0c: dup
      // 1b0d: sipush 136
      // 1b10: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PACKED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b13: aastore
      // 1b14: dup
      // 1b15: sipush 137
      // 1b18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRACKED_STONE_BRICKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b1b: aastore
      // 1b1c: dup
      // 1b1d: sipush 138
      // 1b20: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEEPSLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b23: aastore
      // 1b24: dup
      // 1b25: sipush 139
      // 1b28: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b2b: aastore
      // 1b2c: dup
      // 1b2d: sipush 140
      // 1b30: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STICKY_PISTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b33: aastore
      // 1b34: dup
      // 1b35: sipush 141
      // 1b38: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b3b: aastore
      // 1b3c: dup
      // 1b3d: sipush 142
      // 1b40: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POINTED_DRIPSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1b43: aastore
      // 1b44: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 1b47: bipush 16
      // 1b49: anewarray 2
      // 1b4c: dup
      // 1b4d: bipush 0
      // 1b4e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TERRACOTTA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b51: aastore
      // 1b52: dup
      // 1b53: bipush 1
      // 1b54: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GLAZED_TERRACOTTA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b57: aastore
      // 1b58: dup
      // 1b59: bipush 2
      // 1b5a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b5d: aastore
      // 1b5e: dup
      // 1b5f: bipush 3
      // 1b60: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CORALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b63: aastore
      // 1b64: dup
      // 1b65: bipush 4
      // 1b66: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHULKER_BOXES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b69: aastore
      // 1b6a: dup
      // 1b6b: bipush 5
      // 1b6c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.RAILS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b6f: aastore
      // 1b70: dup
      // 1b71: bipush 6
      // 1b73: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b76: aastore
      // 1b77: dup
      // 1b78: bipush 7
      // 1b7a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b7d: aastore
      // 1b7e: dup
      // 1b7f: bipush 8
      // 1b81: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b84: aastore
      // 1b85: dup
      // 1b86: bipush 9
      // 1b88: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.EMERALD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b8b: aastore
      // 1b8c: dup
      // 1b8d: bipush 10
      // 1b8f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b92: aastore
      // 1b93: dup
      // 1b94: bipush 11
      // 1b96: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ANVIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1b99: aastore
      // 1b9a: dup
      // 1b9b: bipush 12
      // 1b9d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CONCRETE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ba0: aastore
      // 1ba1: dup
      // 1ba2: bipush 13
      // 1ba4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ba7: aastore
      // 1ba8: dup
      // 1ba9: bipush 14
      // 1bab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NON_WOODEN_SLABS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1bae: aastore
      // 1baf: dup
      // 1bb0: bipush 15
      // 1bb2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAULDRONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1bb5: aastore
      // 1bb6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 1bb9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1bbc: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MINEABLE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1bbf: bipush 16
      // 1bc1: anewarray 338
      // 1bc4: dup
      // 1bc5: bipush 0
      // 1bc6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FARMLAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bc9: aastore
      // 1bca: dup
      // 1bcb: bipush 1
      // 1bcc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIRT_PATH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bcf: aastore
      // 1bd0: dup
      // 1bd1: bipush 2
      // 1bd2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bd5: aastore
      // 1bd6: dup
      // 1bd7: bipush 3
      // 1bd8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bdb: aastore
      // 1bdc: dup
      // 1bdd: bipush 4
      // 1bde: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1be1: aastore
      // 1be2: dup
      // 1be3: bipush 5
      // 1be4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COARSE_DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1be7: aastore
      // 1be8: dup
      // 1be9: bipush 6
      // 1beb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bee: aastore
      // 1bef: dup
      // 1bf0: bipush 7
      // 1bf2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bf5: aastore
      // 1bf6: dup
      // 1bf7: bipush 8
      // 1bf9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1bfc: aastore
      // 1bfd: dup
      // 1bfe: bipush 9
      // 1c00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PODZOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c03: aastore
      // 1c04: dup
      // 1c05: bipush 10
      // 1c07: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c0a: aastore
      // 1c0b: dup
      // 1c0c: bipush 11
      // 1c0e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c11: aastore
      // 1c12: dup
      // 1c13: bipush 12
      // 1c15: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ROOTED_DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c18: aastore
      // 1c19: dup
      // 1c1a: bipush 13
      // 1c1c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MYCELIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c1f: aastore
      // 1c20: dup
      // 1c21: bipush 14
      // 1c23: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_SOIL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c26: aastore
      // 1c27: dup
      // 1c28: bipush 15
      // 1c2a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c2d: aastore
      // 1c2e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 1c31: bipush 1
      // 1c32: anewarray 2
      // 1c35: dup
      // 1c36: bipush 0
      // 1c37: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CONCRETE_POWDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1c3a: aastore
      // 1c3b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 1c3e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1c41: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MINEABLE_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1c44: bipush 22
      // 1c46: anewarray 338
      // 1c49: dup
      // 1c4a: bipush 0
      // 1c4b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c4e: aastore
      // 1c4f: dup
      // 1c50: bipush 1
      // 1c51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c54: aastore
      // 1c55: dup
      // 1c56: bipush 2
      // 1c57: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c5a: aastore
      // 1c5b: dup
      // 1c5c: bipush 3
      // 1c5d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHROOMLIGHT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c60: aastore
      // 1c61: dup
      // 1c62: bipush 4
      // 1c63: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c66: aastore
      // 1c67: dup
      // 1c68: bipush 5
      // 1c69: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DRIED_KELP_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c6c: aastore
      // 1c6d: dup
      // 1c6e: bipush 6
      // 1c70: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c73: aastore
      // 1c74: dup
      // 1c75: bipush 7
      // 1c77: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c7a: aastore
      // 1c7b: dup
      // 1c7c: bipush 8
      // 1c7e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSS_CARPET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c81: aastore
      // 1c82: dup
      // 1c83: bipush 9
      // 1c85: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WET_SPONGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c88: aastore
      // 1c89: dup
      // 1c8a: bipush 10
      // 1c8c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c8f: aastore
      // 1c90: dup
      // 1c91: bipush 11
      // 1c93: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_WART_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c96: aastore
      // 1c97: dup
      // 1c98: bipush 12
      // 1c9a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_WART_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1c9d: aastore
      // 1c9e: dup
      // 1c9f: bipush 13
      // 1ca1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPONGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ca4: aastore
      // 1ca5: dup
      // 1ca6: bipush 14
      // 1ca8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cab: aastore
      // 1cac: dup
      // 1cad: bipush 15
      // 1caf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SCULK_SENSOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cb2: aastore
      // 1cb3: dup
      // 1cb4: bipush 16
      // 1cb6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HAY_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cb9: aastore
      // 1cba: dup
      // 1cbb: bipush 17
      // 1cbd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TARGET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cc0: aastore
      // 1cc1: dup
      // 1cc2: bipush 18
      // 1cc4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cc7: aastore
      // 1cc8: dup
      // 1cc9: bipush 19
      // 1ccb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cce: aastore
      // 1ccf: dup
      // 1cd0: bipush 20
      // 1cd2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cd5: aastore
      // 1cd6: dup
      // 1cd7: bipush 21
      // 1cd9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOSS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cdc: aastore
      // 1cdd: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ce0: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MINEABLE_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ce3: bipush 58
      // 1ce5: anewarray 338
      // 1ce8: dup
      // 1ce9: bipush 0
      // 1cea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ced: aastore
      // 1cee: dup
      // 1cef: bipush 1
      // 1cf0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_DARK_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cf3: aastore
      // 1cf4: dup
      // 1cf5: bipush 2
      // 1cf6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_PALE_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cf9: aastore
      // 1cfa: dup
      // 1cfb: bipush 3
      // 1cfc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1cff: aastore
      // 1d00: dup
      // 1d01: bipush 4
      // 1d02: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d05: aastore
      // 1d06: dup
      // 1d07: bipush 5
      // 1d08: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d0b: aastore
      // 1d0c: dup
      // 1d0d: bipush 6
      // 1d0f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d12: aastore
      // 1d13: dup
      // 1d14: bipush 7
      // 1d16: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d19: aastore
      // 1d1a: dup
      // 1d1b: bipush 8
      // 1d1d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d20: aastore
      // 1d21: dup
      // 1d22: bipush 9
      // 1d24: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_ACACIA_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d27: aastore
      // 1d28: dup
      // 1d29: bipush 10
      // 1d2b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DARK_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d2e: aastore
      // 1d2f: dup
      // 1d30: bipush 11
      // 1d32: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_DARK_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d35: aastore
      // 1d36: dup
      // 1d37: bipush 12
      // 1d39: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d3c: aastore
      // 1d3d: dup
      // 1d3e: bipush 13
      // 1d40: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPAWNER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d43: aastore
      // 1d44: dup
      // 1d45: bipush 14
      // 1d47: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d4a: aastore
      // 1d4b: dup
      // 1d4c: bipush 15
      // 1d4e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d51: aastore
      // 1d52: dup
      // 1d53: bipush 16
      // 1d55: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d58: aastore
      // 1d59: dup
      // 1d5a: bipush 17
      // 1d5c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d5f: aastore
      // 1d60: dup
      // 1d61: bipush 18
      // 1d63: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d66: aastore
      // 1d67: dup
      // 1d68: bipush 19
      // 1d6a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d6d: aastore
      // 1d6e: dup
      // 1d6f: bipush 20
      // 1d71: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_BIRCH_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d74: aastore
      // 1d75: dup
      // 1d76: bipush 21
      // 1d78: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d7b: aastore
      // 1d7c: dup
      // 1d7d: bipush 22
      // 1d7f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PALE_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d82: aastore
      // 1d83: dup
      // 1d84: bipush 23
      // 1d86: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_PALE_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d89: aastore
      // 1d8a: dup
      // 1d8b: bipush 24
      // 1d8d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d90: aastore
      // 1d91: dup
      // 1d92: bipush 25
      // 1d94: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_ACACIA_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d97: aastore
      // 1d98: dup
      // 1d99: bipush 26
      // 1d9b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1d9e: aastore
      // 1d9f: dup
      // 1da0: bipush 27
      // 1da2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1da5: aastore
      // 1da6: dup
      // 1da7: bipush 28
      // 1da9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_JUNGLE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dac: aastore
      // 1dad: dup
      // 1dae: bipush 29
      // 1db0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_MANGROVE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1db3: aastore
      // 1db4: dup
      // 1db5: bipush 30
      // 1db7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CHERRY_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dba: aastore
      // 1dbb: dup
      // 1dbc: bipush 31
      // 1dbe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dc1: aastore
      // 1dc2: dup
      // 1dc3: bipush 32
      // 1dc5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dc8: aastore
      // 1dc9: dup
      // 1dca: bipush 33
      // 1dcc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dcf: aastore
      // 1dd0: dup
      // 1dd1: bipush 34
      // 1dd3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1dd6: aastore
      // 1dd7: dup
      // 1dd8: bipush 35
      // 1dda: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ddd: aastore
      // 1dde: dup
      // 1ddf: bipush 36
      // 1de1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEDROCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1de4: aastore
      // 1de5: dup
      // 1de6: bipush 37
      // 1de8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1deb: aastore
      // 1dec: dup
      // 1ded: bipush 38
      // 1def: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CRIMSON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1df2: aastore
      // 1df3: dup
      // 1df4: bipush 39
      // 1df6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1df9: aastore
      // 1dfa: dup
      // 1dfb: bipush 40
      // 1dfd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_BIRCH_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e00: aastore
      // 1e01: dup
      // 1e02: bipush 41
      // 1e04: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_MANGROVE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e07: aastore
      // 1e08: dup
      // 1e09: bipush 42
      // 1e0b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_CHERRY_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e0e: aastore
      // 1e0f: dup
      // 1e10: bipush 43
      // 1e12: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_JUNGLE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e15: aastore
      // 1e16: dup
      // 1e17: bipush 44
      // 1e19: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e1c: aastore
      // 1e1d: dup
      // 1e1e: bipush 45
      // 1e20: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_PORTAL_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e23: aastore
      // 1e24: dup
      // 1e25: bipush 46
      // 1e27: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPRUCE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e2a: aastore
      // 1e2b: dup
      // 1e2c: bipush 47
      // 1e2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_SPRUCE_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e31: aastore
      // 1e32: dup
      // 1e33: bipush 48
      // 1e35: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_SPRUCE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e38: aastore
      // 1e39: dup
      // 1e3a: bipush 49
      // 1e3c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUNGLE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e3f: aastore
      // 1e40: dup
      // 1e41: bipush 50
      // 1e43: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MANGROVE_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e46: aastore
      // 1e47: dup
      // 1e48: bipush 51
      // 1e4a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHERRY_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e4d: aastore
      // 1e4e: dup
      // 1e4f: bipush 52
      // 1e51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_OAK_WOOD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e54: aastore
      // 1e55: dup
      // 1e56: bipush 53
      // 1e58: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e5b: aastore
      // 1e5c: dup
      // 1e5d: bipush 54
      // 1e5f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OAK_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e62: aastore
      // 1e63: dup
      // 1e64: bipush 55
      // 1e66: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ACACIA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e69: aastore
      // 1e6a: dup
      // 1e6b: bipush 56
      // 1e6d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STRIPPED_WARPED_HYPHAE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e70: aastore
      // 1e71: dup
      // 1e72: bipush 57
      // 1e74: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIRCH_LOG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e77: aastore
      // 1e78: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1e7b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LAVA_POOL_STONE_CANNOT_REPLACE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1e7e: bipush 4
      // 1e7f: anewarray 338
      // 1e82: dup
      // 1e83: bipush 0
      // 1e84: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e87: aastore
      // 1e88: dup
      // 1e89: bipush 1
      // 1e8a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e8d: aastore
      // 1e8e: dup
      // 1e8f: bipush 2
      // 1e90: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e93: aastore
      // 1e94: dup
      // 1e95: bipush 3
      // 1e96: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LEATHER_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1e99: aastore
      // 1e9a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1e9d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LEATHER_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ea0: bipush 4
      // 1ea1: anewarray 338
      // 1ea4: dup
      // 1ea5: bipush 0
      // 1ea6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ea9: aastore
      // 1eaa: dup
      // 1eab: bipush 1
      // 1eac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1eaf: aastore
      // 1eb0: dup
      // 1eb1: bipush 2
      // 1eb2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1eb5: aastore
      // 1eb6: dup
      // 1eb7: bipush 3
      // 1eb8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ebb: aastore
      // 1ebc: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ebf: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ec2: bipush 4
      // 1ec3: anewarray 338
      // 1ec6: dup
      // 1ec7: bipush 0
      // 1ec8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHAINMAIL_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ecb: aastore
      // 1ecc: dup
      // 1ecd: bipush 1
      // 1ece: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHAINMAIL_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ed1: aastore
      // 1ed2: dup
      // 1ed3: bipush 2
      // 1ed4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHAINMAIL_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ed7: aastore
      // 1ed8: dup
      // 1ed9: bipush 3
      // 1eda: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHAINMAIL_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1edd: aastore
      // 1ede: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ee1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CHAINMAIL_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1ee4: bipush 4
      // 1ee5: anewarray 338
      // 1ee8: dup
      // 1ee9: bipush 0
      // 1eea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1eed: aastore
      // 1eee: dup
      // 1eef: bipush 1
      // 1ef0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ef3: aastore
      // 1ef4: dup
      // 1ef5: bipush 2
      // 1ef6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ef9: aastore
      // 1efa: dup
      // 1efb: bipush 3
      // 1efc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1eff: aastore
      // 1f00: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f03: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f06: bipush 4
      // 1f07: anewarray 338
      // 1f0a: dup
      // 1f0b: bipush 0
      // 1f0c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f0f: aastore
      // 1f10: dup
      // 1f11: bipush 1
      // 1f12: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f15: aastore
      // 1f16: dup
      // 1f17: bipush 2
      // 1f18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f1b: aastore
      // 1f1c: dup
      // 1f1d: bipush 3
      // 1f1e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f21: aastore
      // 1f22: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f25: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLDEN_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f28: bipush 4
      // 1f29: anewarray 338
      // 1f2c: dup
      // 1f2d: bipush 0
      // 1f2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f31: aastore
      // 1f32: dup
      // 1f33: bipush 1
      // 1f34: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f37: aastore
      // 1f38: dup
      // 1f39: bipush 2
      // 1f3a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f3d: aastore
      // 1f3e: dup
      // 1f3f: bipush 3
      // 1f40: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f43: aastore
      // 1f44: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f47: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f4a: bipush 4
      // 1f4b: anewarray 338
      // 1f4e: dup
      // 1f4f: bipush 0
      // 1f50: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f53: aastore
      // 1f54: dup
      // 1f55: bipush 1
      // 1f56: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_CHESTPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f59: aastore
      // 1f5a: dup
      // 1f5b: bipush 2
      // 1f5c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_LEGGINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f5f: aastore
      // 1f60: dup
      // 1f61: bipush 3
      // 1f62: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_BOOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f65: aastore
      // 1f66: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f69: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NETHERITE_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f6c: bipush 5
      // 1f6d: anewarray 338
      // 1f70: dup
      // 1f71: bipush 0
      // 1f72: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f75: aastore
      // 1f76: dup
      // 1f77: bipush 1
      // 1f78: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f7b: aastore
      // 1f7c: dup
      // 1f7d: bipush 2
      // 1f7e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f81: aastore
      // 1f82: dup
      // 1f83: bipush 3
      // 1f84: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f87: aastore
      // 1f88: dup
      // 1f89: bipush 4
      // 1f8a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f8d: aastore
      // 1f8e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f91: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1f94: bipush 5
      // 1f95: anewarray 338
      // 1f98: dup
      // 1f99: bipush 0
      // 1f9a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1f9d: aastore
      // 1f9e: dup
      // 1f9f: bipush 1
      // 1fa0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fa3: aastore
      // 1fa4: dup
      // 1fa5: bipush 2
      // 1fa6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fa9: aastore
      // 1faa: dup
      // 1fab: bipush 3
      // 1fac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1faf: aastore
      // 1fb0: dup
      // 1fb1: bipush 4
      // 1fb2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fb5: aastore
      // 1fb6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1fb9: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STONE_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1fbc: bipush 5
      // 1fbd: anewarray 338
      // 1fc0: dup
      // 1fc1: bipush 0
      // 1fc2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fc5: aastore
      // 1fc6: dup
      // 1fc7: bipush 1
      // 1fc8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fcb: aastore
      // 1fcc: dup
      // 1fcd: bipush 2
      // 1fce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fd1: aastore
      // 1fd2: dup
      // 1fd3: bipush 3
      // 1fd4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fd7: aastore
      // 1fd8: dup
      // 1fd9: bipush 4
      // 1fda: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fdd: aastore
      // 1fde: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1fe1: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 1fe4: bipush 5
      // 1fe5: anewarray 338
      // 1fe8: dup
      // 1fe9: bipush 0
      // 1fea: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fed: aastore
      // 1fee: dup
      // 1fef: bipush 1
      // 1ff0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ff3: aastore
      // 1ff4: dup
      // 1ff5: bipush 2
      // 1ff6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1ff9: aastore
      // 1ffa: dup
      // 1ffb: bipush 3
      // 1ffc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 1fff: aastore
      // 2000: dup
      // 2001: bipush 4
      // 2002: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2005: aastore
      // 2006: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2009: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 200c: bipush 5
      // 200d: anewarray 338
      // 2010: dup
      // 2011: bipush 0
      // 2012: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2015: aastore
      // 2016: dup
      // 2017: bipush 1
      // 2018: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 201b: aastore
      // 201c: dup
      // 201d: bipush 2
      // 201e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2021: aastore
      // 2022: dup
      // 2023: bipush 3
      // 2024: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2027: aastore
      // 2028: dup
      // 2029: bipush 4
      // 202a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 202d: aastore
      // 202e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2031: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLDEN_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2034: bipush 5
      // 2035: anewarray 338
      // 2038: dup
      // 2039: bipush 0
      // 203a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 203d: aastore
      // 203e: dup
      // 203f: bipush 1
      // 2040: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2043: aastore
      // 2044: dup
      // 2045: bipush 2
      // 2046: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2049: aastore
      // 204a: dup
      // 204b: bipush 3
      // 204c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 204f: aastore
      // 2050: dup
      // 2051: bipush 4
      // 2052: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2055: aastore
      // 2056: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2059: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 205c: bipush 5
      // 205d: anewarray 338
      // 2060: dup
      // 2061: bipush 0
      // 2062: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2065: aastore
      // 2066: dup
      // 2067: bipush 1
      // 2068: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 206b: aastore
      // 206c: dup
      // 206d: bipush 2
      // 206e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2071: aastore
      // 2072: dup
      // 2073: bipush 3
      // 2074: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2077: aastore
      // 2078: dup
      // 2079: bipush 4
      // 207a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 207d: aastore
      // 207e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2081: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NETHERITE_TOOLS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2084: bipush 7
      // 2086: anewarray 338
      // 2089: dup
      // 208a: bipush 0
      // 208b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 208e: aastore
      // 208f: dup
      // 2090: bipush 1
      // 2091: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2094: aastore
      // 2095: dup
      // 2096: bipush 2
      // 2097: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 209a: aastore
      // 209b: dup
      // 209c: bipush 3
      // 209d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20a0: aastore
      // 20a1: dup
      // 20a2: bipush 4
      // 20a3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20a6: aastore
      // 20a7: dup
      // 20a8: bipush 5
      // 20a9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20ac: aastore
      // 20ad: dup
      // 20ae: bipush 6
      // 20b0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20b3: aastore
      // 20b4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 20b7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SWORDS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 20ba: bipush 7
      // 20bc: anewarray 338
      // 20bf: dup
      // 20c0: bipush 0
      // 20c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20c4: aastore
      // 20c5: dup
      // 20c6: bipush 1
      // 20c7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20ca: aastore
      // 20cb: dup
      // 20cc: bipush 2
      // 20cd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20d0: aastore
      // 20d1: dup
      // 20d2: bipush 3
      // 20d3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20d6: aastore
      // 20d7: dup
      // 20d8: bipush 4
      // 20d9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20dc: aastore
      // 20dd: dup
      // 20de: bipush 5
      // 20df: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20e2: aastore
      // 20e3: dup
      // 20e4: bipush 6
      // 20e6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20e9: aastore
      // 20ea: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 20ed: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PICKAXES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 20f0: bipush 7
      // 20f2: anewarray 338
      // 20f5: dup
      // 20f6: bipush 0
      // 20f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 20fa: aastore
      // 20fb: dup
      // 20fc: bipush 1
      // 20fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2100: aastore
      // 2101: dup
      // 2102: bipush 2
      // 2103: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2106: aastore
      // 2107: dup
      // 2108: bipush 3
      // 2109: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 210c: aastore
      // 210d: dup
      // 210e: bipush 4
      // 210f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2112: aastore
      // 2113: dup
      // 2114: bipush 5
      // 2115: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2118: aastore
      // 2119: dup
      // 211a: bipush 6
      // 211c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 211f: aastore
      // 2120: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2123: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AXES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2126: bipush 7
      // 2128: anewarray 338
      // 212b: dup
      // 212c: bipush 0
      // 212d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2130: aastore
      // 2131: dup
      // 2132: bipush 1
      // 2133: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2136: aastore
      // 2137: dup
      // 2138: bipush 2
      // 2139: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 213c: aastore
      // 213d: dup
      // 213e: bipush 3
      // 213f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2142: aastore
      // 2143: dup
      // 2144: bipush 4
      // 2145: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2148: aastore
      // 2149: dup
      // 214a: bipush 5
      // 214b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 214e: aastore
      // 214f: dup
      // 2150: bipush 6
      // 2152: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2155: aastore
      // 2156: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2159: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHOVELS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 215c: bipush 7
      // 215e: anewarray 338
      // 2161: dup
      // 2162: bipush 0
      // 2163: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WOODEN_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2166: aastore
      // 2167: dup
      // 2168: bipush 1
      // 2169: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 216c: aastore
      // 216d: dup
      // 216e: bipush 2
      // 216f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COPPER_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2172: aastore
      // 2173: dup
      // 2174: bipush 3
      // 2175: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2178: aastore
      // 2179: dup
      // 217a: bipush 4
      // 217b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 217e: aastore
      // 217f: dup
      // 2180: bipush 5
      // 2181: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIAMOND_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2184: aastore
      // 2185: dup
      // 2186: bipush 6
      // 2188: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 218b: aastore
      // 218c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 218f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.HOES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2192: bipush 1
      // 2193: anewarray 338
      // 2196: dup
      // 2197: bipush 0
      // 2198: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TURTLE_HELMET Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 219b: aastore
      // 219c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 219f: bipush 7
      // 21a1: anewarray 2
      // 21a4: dup
      // 21a5: bipush 0
      // 21a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LEATHER_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21a9: aastore
      // 21aa: dup
      // 21ab: bipush 1
      // 21ac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CHAINMAIL_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21af: aastore
      // 21b0: dup
      // 21b1: bipush 2
      // 21b2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.COPPER_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21b5: aastore
      // 21b6: dup
      // 21b7: bipush 3
      // 21b8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.IRON_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21bb: aastore
      // 21bc: dup
      // 21bd: bipush 4
      // 21be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLDEN_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21c1: aastore
      // 21c2: dup
      // 21c3: bipush 5
      // 21c4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIAMOND_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21c7: aastore
      // 21c8: dup
      // 21c9: bipush 6
      // 21cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NETHERITE_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21ce: aastore
      // 21cf: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 21d2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21d5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 21d8: bipush 17
      // 21da: anewarray 338
      // 21dd: dup
      // 21de: bipush 0
      // 21df: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHERITE_UPGRADE_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 21e2: aastore
      // 21e3: dup
      // 21e4: bipush 1
      // 21e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAST_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 21e8: aastore
      // 21e9: dup
      // 21ea: bipush 2
      // 21eb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 21ee: aastore
      // 21ef: dup
      // 21f0: bipush 3
      // 21f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EYE_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 21f4: aastore
      // 21f5: dup
      // 21f6: bipush 4
      // 21f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HOST_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 21fa: aastore
      // 21fb: dup
      // 21fc: bipush 5
      // 21fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAISER_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2200: aastore
      // 2201: dup
      // 2202: bipush 6
      // 2204: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RIB_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2207: aastore
      // 2208: dup
      // 2209: bipush 7
      // 220b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 220e: aastore
      // 220f: dup
      // 2210: bipush 8
      // 2212: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2215: aastore
      // 2216: dup
      // 2217: bipush 9
      // 2219: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 221c: aastore
      // 221d: dup
      // 221e: bipush 10
      // 2220: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2223: aastore
      // 2224: dup
      // 2225: bipush 11
      // 2227: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 222a: aastore
      // 222b: dup
      // 222c: bipush 12
      // 222e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2231: aastore
      // 2232: dup
      // 2233: bipush 13
      // 2235: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.VEX_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2238: aastore
      // 2239: dup
      // 223a: bipush 14
      // 223c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARD_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 223f: aastore
      // 2240: dup
      // 2241: bipush 15
      // 2243: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2246: aastore
      // 2247: dup
      // 2248: bipush 16
      // 224a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WILD_ARMOR_TRIM_SMITHING_TEMPLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 224d: aastore
      // 224e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2251: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SMITHING_TEMPLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2254: bipush 2
      // 2255: anewarray 338
      // 2258: dup
      // 2259: bipush 0
      // 225a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 225d: aastore
      // 225e: dup
      // 225f: bipush 1
      // 2260: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2263: aastore
      // 2264: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2267: bipush 3
      // 2268: anewarray 2
      // 226b: dup
      // 226c: bipush 0
      // 226d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TERRACOTTA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2270: aastore
      // 2271: dup
      // 2272: bipush 1
      // 2273: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2276: aastore
      // 2277: dup
      // 2278: bipush 2
      // 2279: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 227c: aastore
      // 227d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2280: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2283: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AZALEA_GROWS_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2286: bipush 2
      // 2287: anewarray 338
      // 228a: dup
      // 228b: bipush 0
      // 228c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 228f: aastore
      // 2290: dup
      // 2291: bipush 1
      // 2292: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2295: aastore
      // 2296: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2299: bipush 3
      // 229a: anewarray 2
      // 229d: dup
      // 229e: bipush 0
      // 229f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AZALEA_GROWS_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22a2: aastore
      // 22a3: dup
      // 22a4: bipush 1
      // 22a5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22a8: aastore
      // 22a9: dup
      // 22aa: bipush 2
      // 22ab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22ae: aastore
      // 22af: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 22b2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22b5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AZALEA_ROOT_REPLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22b8: bipush 3
      // 22b9: anewarray 338
      // 22bc: dup
      // 22bd: bipush 0
      // 22be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 22c1: aastore
      // 22c2: dup
      // 22c3: bipush 1
      // 22c4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 22c7: aastore
      // 22c8: dup
      // 22c9: bipush 2
      // 22ca: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 22cd: aastore
      // 22ce: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 22d1: bipush 2
      // 22d2: anewarray 2
      // 22d5: dup
      // 22d6: bipush 0
      // 22d7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22da: aastore
      // 22db: dup
      // 22dc: bipush 1
      // 22dd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22e0: aastore
      // 22e1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 22e4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22e7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BAMBOO_PLANTABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 22ea: bipush 1
      // 22eb: anewarray 338
      // 22ee: dup
      // 22ef: bipush 0
      // 22f0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SWEET_BERRY_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 22f3: aastore
      // 22f4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 22f7: bipush 2
      // 22f8: anewarray 2
      // 22fb: dup
      // 22fc: bipush 0
      // 22fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CROPS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2300: aastore
      // 2301: dup
      // 2302: bipush 1
      // 2303: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2306: aastore
      // 2307: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 230a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 230d: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BEE_GROWABLES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2310: bipush 2
      // 2311: anewarray 338
      // 2314: dup
      // 2315: bipush 0
      // 2316: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2319: aastore
      // 231a: dup
      // 231b: bipush 1
      // 231c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FARMLAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 231f: aastore
      // 2320: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2323: bipush 1
      // 2324: anewarray 2
      // 2327: dup
      // 2328: bipush 0
      // 2329: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 232c: aastore
      // 232d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2330: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2333: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BIG_DRIPLEAF_PLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2336: bipush 2
      // 2337: anewarray 338
      // 233a: dup
      // 233b: bipush 0
      // 233c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE_BUTTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 233f: aastore
      // 2340: dup
      // 2341: bipush 1
      // 2342: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POLISHED_BLACKSTONE_BUTTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2345: aastore
      // 2346: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2349: bipush 1
      // 234a: anewarray 2
      // 234d: dup
      // 234e: bipush 0
      // 234f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_BUTTONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2352: aastore
      // 2353: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2356: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2359: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BUTTONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 235c: bipush 1
      // 235d: anewarray 338
      // 2360: dup
      // 2361: bipush 0
      // 2362: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2365: aastore
      // 2366: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2369: bipush 1
      // 236a: anewarray 2
      // 236d: dup
      // 236e: bipush 0
      // 236f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2372: aastore
      // 2373: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2376: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2379: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DRIPSTONE_REPLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 237c: bipush 13
      // 237e: anewarray 338
      // 2381: dup
      // 2382: bipush 0
      // 2383: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TNT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2386: aastore
      // 2387: dup
      // 2388: bipush 1
      // 2389: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUMPKIN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 238c: aastore
      // 238d: dup
      // 238e: bipush 2
      // 238f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARVED_PUMPKIN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2392: aastore
      // 2393: dup
      // 2394: bipush 3
      // 2395: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MELON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2398: aastore
      // 2399: dup
      // 239a: bipush 4
      // 239b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 239e: aastore
      // 239f: dup
      // 23a0: bipush 5
      // 23a1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23a4: aastore
      // 23a5: dup
      // 23a6: bipush 6
      // 23a8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23ab: aastore
      // 23ac: dup
      // 23ad: bipush 7
      // 23af: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23b2: aastore
      // 23b3: dup
      // 23b4: bipush 8
      // 23b6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23b9: aastore
      // 23ba: dup
      // 23bb: bipush 9
      // 23bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BROWN_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23c0: aastore
      // 23c1: dup
      // 23c2: bipush 10
      // 23c4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CACTUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23c7: aastore
      // 23c8: dup
      // 23c9: bipush 11
      // 23cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23ce: aastore
      // 23cf: dup
      // 23d0: bipush 12
      // 23d2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 23d5: aastore
      // 23d6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 23d9: bipush 4
      // 23da: anewarray 2
      // 23dd: dup
      // 23de: bipush 0
      // 23df: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23e2: aastore
      // 23e3: dup
      // 23e4: bipush 1
      // 23e5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23e8: aastore
      // 23e9: dup
      // 23ea: bipush 2
      // 23eb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23ee: aastore
      // 23ef: dup
      // 23f0: bipush 3
      // 23f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SMALL_FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23f4: aastore
      // 23f5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 23f8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23fb: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ENDERMAN_HOLDABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 23fe: bipush 2
      // 23ff: anewarray 338
      // 2402: dup
      // 2403: bipush 0
      // 2404: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2407: aastore
      // 2408: dup
      // 2409: bipush 1
      // 240a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWERING_AZALEA_LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 240d: aastore
      // 240e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2411: bipush 2
      // 2412: anewarray 2
      // 2415: dup
      // 2416: bipush 0
      // 2417: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SMALL_FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 241a: aastore
      // 241b: dup
      // 241c: bipush 1
      // 241d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TALL_FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2420: aastore
      // 2421: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2424: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2427: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FLOWERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 242a: bipush 3
      // 242b: anewarray 338
      // 242e: dup
      // 242f: bipush 0
      // 2430: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2433: aastore
      // 2434: dup
      // 2435: bipush 1
      // 2436: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2439: aastore
      // 243a: dup
      // 243b: bipush 2
      // 243c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PACKED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 243f: aastore
      // 2440: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2443: bipush 1
      // 2444: anewarray 2
      // 2447: dup
      // 2448: bipush 0
      // 2449: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 244c: aastore
      // 244d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2450: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2453: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOATS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2456: bipush 7
      // 2458: anewarray 338
      // 245b: dup
      // 245c: bipush 0
      // 245d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2460: aastore
      // 2461: dup
      // 2462: bipush 1
      // 2463: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENDER_CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2466: aastore
      // 2467: dup
      // 2468: bipush 2
      // 2469: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 246c: aastore
      // 246d: dup
      // 246e: bipush 3
      // 246f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GILDED_BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2472: aastore
      // 2473: dup
      // 2474: bipush 4
      // 2475: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2478: aastore
      // 2479: dup
      // 247a: bipush 5
      // 247b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BARREL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 247e: aastore
      // 247f: dup
      // 2480: bipush 6
      // 2482: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TRAPPED_CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2485: aastore
      // 2486: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2489: bipush 2
      // 248a: anewarray 2
      // 248d: dup
      // 248e: bipush 0
      // 248f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHULKER_BOXES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2492: aastore
      // 2493: dup
      // 2494: bipush 1
      // 2495: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2498: aastore
      // 2499: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 249c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 249f: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GUARDED_BY_PIGLINS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 24a2: bipush 2
      // 24a3: anewarray 338
      // 24a6: dup
      // 24a7: bipush 0
      // 24a8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_OTHERSIDE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24ab: aastore
      // 24ac: dup
      // 24ad: bipush 1
      // 24ae: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSIC_DISC_PIGSTEP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24b1: aastore
      // 24b2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 24b5: bipush 1
      // 24b6: anewarray 2
      // 24b9: dup
      // 24ba: bipush 0
      // 24bb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_CREEPER_DROP_MUSIC_DISCS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 24be: aastore
      // 24bf: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 24c2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 24c5: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_MUSIC_DISCS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 24c8: bipush 18
      // 24ca: anewarray 338
      // 24cd: dup
      // 24ce: bipush 0
      // 24cf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24d2: aastore
      // 24d3: dup
      // 24d4: bipush 1
      // 24d5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_GOLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24d8: aastore
      // 24d9: dup
      // 24da: bipush 2
      // 24db: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GLISTERING_MELON_SLICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24de: aastore
      // 24df: dup
      // 24e0: bipush 3
      // 24e1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_HORSE_ARMOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24e4: aastore
      // 24e5: dup
      // 24e6: bipush 4
      // 24e7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LIGHT_WEIGHTED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24ea: aastore
      // 24eb: dup
      // 24ec: bipush 5
      // 24ed: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SWORD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24f0: aastore
      // 24f1: dup
      // 24f2: bipush 6
      // 24f4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24f7: aastore
      // 24f8: dup
      // 24f9: bipush 7
      // 24fb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BELL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 24fe: aastore
      // 24ff: dup
      // 2500: bipush 8
      // 2502: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENCHANTED_GOLDEN_APPLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2505: aastore
      // 2506: dup
      // 2507: bipush 9
      // 2509: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RAW_GOLD_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 250c: aastore
      // 250d: dup
      // 250e: bipush 10
      // 2510: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GILDED_BLACKSTONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2513: aastore
      // 2514: dup
      // 2515: bipush 11
      // 2517: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 251a: aastore
      // 251b: dup
      // 251c: bipush 12
      // 251e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_CARROT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2521: aastore
      // 2522: dup
      // 2523: bipush 13
      // 2525: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_APPLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2528: aastore
      // 2529: dup
      // 252a: bipush 14
      // 252c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_SHOVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 252f: aastore
      // 2530: dup
      // 2531: bipush 15
      // 2533: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_PICKAXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2536: aastore
      // 2537: dup
      // 2538: bipush 16
      // 253a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLDEN_HOE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 253d: aastore
      // 253e: dup
      // 253f: bipush 17
      // 2541: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GOLD_INGOT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2544: aastore
      // 2545: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2548: bipush 2
      // 2549: anewarray 2
      // 254c: dup
      // 254d: bipush 0
      // 254e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLD_ORES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2551: aastore
      // 2552: dup
      // 2553: bipush 1
      // 2554: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.GOLDEN_ARMOR_PIECES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2557: aastore
      // 2558: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 255b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 255e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_PIGLIN_LOVED Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2561: bipush 2
      // 2562: anewarray 2
      // 2565: dup
      // 2566: bipush 0
      // 2567: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 256a: aastore
      // 256b: dup
      // 256c: bipush 1
      // 256d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STANDING_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2570: aastore
      // 2571: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2574: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2577: bipush 2
      // 2578: anewarray 338
      // 257b: dup
      // 257c: bipush 0
      // 257d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LIGHT_WEIGHTED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2580: aastore
      // 2581: dup
      // 2582: bipush 1
      // 2583: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HEAVY_WEIGHTED_PRESSURE_PLATE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2586: aastore
      // 2587: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 258a: bipush 2
      // 258b: anewarray 2
      // 258e: dup
      // 258f: bipush 0
      // 2590: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.STONE_PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2593: aastore
      // 2594: dup
      // 2595: bipush 1
      // 2596: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2599: aastore
      // 259a: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 259d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 25a0: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 25a3: bipush 5
      // 25a4: anewarray 338
      // 25a7: dup
      // 25a8: bipush 0
      // 25a9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_BARS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25ac: aastore
      // 25ad: dup
      // 25ae: bipush 1
      // 25af: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25b2: aastore
      // 25b3: dup
      // 25b4: bipush 2
      // 25b5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RESPAWN_ANCHOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25b8: aastore
      // 25b9: dup
      // 25ba: bipush 3
      // 25bb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_STONE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25be: aastore
      // 25bf: dup
      // 25c0: bipush 4
      // 25c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRYING_OBSIDIAN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25c4: aastore
      // 25c5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 25c8: bipush 1
      // 25c9: anewarray 2
      // 25cc: dup
      // 25cd: bipush 0
      // 25ce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WITHER_IMMUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 25d1: aastore
      // 25d2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 25d5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 25d8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DRAGON_IMMUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 25db: bipush 4
      // 25dc: anewarray 338
      // 25df: dup
      // 25e0: bipush 0
      // 25e1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25e4: aastore
      // 25e5: dup
      // 25e6: bipush 1
      // 25e7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TRIPWIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25ea: aastore
      // 25eb: dup
      // 25ec: bipush 2
      // 25ed: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25f0: aastore
      // 25f1: dup
      // 25f2: bipush 3
      // 25f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SOUL_TORCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 25f6: aastore
      // 25f7: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 25fa: bipush 3
      // 25fb: anewarray 2
      // 25fe: dup
      // 25ff: bipush 0
      // 2600: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2603: aastore
      // 2604: dup
      // 2605: bipush 1
      // 2606: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2609: aastore
      // 260a: dup
      // 260b: bipush 2
      // 260c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 260f: aastore
      // 2610: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2613: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2616: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_POST_OVERRIDE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2619: bipush 1
      // 261a: anewarray 338
      // 261d: dup
      // 261e: bipush 0
      // 261f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SEAGRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2622: aastore
      // 2623: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2626: bipush 2
      // 2627: anewarray 2
      // 262a: dup
      // 262b: bipush 0
      // 262c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CORALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 262f: aastore
      // 2630: dup
      // 2631: bipush 1
      // 2632: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2635: aastore
      // 2636: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2639: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 263c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.UNDERWATER_BONEMEALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 263f: bipush 1
      // 2640: anewarray 2
      // 2643: dup
      // 2644: bipush 0
      // 2645: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FENCE_GATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2648: aastore
      // 2649: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 264c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.UNSTABLE_BOTTOM_CENTER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 264f: bipush 1
      // 2650: anewarray 2
      // 2653: dup
      // 2654: bipush 0
      // 2655: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.RAILS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2658: aastore
      // 2659: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 265c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PREVENT_MOB_SPAWNING_INSIDE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 265f: bipush 1
      // 2660: anewarray 2
      // 2663: dup
      // 2664: bipush 0
      // 2665: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2668: aastore
      // 2669: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 266c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.OCCLUDES_VIBRATION_SIGNALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 266f: bipush 9
      // 2671: anewarray 2
      // 2674: dup
      // 2675: bipush 0
      // 2676: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ACACIA_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2679: aastore
      // 267a: dup
      // 267b: bipush 1
      // 267c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 267f: aastore
      // 2680: dup
      // 2681: bipush 2
      // 2682: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DARK_OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2685: aastore
      // 2686: dup
      // 2687: bipush 3
      // 2688: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PALE_OAK_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 268b: aastore
      // 268c: dup
      // 268d: bipush 4
      // 268e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SPRUCE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2691: aastore
      // 2692: dup
      // 2693: bipush 5
      // 2694: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.JUNGLE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2697: aastore
      // 2698: dup
      // 2699: bipush 6
      // 269b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BIRCH_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 269e: aastore
      // 269f: dup
      // 26a0: bipush 7
      // 26a2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MANGROVE_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26a5: aastore
      // 26a6: dup
      // 26a7: bipush 8
      // 26a9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CHERRY_LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26ac: aastore
      // 26ad: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26b0: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS_THAT_BURN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26b3: bipush 3
      // 26b4: anewarray 2
      // 26b7: dup
      // 26b8: bipush 0
      // 26b9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS_THAT_BURN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26bc: aastore
      // 26bd: dup
      // 26be: bipush 1
      // 26bf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CRIMSON_STEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26c2: aastore
      // 26c3: dup
      // 26c4: bipush 2
      // 26c5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WARPED_STEMS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26c8: aastore
      // 26c9: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26cc: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26cf: bipush 3
      // 26d0: anewarray 338
      // 26d3: dup
      // 26d4: bipush 0
      // 26d5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 26d8: aastore
      // 26d9: dup
      // 26da: bipush 1
      // 26db: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHARCOAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 26de: aastore
      // 26df: dup
      // 26e0: bipush 2
      // 26e1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COAL_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 26e4: aastore
      // 26e5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 26e8: bipush 2
      // 26e9: anewarray 2
      // 26ec: dup
      // 26ed: bipush 0
      // 26ee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26f1: aastore
      // 26f2: dup
      // 26f3: bipush 1
      // 26f4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26f7: aastore
      // 26f8: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 26fb: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 26fe: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_FURNACE_MATERIALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2701: bipush 1
      // 2702: anewarray 338
      // 2705: dup
      // 2706: bipush 0
      // 2707: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRASS_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 270a: aastore
      // 270b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 270e: bipush 3
      // 270f: anewarray 2
      // 2712: dup
      // 2713: bipush 0
      // 2714: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2717: aastore
      // 2718: dup
      // 2719: bipush 1
      // 271a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LEAVES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 271d: aastore
      // 271e: dup
      // 271f: bipush 2
      // 2720: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2723: aastore
      // 2724: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2727: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 272a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PARROTS_SPAWNABLE_ON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 272d: bipush 3
      // 272e: anewarray 338
      // 2731: dup
      // 2732: bipush 0
      // 2733: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GRAVEL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2736: aastore
      // 2737: dup
      // 2738: bipush 1
      // 2739: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SAND Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 273c: aastore
      // 273d: dup
      // 273e: bipush 2
      // 273f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CLAY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2742: aastore
      // 2743: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2746: bipush 3
      // 2747: anewarray 2
      // 274a: dup
      // 274b: bipush 0
      // 274c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 274f: aastore
      // 2750: dup
      // 2751: bipush 1
      // 2752: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2755: aastore
      // 2756: dup
      // 2757: bipush 2
      // 2758: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 275b: aastore
      // 275c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 275f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2762: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LUSH_GROUND_REPLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2765: bipush 1
      // 2766: anewarray 338
      // 2769: dup
      // 276a: bipush 0
      // 276b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.IRON_TRAPDOOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 276e: aastore
      // 276f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2772: bipush 1
      // 2773: anewarray 2
      // 2776: dup
      // 2777: bipush 0
      // 2778: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_TRAPDOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 277b: aastore
      // 277c: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 277f: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2782: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TRAPDOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2785: bipush 2
      // 2786: anewarray 338
      // 2789: dup
      // 278a: bipush 0
      // 278b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PODZOL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 278e: aastore
      // 278f: dup
      // 2790: bipush 1
      // 2791: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MYCELIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2794: aastore
      // 2795: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2798: bipush 1
      // 2799: anewarray 2
      // 279c: dup
      // 279d: bipush 0
      // 279e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.NYLIUM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27a1: aastore
      // 27a2: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 27a5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27a8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MUSHROOM_GROW_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27ab: bipush 3
      // 27ac: anewarray 2
      // 27af: dup
      // 27b0: bipush 0
      // 27b1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27b4: aastore
      // 27b5: dup
      // 27b6: bipush 1
      // 27b7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DIRT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27ba: aastore
      // 27bb: dup
      // 27bc: bipush 2
      // 27bd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BASE_STONE_OVERWORLD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27c0: aastore
      // 27c1: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27c4: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MOSS_REPLACEABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 27c7: bipush 9
      // 27c9: anewarray 3403
      // 27cc: dup
      // 27cd: bipush 0
      // 27ce: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.BLAST_PROTECTION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27d1: aastore
      // 27d2: dup
      // 27d3: bipush 1
      // 27d4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.BINDING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27d7: aastore
      // 27d8: dup
      // 27d9: bipush 2
      // 27da: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27dd: aastore
      // 27de: dup
      // 27df: bipush 3
      // 27e0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FIRE_PROTECTION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27e3: aastore
      // 27e4: dup
      // 27e5: bipush 4
      // 27e6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27e9: aastore
      // 27ea: dup
      // 27eb: bipush 5
      // 27ec: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.PROJECTILE_PROTECTION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27ef: aastore
      // 27f0: dup
      // 27f1: bipush 6
      // 27f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.PROTECTION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27f6: aastore
      // 27f7: dup
      // 27f8: bipush 7
      // 27fa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.THORNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 27fd: aastore
      // 27fe: dup
      // 27ff: bipush 8
      // 2801: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2804: aastore
      // 2805: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2808: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 280b: bipush 2
      // 280c: anewarray 3403
      // 280f: dup
      // 2810: bipush 0
      // 2811: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.AQUA_AFFINITY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2814: aastore
      // 2815: dup
      // 2816: bipush 1
      // 2817: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.RESPIRATION Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 281a: aastore
      // 281b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 281e: bipush 1
      // 281f: anewarray 2
      // 2822: dup
      // 2823: bipush 0
      // 2824: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2827: aastore
      // 2828: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 282b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 282e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.HELEMT_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2831: bipush 1
      // 2832: anewarray 2
      // 2835: dup
      // 2836: bipush 0
      // 2837: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 283a: aastore
      // 283b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 283e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CHESTPLATE_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2841: bipush 1
      // 2842: anewarray 2
      // 2845: dup
      // 2846: bipush 0
      // 2847: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 284a: aastore
      // 284b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$400 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 284e: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LEGGINGS_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2851: bipush 3
      // 2852: anewarray 3403
      // 2855: dup
      // 2856: bipush 0
      // 2857: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.DEPTH_STRIDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 285a: aastore
      // 285b: dup
      // 285c: bipush 1
      // 285d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FEATHER_FALLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2860: aastore
      // 2861: dup
      // 2862: bipush 2
      // 2863: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FROST_WALKER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2866: aastore
      // 2867: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 286a: bipush 1
      // 286b: anewarray 2
      // 286e: dup
      // 286f: bipush 0
      // 2870: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ARMOR_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2873: aastore
      // 2874: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2877: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 287a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BOOTS_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 287d: bipush 4
      // 287e: anewarray 3403
      // 2881: dup
      // 2882: bipush 0
      // 2883: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.BINDING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2886: aastore
      // 2887: dup
      // 2888: bipush 1
      // 2889: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 288c: aastore
      // 288d: dup
      // 288e: bipush 2
      // 288f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2892: aastore
      // 2893: dup
      // 2894: bipush 3
      // 2895: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2898: aastore
      // 2899: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 289c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ELYTRA_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 289f: bipush 10
      // 28a1: anewarray 3403
      // 28a4: dup
      // 28a5: bipush 0
      // 28a6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.BANE_OF_ARTHROPODS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28a9: aastore
      // 28aa: dup
      // 28ab: bipush 1
      // 28ac: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28af: aastore
      // 28b0: dup
      // 28b1: bipush 2
      // 28b2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FIRE_ASPECT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28b5: aastore
      // 28b6: dup
      // 28b7: bipush 3
      // 28b8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.KNOCKBACK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28bb: aastore
      // 28bc: dup
      // 28bd: bipush 4
      // 28be: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.LOOTING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28c1: aastore
      // 28c2: dup
      // 28c3: bipush 5
      // 28c4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28c7: aastore
      // 28c8: dup
      // 28c9: bipush 6
      // 28cb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SHARPNESS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28ce: aastore
      // 28cf: dup
      // 28d0: bipush 7
      // 28d2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SMITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28d5: aastore
      // 28d6: dup
      // 28d7: bipush 8
      // 28d9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SWEEPING_EDGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28dc: aastore
      // 28dd: dup
      // 28de: bipush 9
      // 28e0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28e3: aastore
      // 28e4: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 28e7: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SWORD_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 28ea: bipush 9
      // 28ec: anewarray 3403
      // 28ef: dup
      // 28f0: bipush 0
      // 28f1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.BANE_OF_ARTHROPODS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28f4: aastore
      // 28f5: dup
      // 28f6: bipush 1
      // 28f7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 28fa: aastore
      // 28fb: dup
      // 28fc: bipush 2
      // 28fd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.EFFICIENCY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2900: aastore
      // 2901: dup
      // 2902: bipush 3
      // 2903: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FORTUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2906: aastore
      // 2907: dup
      // 2908: bipush 4
      // 2909: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 290c: aastore
      // 290d: dup
      // 290e: bipush 5
      // 290f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SHARPNESS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2912: aastore
      // 2913: dup
      // 2914: bipush 6
      // 2916: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SILK_TOUCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2919: aastore
      // 291a: dup
      // 291b: bipush 7
      // 291d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SMITE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2920: aastore
      // 2921: dup
      // 2922: bipush 8
      // 2924: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2927: aastore
      // 2928: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 292b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AXE_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 292e: bipush 6
      // 2930: anewarray 3403
      // 2933: dup
      // 2934: bipush 0
      // 2935: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2938: aastore
      // 2939: dup
      // 293a: bipush 1
      // 293b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.EFFICIENCY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 293e: aastore
      // 293f: dup
      // 2940: bipush 2
      // 2941: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FORTUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2944: aastore
      // 2945: dup
      // 2946: bipush 3
      // 2947: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 294a: aastore
      // 294b: dup
      // 294c: bipush 4
      // 294d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SILK_TOUCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2950: aastore
      // 2951: dup
      // 2952: bipush 5
      // 2953: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2956: aastore
      // 2957: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 295a: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.HOE_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 295d: bipush 6
      // 295f: anewarray 3403
      // 2962: dup
      // 2963: bipush 0
      // 2964: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2967: aastore
      // 2968: dup
      // 2969: bipush 1
      // 296a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.EFFICIENCY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 296d: aastore
      // 296e: dup
      // 296f: bipush 2
      // 2970: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FORTUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2973: aastore
      // 2974: dup
      // 2975: bipush 3
      // 2976: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2979: aastore
      // 297a: dup
      // 297b: bipush 4
      // 297c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SILK_TOUCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 297f: aastore
      // 2980: dup
      // 2981: bipush 5
      // 2982: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2985: aastore
      // 2986: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2989: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PICKAXE_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 298c: bipush 6
      // 298e: anewarray 3403
      // 2991: dup
      // 2992: bipush 0
      // 2993: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2996: aastore
      // 2997: dup
      // 2998: bipush 1
      // 2999: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.EFFICIENCY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 299c: aastore
      // 299d: dup
      // 299e: bipush 2
      // 299f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FORTUNE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29a2: aastore
      // 29a3: dup
      // 29a4: bipush 3
      // 29a5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29a8: aastore
      // 29a9: dup
      // 29aa: bipush 4
      // 29ab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.SILK_TOUCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29ae: aastore
      // 29af: dup
      // 29b0: bipush 5
      // 29b1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29b4: aastore
      // 29b5: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 29b8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHOVEL_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 29bb: bipush 4
      // 29bc: anewarray 3403
      // 29bf: dup
      // 29c0: bipush 0
      // 29c1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29c4: aastore
      // 29c5: dup
      // 29c6: bipush 1
      // 29c7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.EFFICIENCY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29ca: aastore
      // 29cb: dup
      // 29cc: bipush 2
      // 29cd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29d0: aastore
      // 29d1: dup
      // 29d2: bipush 3
      // 29d3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29d6: aastore
      // 29d7: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 29da: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 29dd: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SHEARS_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 29e0: bipush 6
      // 29e2: anewarray 3403
      // 29e5: dup
      // 29e6: bipush 0
      // 29e7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29ea: aastore
      // 29eb: dup
      // 29ec: bipush 1
      // 29ed: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.FLAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29f0: aastore
      // 29f1: dup
      // 29f2: bipush 2
      // 29f3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.INFINITY Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29f6: aastore
      // 29f7: dup
      // 29f8: bipush 3
      // 29f9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 29fc: aastore
      // 29fd: dup
      // 29fe: bipush 4
      // 29ff: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.PUNCH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a02: aastore
      // 2a03: dup
      // 2a04: bipush 5
      // 2a05: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a08: aastore
      // 2a09: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2a0c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BOW_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2a0f: bipush 6
      // 2a11: anewarray 3403
      // 2a14: dup
      // 2a15: bipush 0
      // 2a16: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.VANISHING_CURSE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a19: aastore
      // 2a1a: dup
      // 2a1b: bipush 1
      // 2a1c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MENDING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a1f: aastore
      // 2a20: dup
      // 2a21: bipush 2
      // 2a22: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.MULTISHOT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a25: aastore
      // 2a26: dup
      // 2a27: bipush 3
      // 2a28: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.PIERCING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a2b: aastore
      // 2a2c: dup
      // 2a2d: bipush 4
      // 2a2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.QUICK_CHARGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a31: aastore
      // 2a32: dup
      // 2a33: bipush 5
      // 2a34: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment.UNBREAKING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEnchantment;
      // 2a37: aastore
      // 2a38: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$000 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2a3b: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CROSSBOW_ENCHANTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2a3e: bipush 48
      // 2a40: anewarray 338
      // 2a43: dup
      // 2a44: bipush 0
      // 2a45: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COMPOSTER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a48: aastore
      // 2a49: dup
      // 2a4a: bipush 1
      // 2a4b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COCOA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a4e: aastore
      // 2a4f: dup
      // 2a50: bipush 2
      // 2a51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_MUSHROOM_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a54: aastore
      // 2a55: dup
      // 2a56: bipush 3
      // 2a57: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRAFTING_TABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a5a: aastore
      // 2a5b: dup
      // 2a5c: bipush 4
      // 2a5d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TALL_GRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a60: aastore
      // 2a61: dup
      // 2a62: bipush 5
      // 2a63: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIG_DRIPLEAF_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a66: aastore
      // 2a67: dup
      // 2a68: bipush 6
      // 2a6a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.RED_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a6d: aastore
      // 2a6e: dup
      // 2a6f: bipush 7
      // 2a71: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JUKEBOX Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a74: aastore
      // 2a75: dup
      // 2a76: bipush 8
      // 2a78: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WARPED_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a7b: aastore
      // 2a7c: dup
      // 2a7d: bipush 9
      // 2a7f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DEAD_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a82: aastore
      // 2a83: dup
      // 2a84: bipush 10
      // 2a86: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NOTE_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a89: aastore
      // 2a8a: dup
      // 2a8b: bipush 11
      // 2a8d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CRIMSON_FUNGUS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a90: aastore
      // 2a91: dup
      // 2a92: bipush 12
      // 2a94: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MUSHROOM_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a97: aastore
      // 2a98: dup
      // 2a99: bipush 13
      // 2a9b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHORUS_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2a9e: aastore
      // 2a9f: dup
      // 2aa0: bipush 14
      // 2aa2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEE_NEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2aa5: aastore
      // 2aa6: dup
      // 2aa7: bipush 15
      // 2aa9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BROWN_MUSHROOM_BLOCK Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2aac: aastore
      // 2aad: dup
      // 2aae: bipush 16
      // 2ab0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.JACK_O_LANTERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ab3: aastore
      // 2ab4: dup
      // 2ab5: bipush 17
      // 2ab7: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2aba: aastore
      // 2abb: dup
      // 2abc: bipush 18
      // 2abe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.NETHER_WART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ac1: aastore
      // 2ac2: dup
      // 2ac3: bipush 19
      // 2ac5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARTOGRAPHY_TABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ac8: aastore
      // 2ac9: dup
      // 2aca: bipush 20
      // 2acc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2acf: aastore
      // 2ad0: dup
      // 2ad1: bipush 21
      // 2ad3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SWEET_BERRY_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ad6: aastore
      // 2ad7: dup
      // 2ad8: bipush 22
      // 2ada: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BROWN_MUSHROOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2add: aastore
      // 2ade: dup
      // 2adf: bipush 23
      // 2ae1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARVED_PUMPKIN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ae4: aastore
      // 2ae5: dup
      // 2ae6: bipush 24
      // 2ae8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMITHING_TABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2aeb: aastore
      // 2aec: dup
      // 2aed: bipush 25
      // 2aef: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GLOW_LICHEN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2af2: aastore
      // 2af3: dup
      // 2af4: bipush 26
      // 2af6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SMALL_DRIPLEAF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2af9: aastore
      // 2afa: dup
      // 2afb: bipush 27
      // 2afd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LOOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b00: aastore
      // 2b01: dup
      // 2b02: bipush 28
      // 2b04: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BEEHIVE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b07: aastore
      // 2b08: dup
      // 2b09: bipush 29
      // 2b0b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SHORT_GRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b0e: aastore
      // 2b0f: dup
      // 2b10: bipush 30
      // 2b12: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HANGING_ROOTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b15: aastore
      // 2b16: dup
      // 2b17: bipush 31
      // 2b19: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHORUS_FLOWER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b1c: aastore
      // 2b1d: dup
      // 2b1e: bipush 32
      // 2b20: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ATTACHED_PUMPKIN_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b23: aastore
      // 2b24: dup
      // 2b25: bipush 33
      // 2b27: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIG_DRIPLEAF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b2a: aastore
      // 2b2b: dup
      // 2b2c: bipush 34
      // 2b2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.DAYLIGHT_DETECTOR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b31: aastore
      // 2b32: dup
      // 2b33: bipush 35
      // 2b35: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SPORE_BLOSSOM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b38: aastore
      // 2b39: dup
      // 2b3a: bipush 36
      // 2b3c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LILY_PAD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b3f: aastore
      // 2b40: dup
      // 2b41: bipush 37
      // 2b43: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TRAPPED_CHEST Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b46: aastore
      // 2b47: dup
      // 2b48: bipush 38
      // 2b4a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BARREL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b4d: aastore
      // 2b4e: dup
      // 2b4f: bipush 39
      // 2b51: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LARGE_FERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b54: aastore
      // 2b55: dup
      // 2b56: bipush 40
      // 2b58: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.LECTERN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b5b: aastore
      // 2b5c: dup
      // 2b5d: bipush 41
      // 2b5f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SUGAR_CANE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b62: aastore
      // 2b63: dup
      // 2b64: bipush 42
      // 2b66: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MELON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b69: aastore
      // 2b6a: dup
      // 2b6b: bipush 43
      // 2b6d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ATTACHED_MELON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b70: aastore
      // 2b71: dup
      // 2b72: bipush 44
      // 2b74: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUMPKIN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b77: aastore
      // 2b78: dup
      // 2b79: bipush 45
      // 2b7b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b7e: aastore
      // 2b7f: dup
      // 2b80: bipush 46
      // 2b82: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLETCHING_TABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b85: aastore
      // 2b86: dup
      // 2b87: bipush 47
      // 2b89: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BOOKSHELF Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2b8c: aastore
      // 2b8d: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2b90: bipush 17
      // 2b92: anewarray 2
      // 2b95: dup
      // 2b96: bipush 0
      // 2b97: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_STAIRS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2b9a: aastore
      // 2b9b: dup
      // 2b9c: bipush 1
      // 2b9d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_SLABS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2ba0: aastore
      // 2ba1: dup
      // 2ba2: bipush 2
      // 2ba3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_PRESSURE_PLATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2ba6: aastore
      // 2ba7: dup
      // 2ba8: bipush 3
      // 2ba9: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bac: aastore
      // 2bad: dup
      // 2bae: bipush 4
      // 2baf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_FENCE_GATES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bb2: aastore
      // 2bb3: dup
      // 2bb4: bipush 5
      // 2bb5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_TRAPDOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bb8: aastore
      // 2bb9: dup
      // 2bba: bipush 6
      // 2bbc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_DOORS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bbf: aastore
      // 2bc0: dup
      // 2bc1: bipush 7
      // 2bc3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WOODEN_BUTTONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bc6: aastore
      // 2bc7: dup
      // 2bc8: bipush 8
      // 2bca: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bcd: aastore
      // 2bce: dup
      // 2bcf: bipush 9
      // 2bd1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bd4: aastore
      // 2bd5: dup
      // 2bd6: bipush 10
      // 2bd8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bdb: aastore
      // 2bdc: dup
      // 2bdd: bipush 11
      // 2bdf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CROPS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2be2: aastore
      // 2be3: dup
      // 2be4: bipush 12
      // 2be6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.LOGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2be9: aastore
      // 2bea: dup
      // 2beb: bipush 13
      // 2bed: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PLANKS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bf0: aastore
      // 2bf1: dup
      // 2bf2: bipush 14
      // 2bf4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SAPLINGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bf7: aastore
      // 2bf8: dup
      // 2bf9: bipush 15
      // 2bfb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CLIMBABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2bfe: aastore
      // 2bff: dup
      // 2c00: bipush 16
      // 2c02: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAMPFIRES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2c05: aastore
      // 2c06: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2c09: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2c0c: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MINEABLE_AXE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2c0f: bipush 24
      // 2c11: anewarray 338
      // 2c14: dup
      // 2c15: bipush 0
      // 2c16: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FROSTED_ICE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c19: aastore
      // 2c1a: dup
      // 2c1b: bipush 1
      // 2c1c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MOVING_PISTON Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c1f: aastore
      // 2c20: dup
      // 2c21: bipush 2
      // 2c22: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PISTON_HEAD Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c25: aastore
      // 2c26: dup
      // 2c27: bipush 3
      // 2c28: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BUBBLE_COLUMN Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c2b: aastore
      // 2c2c: dup
      // 2c2d: bipush 4
      // 2c2e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POWDER_SNOW Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c31: aastore
      // 2c32: dup
      // 2c33: bipush 5
      // 2c34: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.REDSTONE_WIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c37: aastore
      // 2c38: dup
      // 2c39: bipush 6
      // 2c3b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TRIPWIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c3e: aastore
      // 2c3f: dup
      // 2c40: bipush 7
      // 2c42: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BIG_DRIPLEAF_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c45: aastore
      // 2c46: dup
      // 2c47: bipush 8
      // 2c49: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SWEET_BERRY_BUSH Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c4c: aastore
      // 2c4d: dup
      // 2c4e: bipush 9
      // 2c50: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TORCHFLOWER_CROP Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c53: aastore
      // 2c54: dup
      // 2c55: bipush 10
      // 2c57: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TWISTING_VINES_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c5a: aastore
      // 2c5b: dup
      // 2c5c: bipush 11
      // 2c5e: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WEEPING_VINES_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c61: aastore
      // 2c62: dup
      // 2c63: bipush 12
      // 2c65: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c68: aastore
      // 2c69: dup
      // 2c6a: bipush 13
      // 2c6c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CARROTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c6f: aastore
      // 2c70: dup
      // 2c71: bipush 14
      // 2c73: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.POTATOES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c76: aastore
      // 2c77: dup
      // 2c78: bipush 15
      // 2c7a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.BAMBOO_SAPLING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c7d: aastore
      // 2c7e: dup
      // 2c7f: bipush 16
      // 2c81: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHORUS_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c84: aastore
      // 2c85: dup
      // 2c86: bipush 17
      // 2c88: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.KELP_PLANT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c8b: aastore
      // 2c8c: dup
      // 2c8d: bipush 18
      // 2c8f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COCOA Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c92: aastore
      // 2c93: dup
      // 2c94: bipush 19
      // 2c96: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TALL_SEAGRASS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2c99: aastore
      // 2c9a: dup
      // 2c9b: bipush 20
      // 2c9d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MELON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ca0: aastore
      // 2ca1: dup
      // 2ca2: bipush 21
      // 2ca4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PUMPKIN_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2ca7: aastore
      // 2ca8: dup
      // 2ca9: bipush 22
      // 2cab: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ATTACHED_MELON_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2cae: aastore
      // 2caf: dup
      // 2cb0: bipush 23
      // 2cb2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ATTACHED_PUMPKIN_STEM Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2cb5: aastore
      // 2cb6: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$100 ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2cb9: bipush 15
      // 2cbb: anewarray 2
      // 2cbe: dup
      // 2cbf: bipush 0
      // 2cc0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.AIR Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cc3: aastore
      // 2cc4: dup
      // 2cc5: bipush 1
      // 2cc6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CAVE_VINES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cc9: aastore
      // 2cca: dup
      // 2ccb: bipush 2
      // 2ccc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FILLED_CAULDRONS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2ccf: aastore
      // 2cd0: dup
      // 2cd1: bipush 3
      // 2cd2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FIRE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cd5: aastore
      // 2cd6: dup
      // 2cd7: bipush 4
      // 2cd8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FLUID Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cdb: aastore
      // 2cdc: dup
      // 2cdd: bipush 5
      // 2cde: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.PORTALS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2ce1: aastore
      // 2ce2: dup
      // 2ce3: bipush 6
      // 2ce5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2ce8: aastore
      // 2ce9: dup
      // 2cea: bipush 7
      // 2cec: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_HANGING_SIGNS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cef: aastore
      // 2cf0: dup
      // 2cf1: bipush 8
      // 2cf3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_TORCHES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cf6: aastore
      // 2cf7: dup
      // 2cf8: bipush 9
      // 2cfa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ALIVE_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2cfd: aastore
      // 2cfe: dup
      // 2cff: bipush 10
      // 2d01: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.DEAD_CORAL_WALL_FANS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d04: aastore
      // 2d05: dup
      // 2d06: bipush 11
      // 2d08: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_HEADS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d0b: aastore
      // 2d0c: dup
      // 2d0d: bipush 12
      // 2d0f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.CANDLE_CAKES Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d12: aastore
      // 2d13: dup
      // 2d14: bipush 13
      // 2d16: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.WALL_BANNERS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d19: aastore
      // 2d1a: dup
      // 2d1b: bipush 14
      // 2d1d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.FLOWER_POTS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d20: bipush 1
      // 2d21: anewarray 338
      // 2d24: dup
      // 2d25: bipush 0
      // 2d26: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FLOWER_POT Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d29: aastore
      // 2d2a: invokespecial id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.without ([Lid/zentra/minigames/libs/com/cryptomorin/xseries/base/XBase;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d2d: aastore
      // 2d2e: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$300 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;[Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;
      // 2d31: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder.access$200 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag$TagBuilder;)Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d34: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.INVENTORY_NOT_DISPLAYABLE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2d37: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d3a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d3d: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d40: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d45: pop
      // 2d46: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d49: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.CHEST_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d4c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.CHEST_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d4f: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d54: pop
      // 2d55: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d58: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.COMMAND_BLOCK_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d5b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.COMMAND_BLOCK_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d5e: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d63: pop
      // 2d64: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d67: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.TNT_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d6a: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.TNT_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d6d: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d72: pop
      // 2d73: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d76: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.FURNACE_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d79: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.FURNACE_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d7c: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d81: pop
      // 2d82: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d85: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.HOPPER_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d88: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.HOPPER_MINECART Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d8b: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d90: pop
      // 2d91: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2d94: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.END_CRYSTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2d97: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.END_CRYSTAL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2d9a: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2d9f: pop
      // 2da0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2da3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.PAINTING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2da6: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.PAINTING Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2da9: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2dae: pop
      // 2daf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2db2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ITEM_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2db5: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.ITEM_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2db8: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2dbd: pop
      // 2dbe: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2dc1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.GLOW_ITEM_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2dc4: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.GLOW_ITEM_FRAME Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2dc7: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2dcc: pop
      // 2dcd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2dd0: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.WIND_CHARGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2dd3: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.WIND_CHARGE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2dd6: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2ddb: pop
      // 2ddc: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2ddf: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.EGG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2de2: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.EGG Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2de5: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2dea: pop
      // 2deb: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2dee: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.SNOWBALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2df1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.SNOWBALL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2df4: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2df9: pop
      // 2dfa: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2dfd: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENDER_PEARL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2e00: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.ENDER_PEARL Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2e03: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2e08: pop
      // 2e09: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2e0c: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.ENDER_EYE Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;
      // 2e0f: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.EYE_OF_ENDER Lid/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType;
      // 2e12: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2e17: pop
      // 2e18: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.ITEMS_BOATS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2e1b: getfield id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.values Ljava/util/Set;
      // 2e1e: invokeinterface java/util/Set.iterator ()Ljava/util/Iterator; 1
      // 2e23: astore 0
      // 2e24: aload 0
      // 2e25: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2e2a: ifeq 2e59
      // 2e2d: aload 0
      // 2e2e: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 2e33: checkcast id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial
      // 2e36: astore 1
      // 2e37: aload 1
      // 2e38: invokevirtual id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.name ()Ljava/lang/String;
      // 2e3b: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.of (Ljava/lang/String;)Ljava/util/Optional;
      // 2e3e: aload 1
      // 2e3f: invokedynamic get (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.lambda$static$1 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;)Ljava/lang/IllegalStateException;, ()Ljava/lang/IllegalStateException; ]
      // 2e44: invokevirtual java/util/Optional.orElseThrow (Ljava/util/function/Supplier;)Ljava/lang/Object;
      // 2e47: checkcast id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType
      // 2e4a: astore 2
      // 2e4b: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2e4e: aload 1
      // 2e4f: aload 2
      // 2e50: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2e55: pop
      // 2e56: goto 2e24
      // 2e59: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.SPAWN_EGGS Lid/zentra/minigames/libs/com/cryptomorin/xseries/XTag;
      // 2e5c: getfield id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.values Ljava/util/Set;
      // 2e5f: invokeinterface java/util/Set.iterator ()Ljava/util/Iterator; 1
      // 2e64: astore 0
      // 2e65: aload 0
      // 2e66: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2e6b: ifeq 2eaf
      // 2e6e: aload 0
      // 2e6f: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 2e74: checkcast id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial
      // 2e77: astore 1
      // 2e78: aload 1
      // 2e79: invokevirtual id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.name ()Ljava/lang/String;
      // 2e7c: bipush 0
      // 2e7d: aload 1
      // 2e7e: invokevirtual id/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial.name ()Ljava/lang/String;
      // 2e81: invokevirtual java/lang/String.length ()I
      // 2e84: ldc_w "_SPAWN_EGG"
      // 2e87: invokevirtual java/lang/String.length ()I
      // 2e8a: isub
      // 2e8b: invokevirtual java/lang/String.substring (II)Ljava/lang/String;
      // 2e8e: astore 2
      // 2e8f: aload 2
      // 2e90: invokestatic id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType.of (Ljava/lang/String;)Ljava/util/Optional;
      // 2e93: aload 1
      // 2e94: aload 2
      // 2e95: invokedynamic get (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;Ljava/lang/String;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.lambda$static$2 (Lid/zentra/minigames/libs/com/cryptomorin/xseries/XMaterial;Ljava/lang/String;)Ljava/lang/IllegalStateException;, ()Ljava/lang/IllegalStateException; ]
      // 2e9a: invokevirtual java/util/Optional.orElseThrow (Ljava/util/function/Supplier;)Ljava/lang/Object;
      // 2e9d: checkcast id/zentra/minigames/libs/com/cryptomorin/xseries/XEntityType
      // 2ea0: astore 3
      // 2ea1: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.MATERIAL_TO_ENTITY Ljava/util/Map;
      // 2ea4: aload 1
      // 2ea5: aload 3
      // 2ea6: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2eab: pop
      // 2eac: goto 2e65
      // 2eaf: new java/util/HashMap
      // 2eb2: dup
      // 2eb3: bipush 30
      // 2eb5: invokespecial java/util/HashMap.<init> (I)V
      // 2eb8: putstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TAGS Ljava/util/Map;
      // 2ebb: ldc id/zentra/minigames/libs/com/cryptomorin/xseries/XTag
      // 2ebd: invokevirtual java/lang/Class.getDeclaredFields ()[Ljava/lang/reflect/Field;
      // 2ec0: astore 0
      // 2ec1: aload 0
      // 2ec2: arraylength
      // 2ec3: istore 1
      // 2ec4: bipush 0
      // 2ec5: istore 2
      // 2ec6: iload 2
      // 2ec7: iload 1
      // 2ec8: if_icmpge 2f18
      // 2ecb: aload 0
      // 2ecc: iload 2
      // 2ecd: aaload
      // 2ece: astore 3
      // 2ecf: aload 3
      // 2ed0: invokevirtual java/lang/reflect/Field.getType ()Ljava/lang/Class;
      // 2ed3: ldc id/zentra/minigames/libs/com/cryptomorin/xseries/XTag
      // 2ed5: if_acmpne 2eed
      // 2ed8: getstatic id/zentra/minigames/libs/com/cryptomorin/xseries/XTag.TAGS Ljava/util/Map;
      // 2edb: aload 3
      // 2edc: invokevirtual java/lang/reflect/Field.getName ()Ljava/lang/String;
      // 2edf: aload 3
      // 2ee0: aconst_null
      // 2ee1: invokevirtual java/lang/reflect/Field.get (Ljava/lang/Object;)Ljava/lang/Object;
      // 2ee4: checkcast id/zentra/minigames/libs/com/cryptomorin/xseries/XTag
      // 2ee7: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 2eec: pop
      // 2eed: goto 2f12
      // 2ef0: astore 4
      // 2ef2: new java/lang/IllegalStateException
      // 2ef5: dup
      // 2ef6: new java/lang/StringBuilder
      // 2ef9: dup
      // 2efa: invokespecial java/lang/StringBuilder.<init> ()V
      // 2efd: ldc_w "Failed to get XTag "
      // 2f00: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 2f03: aload 3
      // 2f04: invokevirtual java/lang/StringBuilder.append (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      // 2f07: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 2f0a: aload 4
      // 2f0c: invokespecial java/lang/IllegalStateException.<init> (Ljava/lang/String;Ljava/lang/Throwable;)V
      // 2f0f: invokevirtual java/lang/IllegalStateException.printStackTrace ()V
      // 2f12: iinc 2 1
      // 2f15: goto 2ec6
      // 2f18: return
   }

   public abstract static class Matcher<T> {
      public abstract boolean matches(T var1);

      public static final class Error extends RuntimeException {
         public final String matcher;

         public Error(String matcher, String message) {
            super(message);
            this.matcher = matcher;
         }

         public Error(String matcher, String message, Throwable cause) {
            super(message, cause);
            this.matcher = matcher;
         }
      }

      public static final class RegexMatcher<T> extends XTag.Matcher<T> {
         public final Pattern regex;

         public RegexMatcher(Pattern regex) {
            this.regex = regex;
         }

         @Override
         public boolean matches(T object) {
            String name = object instanceof Enum ? ((Enum)object).name() : object.toString();
            return this.regex.matcher(name).matches();
         }
      }

      public static final class TextMatcher<T> extends XTag.Matcher<T> {
         public final String text;
         public final boolean contains;

         public TextMatcher(String text, boolean contains) {
            this.text = text;
            this.contains = contains;
         }

         @Override
         public boolean matches(T object) {
            String name = object instanceof Enum ? ((Enum)object).name() : object.toString();
            return this.contains ? name.contains(this.text) : name.equals(this.text);
         }
      }

      public static final class XTagMatcher<T extends XBase<?, ?>> extends XTag.Matcher<T> {
         public final XTag<T> matcher;

         public XTagMatcher(XTag<T> matcher) {
            this.matcher = matcher;
         }

         public boolean matches(T object) {
            return this.matcher.isTagged(object);
         }
      }
   }

   private static final class TagBuilder<T extends XBase<?, ?>> {
      private final Set<T> values;

      private TagBuilder(Collection<T> values) {
         if (values.isEmpty()) {
            this.values = Collections.newSetFromMap(new IdentityHashMap<>());
         } else if (values.iterator().next() instanceof Enum) {
            Iterator<T> iter = values.iterator();
            T first = iter.next();
            this.values = EnumSet.of((Enum)first);

            while (iter.hasNext()) {
               this.values.add(iter.next());
            }
         } else {
            this.values = Collections.newSetFromMap(new IdentityHashMap<>(values.size()));
            this.values.addAll(values);
         }
      }

      @SafeVarargs
      private static <T extends XBase<?, ?>> XTag<T> simple(T... values) {
         return of(values).build();
      }

      @SafeVarargs
      private static <T extends XBase<?, ?>> XTag<T> simple(XTag<T>... values) {
         return new XTag.TagBuilder<>(Collections.singletonList(values[0].values.iterator().next())).inheritFrom(values).build();
      }

      @SafeVarargs
      private static <T extends XBase<?, ?>> XTag.TagBuilder<T> of(T... values) {
         return new XTag.TagBuilder<>(Arrays.asList(values));
      }

      @SafeVarargs
      private final XTag.TagBuilder<T> inheritFrom(@NotNull XTag<T>... values) {
         for (XTag<T> value : values) {
            this.values.addAll(value.values);
         }

         return this;
      }

      private XTag<T> build() {
         return new XTag<>(Collections.unmodifiableSet(this.values));
      }
   }
}
