/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class TntTagGame
extends Game {
    private final Set<UUID> its = new HashSet<UUID>();
    private final Map<UUID, Long> tagCd = new HashMap<UUID, Long>();
    private int round;
    private int phase;
    private int timer;
    private int roundLen;

    public TntTagGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "tnttag", "Bom Estafet", Material.TNT, n, n2, n3, n4, 3, 16, List.of("Jangan jadi pembawa bom saat sumbunya habis!", "Pembawa bom ditandai helm TNT dan efek menyala. Pukul orang lain untuk memindahkan bom.", "Setiap ronde pembawa bom meledak dan tersingkir. Ronde makin singkat.", "Bom yang baru dioper punya perlindungan 1,5 detik. Bertahan sampai terakhir!"));
        this.voidY = n3 - 10;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        int n;
        int n2;
        blueprint.cone(this.cx, this.by - 14, this.cz, 17, 12, Material.BLACKSTONE);
        blueprint.disc(this.cx, this.by, this.cz, 17, Material.GRAY_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 6, 7, Material.ORANGE_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 11, 12, Material.ORANGE_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 16, 17, Material.RED_CONCRETE);
        blueprint.disc(this.cx, this.by, this.cz, 2, Material.YELLOW_CONCRETE);
        blueprint.set(this.cx, this.by + 1, this.cz, Material.TNT);
        for (int[] nArray : new int[][]{{9, 0}, {-9, 0}, {0, 9}, {0, -9}}) {
            n2 = nArray[0] == 0 ? 1 : 0;
            n = this.cx + nArray[0];
            int n3 = this.cz + nArray[1];
            if (n2 != 0) {
                blueprint.fill(n - 2, this.by + 1, n3, n + 2, this.by + 3, n3, Material.POLISHED_BLACKSTONE_BRICKS);
                continue;
            }
            blueprint.fill(n, this.by + 1, n3 - 2, n, this.by + 3, n3 + 2, Material.POLISHED_BLACKSTONE_BRICKS);
        }
        for (int[] nArray : new int[][]{{12, 12}, {-12, 12}, {12, -12}, {-12, -12}}) {
            n2 = this.cx + nArray[0];
            n = this.cz + nArray[1];
            blueprint.fill(n2, this.by + 1, n, n2, this.by + 6, n, Material.OBSIDIAN);
            blueprint.set(n2, this.by + 7, n, Material.SEA_LANTERN);
        }
    }

    @Override
    protected void onStart() {
        this.its.clear();
        this.tagCd.clear();
        this.round = 0;
        this.phase = 0;
        this.timer = 5;
        this.spreadRing(this.alivePlayers(), 12.0, this.by + 1);
        this.bc("&cBom pertama dipilih dalam 5 detik...");
    }

    @Override
    protected void onSecond() {
        --this.timer;
        if (this.phase == 0) {
            if (this.timer <= 0) {
                this.startRound();
            } else {
                for (Player player : this.alivePlayers()) {
                    Msg.bar(player, "&eRonde berikutnya dalam &f" + this.timer + "s");
                }
            }
            return;
        }
        for (Player player : this.alivePlayers()) {
            if (this.its.contains(player.getUniqueId())) {
                Msg.bar(player, "&c&lKAMU BOM! &f" + this.timer + "s &7- pukul orang lain!");
                float f = 0.5f + (1.0f - (float)Math.max(0, this.timer) / (float)this.roundLen) * 1.5f;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, f);
                continue;
            }
            Msg.bar(player, "&aHindari pembawa bom! &7" + this.timer + "s");
        }
        if (this.timer <= 0) {
            this.explode();
        }
    }

    private void startRound() {
        ++this.round;
        this.roundLen = Math.max(12, 30 - (this.round - 1) * 3);
        List<Player> list = this.alivePlayers();
        Collections.shuffle(list, this.rnd);
        int n = Math.max(1, list.size() / 4);
        this.its.clear();
        for (int i = 0; i < n && i < list.size(); ++i) {
            this.setIt(list.get(i), true);
        }
        this.phase = 1;
        this.timer = this.roundLen;
        StringBuilder stringBuilder = new StringBuilder();
        for (UUID uUID : this.its) {
            stringBuilder.append(Bukkit.getOfflinePlayer((UUID)uUID).getName()).append(" ");
        }
        this.bc("&6Ronde &f" + this.round + " &6- bom dibawa: &c" + stringBuilder.toString().trim() + " &8(" + this.roundLen + "s)");
        this.sound(Sound.ENTITY_TNT_PRIMED, 1.0f, 1.0f);
    }

    private void setIt(Player player, boolean bl) {
        if (bl) {
            this.its.add(player.getUniqueId());
            player.getInventory().setHelmet(new ItemStack(Material.TNT));
            player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 1200, 0, false, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 1200, 1, false, false));
            Msg.title(player, "&c&lKAMU BOM!", "&7Pukul seseorang!", 0, 30, 10);
        } else {
            this.its.remove(player.getUniqueId());
            player.getInventory().setHelmet(null);
            player.removePotionEffect(PotionEffectType.GLOWING);
            player.removePotionEffect(PotionEffectType.SPEED);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 1200, 0, false, false));
        }
    }

    private void explode() {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (UUID uUID : new ArrayList<UUID>(this.its)) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) continue;
            arrayList.add(player);
        }
        this.its.clear();
        for (Player player : arrayList) {
            this.world.spawnParticle(Particle.EXPLOSION_EMITTER, player.getLocation(), 1);
            this.world.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.0f);
            this.eliminate(player, null, "meledak jadi serpihan");
        }
        if (this.state == Game.State.RUNNING) {
            for (Player player : this.alivePlayers()) {
                player.getInventory().setHelmet(null);
                player.removePotionEffect(PotionEffectType.GLOWING);
            }
            this.phase = 0;
            this.timer = 4;
        }
    }

    @Override
    protected void onHit(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setCancelled(true);
        if (this.phase != 1) {
            return;
        }
        if (!this.its.contains(player2.getUniqueId()) || this.its.contains(player.getUniqueId())) {
            return;
        }
        long l = System.currentTimeMillis();
        if (l - this.tagCd.getOrDefault(player2.getUniqueId(), 0L) < 1500L) {
            return;
        }
        this.tagCd.put(player.getUniqueId(), l);
        this.setIt(player2, false);
        this.setIt(player, true);
        this.world.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.6f);
    }

    @Override
    protected void onEnd() {
        this.its.clear();
    }

    @Override
    protected String barText() {
        return "&cBom Estafet &8| &fRonde &e" + this.round + " &8| &fHidup: &a" + this.alive.size();
    }
}

