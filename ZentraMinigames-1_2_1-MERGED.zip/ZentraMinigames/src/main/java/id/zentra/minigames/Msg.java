/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 *  net.kyori.adventure.title.Title
 *  net.kyori.adventure.title.Title$Times
 *  org.bukkit.entity.Player
 */
package id.zentra.minigames;

import java.time.Duration;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

public final class Msg {
    public static final String PREFIX = "&8[&bZentra&3Minigames&8] &7";

    private Msg() {
    }

    public static Component c(String string) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(string).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(Player player, String string) {
        player.sendMessage(Msg.c(PREFIX + string));
    }

    public static void title(Player player, String string, String string2, int n, int n2, int n3) {
        player.showTitle(Title.title((Component)Msg.c(string), (Component)Msg.c(string2), (Title.Times)Title.Times.times((Duration)Duration.ofMillis((long)n * 50L), (Duration)Duration.ofMillis((long)n2 * 50L), (Duration)Duration.ofMillis((long)n3 * 50L))));
    }

    public static String bar(int n, String string) {
        return "&8&m" + string.repeat(Math.max(1, n));
    }

    public static void line(Player player) {
        player.sendMessage(Msg.c("&8&m                                          "));
    }

    public static void bar(Player player, String string) {
        player.sendActionBar(Msg.c(string));
    }
}

