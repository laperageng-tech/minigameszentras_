/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Language
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XAccessFlag;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.classes.ClassHandle;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import java.util.EnumSet;
import java.util.Set;
import org.intellij.lang.annotations.Language;
import org.jetbrains.annotations.ApiStatus;

public abstract class MemberHandle
implements ReflectiveHandle<MethodHandle> {
    protected Set<XAccessFlag> accessFlags = EnumSet.noneOf(XAccessFlag.class);
    protected final ClassHandle clazz;

    protected MemberHandle(ClassHandle clazz) {
        this.clazz = clazz;
    }

    @ApiStatus.Internal
    public Set<XAccessFlag> getAccessFlags() {
        return this.accessFlags;
    }

    public ClassHandle getClassHandle() {
        return this.clazz;
    }

    public MemberHandle makeAccessible() {
        this.accessFlags.add(XAccessFlag.PRIVATE);
        return this;
    }

    public abstract MemberHandle signature(@Language(value="Java") String var1);

    @Override
    public abstract MethodHandle reflect() throws ReflectiveOperationException;

    public abstract <T extends AccessibleObject> T reflectJvm() throws ReflectiveOperationException;

    protected <T extends AccessibleObject> T handleAccessible(T accessibleObject) throws ReflectiveOperationException {
        if (this.accessFlags.contains((Object)XAccessFlag.PRIVATE) || Modifier.isPrivate(((Member)((Object)accessibleObject)).getDeclaringClass().getModifiers())) {
            accessibleObject.setAccessible(true);
        }
        return accessibleObject;
    }

    public abstract MemberHandle copy();
}

