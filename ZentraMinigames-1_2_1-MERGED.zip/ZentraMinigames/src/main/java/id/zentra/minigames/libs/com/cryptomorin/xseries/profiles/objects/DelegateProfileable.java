/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 *  org.jetbrains.annotations.Unmodifiable
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.MojangGameProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.Profileable;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.transformer.ProfileTransformer;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

@ApiStatus.Internal
public interface DelegateProfileable
extends Profileable {
    @ApiStatus.Internal
    @NotNull
    public Profileable getDelegateProfile();

    @Override
    @Nullable
    default public @Unmodifiable MojangGameProfile getProfile() {
        return this.getDelegateProfile().getProfile();
    }

    @Override
    @Nullable
    default public ProfileException test() {
        return this.getDelegateProfile().test();
    }

    @Override
    @Nullable
    default public MojangGameProfile getDisposableProfile() {
        return this.getDelegateProfile().getDisposableProfile();
    }

    @Override
    default public boolean isReady() {
        return this.getDelegateProfile().isReady();
    }

    @Override
    @NotNull
    default public Profileable transform(ProfileTransformer ... transformers) {
        return this.getDelegateProfile().transform(transformers);
    }

    @Override
    @Nullable
    default public String getProfileValue() {
        return this.getDelegateProfile().getProfileValue();
    }
}

