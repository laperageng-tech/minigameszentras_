/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock.KeyedLockMap;
import java.util.UUID;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public final class MojangRequestQueue {
    public static final KeyedLockMap<String> USERNAME_REQUESTS = new KeyedLockMap();
    public static final KeyedLockMap<UUID> UUID_REQUESTS = new KeyedLockMap();
}

