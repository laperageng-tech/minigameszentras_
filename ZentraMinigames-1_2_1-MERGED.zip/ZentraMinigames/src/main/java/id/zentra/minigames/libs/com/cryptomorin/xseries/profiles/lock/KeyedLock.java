/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.ApiStatus$OverrideOnly
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock;

import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface KeyedLock<K, V>
extends AutoCloseable {
    public V getOrRetryValue();

    @ApiStatus.OverrideOnly
    public void lock();

    public void unlock();

    @Override
    public void close();
}

