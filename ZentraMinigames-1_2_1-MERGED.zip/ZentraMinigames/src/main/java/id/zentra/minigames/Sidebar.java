/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.Criteria
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 */
package id.zentra.minigames;

import id.zentra.minigames.Msg;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class Sidebar {
    private static final int MAX = 15;
    private final Scoreboard sb;
    private final Objective obj;
    private final List<Team> teams = new ArrayList<Team>();
    private final List<String> entries = new ArrayList<String>();
    private int shown = 0;

    public Sidebar() {
        this.sb = Bukkit.getScoreboardManager().getNewScoreboard();
        this.obj = this.sb.registerNewObjective("zm", Criteria.DUMMY, (Component)Component.text((String)""));
        this.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        ChatColor[] chatColorArray = ChatColor.values();
        for (int i = 0; i < 15; ++i) {
            String string = chatColorArray[i].toString() + String.valueOf(ChatColor.RESET);
            Team team = this.sb.registerNewTeam("l" + i);
            team.addEntry(string);
            this.teams.add(team);
            this.entries.add(string);
        }
    }

    public void show(Player player) {
        player.setScoreboard(this.sb);
    }

    public void set(String string, List<String> list) {
        int n;
        this.obj.displayName(Msg.c(string));
        int n2 = Math.min(15, list.size());
        for (n = 0; n < n2; ++n) {
            this.teams.get(n).prefix(Msg.c(list.get(n)));
            this.obj.getScore(this.entries.get(n)).setScore(n2 - n);
        }
        for (n = n2; n < this.shown; ++n) {
            this.sb.resetScores(this.entries.get(n));
        }
        this.shown = n2;
    }
}

