/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Registry
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.potion.PotionType
 */
package id.zentra.minigames;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

public enum Kit {
    CRYSTAL("Crystal PvP", "&d", Material.END_CRYSTAL, List.of("&7Armor Netherite &8(Protection IV)", "&7Pedang Netherite &8(Sharpness V)", "&7End Crystal &8x128 &7+ Obsidian &8x128", "&7Totem &8x4 &7+ Golden Apple + Ender Pearl")),
    MACE("Mace", "&6", Material.MACE, List.of("&7Armor Netherite &8(Protection IV)", "&7Mace &8(Density V) &7+ Tombak Netherite &8(Lunge)", "&7Wind Charge &8x64 &7untuk lompat smash", "&7Kapak anti-tameng + Golden Apple")),
    SWORD("Sword", "&b", Material.DIAMOND_SWORD, List.of("&7Armor Diamond &8(Protection IV)", "&7Pedang Diamond &8(Sharpness V)", "&7Shield + Golden Apple &8x8", "&7Ender Pearl &8x4")),
    NODEBUFF("NoDebuff", "&c", Material.SPLASH_POTION, List.of("&7Armor Diamond &8(Protection IV)", "&7Pedang Diamond &8(Sharpness V)", "&7Splash Instant Health II &8(banyak)", "&7Speed Potion + Ender Pearl &8x16"));

    public final String display;
    public final String color;
    public final Material material;
    public final List<String> lore;

    private Kit(String string2, String string3, Material material, List<String> list) {
        this.display = string2;
        this.color = string3;
        this.material = material;
        this.lore = list;
    }

    public String colored() {
        return this.color + this.display;
    }

    public static Kit parse(String string) {
        String string2;
        if (string == null) {
            return null;
        }
        return switch (string2 = string.toLowerCase().replace("_", "").replace("-", "").replace(" ", "")) {
            case "crystal", "crystalpvp", "cpvp" -> CRYSTAL;
            case "mace" -> MACE;
            case "sword", "sw" -> SWORD;
            case "nodebuff", "nd", "debuff" -> NODEBUFF;
            default -> null;
        };
    }

    public ItemStack icon() {
        ItemStack itemStack = new ItemStack(this.material);
        if (this == NODEBUFF) {
            itemStack.setItemMeta((ItemMeta)Kit.potionMeta(itemStack, PotionType.STRONG_HEALING));
        }
        return itemStack;
    }

    private static PotionMeta potionMeta(ItemStack itemStack, PotionType potionType) {
        PotionMeta potionMeta = (PotionMeta)itemStack.getItemMeta();
        potionMeta.setBasePotionType(potionType);
        return potionMeta;
    }

    private static ItemStack potion(Material material, PotionType potionType, int n) {
        ItemStack itemStack = new ItemStack(material, n);
        itemStack.setItemMeta((ItemMeta)Kit.potionMeta(itemStack, potionType));
        return itemStack;
    }

    private static ItemStack gear(Material material, Enchantment enchantment, int n) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setUnbreakable(true);
        itemStack.setItemMeta(itemMeta);
        if (enchantment != null) {
            itemStack.addUnsafeEnchantment(enchantment, n);
        }
        return itemStack;
    }

    private static ItemStack enchant(ItemStack itemStack, Object ... pairs) {
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            Enchantment enchantment = (Enchantment)Registry.ENCHANTMENT.get(NamespacedKey.minecraft((String)((String)pairs[i])));
            if (enchantment != null) {
                itemStack.addUnsafeEnchantment(enchantment, ((Integer)pairs[i + 1]).intValue());
            }
        }
        return itemStack;
    }

    private static ItemStack blade(Material material) {
        return Kit.enchant(Kit.gear(material, Enchantment.SHARPNESS, 5), "unbreaking", 3, "fire_aspect", 2, "looting", 3, "sweeping_edge", 3);
    }

    private static ItemStack shield() {
        return Kit.enchant(new ItemStack(Material.SHIELD), "unbreaking", 3);
    }

    private static ItemStack spear() {
        Material material = Material.matchMaterial((String)"NETHERITE_SPEAR");
        if (material == null) {
            return Kit.gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 3);
        }
        ItemStack itemStack = Kit.gear(material, null, 0);
        Enchantment enchantment = (Enchantment)Registry.ENCHANTMENT.get(NamespacedKey.minecraft((String)"lunge"));
        if (enchantment != null) {
            itemStack.addUnsafeEnchantment(enchantment, 3);
        }
        return itemStack;
    }

    private static void armor(PlayerInventory playerInventory, String string, int n) {
        playerInventory.setHelmet(Kit.enchant(Kit.gear(Material.valueOf((String)(string + "_HELMET")), Enchantment.PROTECTION, n), "unbreaking", 3, "mending", 1));
        playerInventory.setChestplate(Kit.enchant(Kit.gear(Material.valueOf((String)(string + "_CHESTPLATE")), Enchantment.PROTECTION, n), "unbreaking", 3, "mending", 1));
        playerInventory.setLeggings(Kit.enchant(Kit.gear(Material.valueOf((String)(string + "_LEGGINGS")), Enchantment.PROTECTION, n), "unbreaking", 3, "mending", 1));
        playerInventory.setBoots(Kit.enchant(Kit.gear(Material.valueOf((String)(string + "_BOOTS")), Enchantment.PROTECTION, n), "unbreaking", 3, "mending", 1));
    }

    public void give(Player player) {
        PlayerInventory playerInventory = player.getInventory();
        playerInventory.clear();
        switch (this.ordinal()) {
            case 0: {
                Kit.armor(playerInventory, "NETHERITE", 4);
                playerInventory.setItem(0, Kit.blade(Material.NETHERITE_SWORD));
                playerInventory.setItem(1, new ItemStack(Material.END_CRYSTAL, 64));
                playerInventory.setItem(2, new ItemStack(Material.OBSIDIAN, 64));
                playerInventory.setItem(3, new ItemStack(Material.GOLDEN_APPLE, 16));
                playerInventory.setItem(4, new ItemStack(Material.ENDER_PEARL, 16));
                playerInventory.setItem(5, new ItemStack(Material.END_CRYSTAL, 64));
                playerInventory.setItem(6, new ItemStack(Material.OBSIDIAN, 64));
                playerInventory.setItemInOffHand(new ItemStack(Material.TOTEM_OF_UNDYING));
                for (int i = 9; i < 12; ++i) {
                    playerInventory.setItem(i, new ItemStack(Material.TOTEM_OF_UNDYING));
                }
                break;
            }
            case 1: {
                Kit.armor(playerInventory, "NETHERITE", 4);
                playerInventory.setItem(0, Kit.enchant(Kit.gear(Material.MACE, Enchantment.DENSITY, 5), "breach", 4, "wind_burst", 3, "unbreaking", 3));
                playerInventory.setItem(1, Kit.spear());
                playerInventory.setItem(2, new ItemStack(Material.WIND_CHARGE, 64));
                playerInventory.setItem(3, Kit.enchant(Kit.gear(Material.DIAMOND_AXE, Enchantment.SHARPNESS, 5), "unbreaking", 3, "efficiency", 5));
                playerInventory.setItem(4, new ItemStack(Material.GOLDEN_APPLE, 16));
                playerInventory.setItem(5, new ItemStack(Material.ENDER_PEARL, 8));
                playerInventory.setItemInOffHand(Kit.shield());
                break;
            }
            case 3: {
                int n;
                Kit.armor(playerInventory, "DIAMOND", 4);
                playerInventory.setItem(0, Kit.blade(Material.DIAMOND_SWORD));
                playerInventory.setItem(1, new ItemStack(Material.ENDER_PEARL, 16));
                playerInventory.setItem(2, Kit.potion(Material.POTION, PotionType.STRONG_SWIFTNESS, 1));
                for (n = 3; n <= 6; ++n) {
                    playerInventory.setItem(n, Kit.potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1));
                }
                playerInventory.setItem(9, Kit.potion(Material.POTION, PotionType.STRONG_SWIFTNESS, 1));
                for (n = 10; n < 36; ++n) {
                    playerInventory.setItem(n, Kit.potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1));
                }
                break;
            }
            default: {
                Kit.armor(playerInventory, "DIAMOND", 4);
                playerInventory.setItem(0, Kit.blade(Material.DIAMOND_SWORD));
                playerInventory.setItem(1, new ItemStack(Material.GOLDEN_APPLE, 8));
                playerInventory.setItem(2, new ItemStack(Material.ENDER_PEARL, 4));
                playerInventory.setItemInOffHand(Kit.shield());
            }
        }
    }
}

