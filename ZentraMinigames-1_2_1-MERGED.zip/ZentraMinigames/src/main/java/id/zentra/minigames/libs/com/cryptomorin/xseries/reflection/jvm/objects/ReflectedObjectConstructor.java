/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.AbstractMemberReflectedObject;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import org.jspecify.annotations.NonNull;

final class ReflectedObjectConstructor
extends AbstractMemberReflectedObject {
    private final Constructor<?> delegate;

    ReflectedObjectConstructor(Constructor<?> delegate) {
        this.delegate = delegate;
    }

    @Override
    public @NonNull ReflectedObject.Type type() {
        return ReflectedObject.Type.CONSTRUCTOR;
    }

    @Override
    public @NonNull String name() {
        return "<init>";
    }

    @Override
    public @NonNull Constructor<?> unreflect() {
        return this.delegate;
    }

    @Override
    protected Member member() {
        return this.delegate;
    }
}

