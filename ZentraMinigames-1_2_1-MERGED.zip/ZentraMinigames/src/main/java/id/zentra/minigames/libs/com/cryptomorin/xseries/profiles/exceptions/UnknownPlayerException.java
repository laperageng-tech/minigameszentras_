/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.InvalidProfileException;
import org.jetbrains.annotations.NotNull;

public final class UnknownPlayerException
extends InvalidProfileException {
    private final Object unknownObject;

    public UnknownPlayerException(Object unknownObject, String message) {
        super(unknownObject.toString(), message);
        this.unknownObject = unknownObject;
    }

    @NotNull
    public Object getUnknownObject() {
        return this.unknownObject;
    }
}

