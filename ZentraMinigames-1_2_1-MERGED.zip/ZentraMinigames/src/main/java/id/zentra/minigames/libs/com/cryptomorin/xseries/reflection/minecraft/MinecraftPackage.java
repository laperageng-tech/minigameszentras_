/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Pattern
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XReflection;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.classes.PackageHandle;
import org.intellij.lang.annotations.Pattern;

public enum MinecraftPackage implements PackageHandle
{
    NMS(XReflection.NMS_PACKAGE),
    CB(XReflection.CRAFTBUKKIT_PACKAGE),
    BUKKIT("org.bukkit"),
    SPIGOT("org.spigotmc");

    private final String packageId;

    private MinecraftPackage(String packageName) {
        this.packageId = packageName;
    }

    @Override
    public String packageId() {
        return this.name();
    }

    @Override
    public String getBasePackageName() {
        return this.packageId;
    }

    @Override
    public String getPackage(@Pattern(value="(\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*\\.)*\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String packageName) {
        if (packageName.startsWith(".") || packageName.endsWith(".")) {
            throw new IllegalArgumentException("Package name must not start or end with a dot: " + packageName + " (" + this + ')');
        }
        if (!packageName.isEmpty() && (this != NMS || XReflection.supports(1, 17, 0))) {
            return this.packageId + '.' + packageName;
        }
        return this.packageId;
    }
}

