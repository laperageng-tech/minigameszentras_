/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.MinecraftClient;

public interface ProfileRequestConfiguration {
    public void configure(MinecraftClient.Session var1);
}

