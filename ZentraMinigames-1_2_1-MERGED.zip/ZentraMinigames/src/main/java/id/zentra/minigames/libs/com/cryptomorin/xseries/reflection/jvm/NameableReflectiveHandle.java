/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Pattern
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.NamedReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftMapping;
import org.intellij.lang.annotations.Pattern;

public interface NameableReflectiveHandle
extends NamedReflectiveHandle {
    public NameableReflectiveHandle map(MinecraftMapping var1, @Pattern(value="\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String var2);

    public NameableReflectiveHandle named(String ... var1);
}

