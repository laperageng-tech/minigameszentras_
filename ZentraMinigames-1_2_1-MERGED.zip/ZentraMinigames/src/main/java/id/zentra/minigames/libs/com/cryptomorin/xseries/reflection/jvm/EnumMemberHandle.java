/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Language
 *  org.intellij.lang.annotations.Pattern
 *  org.jetbrains.annotations.ApiStatus$Obsolete
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XReflection;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.MemberHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.NamedMemberHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.classes.ClassHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObjectHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftMapping;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.Field;
import org.intellij.lang.annotations.Language;
import org.intellij.lang.annotations.Pattern;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EnumMemberHandle
extends NamedMemberHandle {
    public EnumMemberHandle(ClassHandle clazz) {
        super(clazz);
    }

    @Override
    public EnumMemberHandle map(MinecraftMapping mapping, @Pattern(value="\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String name) {
        super.map(mapping, name);
        return this;
    }

    @Override
    public EnumMemberHandle named(String ... names) {
        super.named(names);
        return this;
    }

    @Override
    @ApiStatus.Obsolete
    public MemberHandle signature(@Language(value="Java", suffix=";") String declaration) {
        throw new UnsupportedOperationException();
    }

    @Override
    @NotNull
    @ApiStatus.Obsolete
    public MethodHandle unreflect() {
        return (MethodHandle)super.unreflect();
    }

    @Override
    @ApiStatus.Obsolete
    @Nullable
    public MethodHandle reflectOrNull() {
        return (MethodHandle)super.reflectOrNull();
    }

    @Override
    @ApiStatus.Obsolete
    @NotNull
    public ReflectiveHandle<ReflectedObject> jvm() {
        return new ReflectedObjectHandle(() -> ReflectedObject.of(this.reflectJvm()));
    }

    @Override
    @ApiStatus.Obsolete
    public MethodHandle reflect() throws ReflectiveOperationException {
        Field jvm = this.reflectJvm();
        return this.clazz.getNamespace().getLookup().unreflectGetter(jvm);
    }

    @Nullable
    public Object getEnumConstant() {
        try {
            return this.reflectJvm().get(null);
        }
        catch (ReflectiveOperationException ex) {
            throw XReflection.throwCheckedException(ex);
        }
    }

    public Field reflectJvm() throws ReflectiveOperationException {
        if (this.names.isEmpty()) {
            throw new IllegalStateException("No enum names specified");
        }
        Throwable errors = null;
        Field field = null;
        Class clazz = (Class)this.clazz.reflect();
        if (!clazz.isEnum()) {
            throw new IllegalStateException("Class is not an enum: " + this.clazz + " -> " + clazz);
        }
        for (String name : this.names) {
            if (field != null) break;
            try {
                field = clazz.getDeclaredField(name);
                if (field.isEnumConstant()) continue;
                throw new NoSuchFieldException("Field named '" + name + "' was found but it's not an enum constant " + this);
            }
            catch (NoSuchFieldException ex) {
                field = null;
                if (errors == null) {
                    errors = new NoSuchFieldException("None of the enums were found for " + this);
                }
                errors.addSuppressed(ex);
            }
        }
        if (field == null) {
            throw (NoSuchFieldException)XReflection.relativizeSuppressedExceptions(errors);
        }
        return this.handleAccessible(field);
    }

    @Override
    @ApiStatus.Obsolete
    public EnumMemberHandle copy() {
        throw new UnsupportedOperationException();
    }
}

