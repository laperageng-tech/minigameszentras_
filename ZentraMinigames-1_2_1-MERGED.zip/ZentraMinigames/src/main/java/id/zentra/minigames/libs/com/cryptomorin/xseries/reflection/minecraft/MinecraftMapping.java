/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft;

public enum MinecraftMapping {
    MOJANG,
    OBFUSCATED,
    SPIGOT;

}

