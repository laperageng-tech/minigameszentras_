/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.cache.Cache
 *  com.google.common.cache.CacheBuilder
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.ListMultimap
 *  com.google.common.collect.Multimap
 *  com.google.common.collect.MultimapBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  com.mojang.authlib.properties.PropertyMap
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.ApiStatus$Obsolete
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.Iterables;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.PlayerProfiles;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.PlayerUUIDs;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.ProfileLogger;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.ProfilesCore;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.UnknownPlayerException;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.MojangGameProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.XGameProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.property.XProperty;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock.KeyedLock;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock.MojangRequestQueue;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.MinecraftClient;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.MojangProfileCache;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.PlayerProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.ProfileRequestConfiguration;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.RateLimiter;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.ProfileInputType;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.XReflection;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public final class MojangAPI {
    private static final MojangProfileCache MOJANG_PROFILE_CACHE = !ProfilesCore.NULLABILITY_RECORD_UPDATE ? new MojangProfileCache.GameProfileCache(ProfilesCore.YggdrasilMinecraftSessionService_insecureProfiles) : new MojangProfileCache.ProfileResultCache(ProfilesCore.YggdrasilMinecraftSessionService_insecureProfiles);
    private static final Cache<UUID, Optional<GameProfile>> INSECURE_PROFILES = CacheBuilder.newBuilder().expireAfterWrite(6L, TimeUnit.HOURS).build();
    private static final boolean REQUIRE_SECURE_PROFILES = false;
    private static final MinecraftClient USERNAME_TO_UUID = new MinecraftClient("GET", "https://api.mojang.com/users/profiles/minecraft/", new RateLimiter(600, Duration.ofMinutes(10L)));
    private static final MinecraftClient USERNAMES_TO_UUIDS = new MinecraftClient("POST", "https://api.minecraftservices.com/minecraft/profile/lookup/bulk/byname", new RateLimiter(600, Duration.ofMinutes(10L)));
    private static final MinecraftClient UUID_TO_PROFILE = new MinecraftClient("GET", "https://sessionserver.mojang.com/session/minecraft/profile/", new RateLimiter(200, Duration.ofMinutes(1L)));

    @Nullable
    public static UUID requestUsernameToUUID(@NotNull String username) throws IOException {
        JsonElement requestElement = USERNAME_TO_UUID.session(null).append(username).request();
        if (requestElement == null) {
            return null;
        }
        JsonObject userJson = requestElement.getAsJsonObject();
        JsonElement idElement = userJson.get("id");
        if (idElement == null) {
            throw new IllegalArgumentException("No 'id' field for UUID request for '" + username + "': " + userJson);
        }
        return PlayerUUIDs.UUIDFromDashlessString(idElement.getAsString());
    }

    @ApiStatus.Obsolete
    private static GameProfile getCachedProfileByUsername(String username) {
        try {
            @Nullable Object profile = ProfilesCore.GameProfileCache_get$profileByName$.invoke(ProfilesCore.USER_CACHE, username);
            if (profile instanceof Optional) {
                profile = ((Optional)profile).orElse(null);
            }
            GameProfile gameProfile = profile == null ? PlayerProfiles.createGameProfile(PlayerUUIDs.IDENTITY_UUID, username).object() : PlayerProfiles.sanitizeProfile((GameProfile)profile);
            ProfileLogger.debug("The cached profile for {} -> {}", username, profile);
            return gameProfile;
        }
        catch (Throwable throwable) {
            ProfileLogger.LOGGER.error("Unable to get cached profile by username: {}", (Object)username, (Object)throwable);
            return null;
        }
    }

    public static Optional<GameProfile> getMojangCachedProfileFromUsername(String username) {
        try {
            return MojangAPI.getMojangCachedProfileFromUsername0(username);
        }
        catch (Throwable e) {
            throw XReflection.throwCheckedException(e);
        }
    }

    private static Optional<GameProfile> getMojangCachedProfileFromUsername0(String username) throws Throwable {
        Optional<GameProfile> optional;
        String normalized = username.toLowerCase(Locale.ENGLISH);
        Object userCacheEntry = ProfilesCore.UserCache_profilesByName.get(normalized);
        if (userCacheEntry != null) {
            if (ProfilesCore.GameProfileInfo_setLastAccess != null && ProfilesCore.UserCache_getNextOperation != null) {
                long nextOperation = ProfilesCore.UserCache_getNextOperation.invoke(ProfilesCore.USER_CACHE);
                ProfilesCore.GameProfileInfo_setLastAccess.invoke(userCacheEntry, nextOperation);
            }
            if (ProfilesCore.GameProfileInfo_getProfile != null) {
                optional = Optional.of(ProfilesCore.GameProfileInfo_getProfile.invoke(userCacheEntry));
            } else {
                Object nameAndId = ProfilesCore.GameProfileInfo_nameAndId.invoke(userCacheEntry);
                optional = Optional.of(XGameProfile.create(ProfilesCore.NameAndId_id.invoke(nameAndId), ProfilesCore.NameAndId_name.invoke(nameAndId)).object());
            }
        } else {
            UUID realUUID = PlayerUUIDs.getRealUUIDOfPlayer(username);
            if (realUUID == null) {
                return Optional.empty();
            }
            GameProfile profile = PlayerProfiles.createGameProfile(PlayerUUIDs.isOnlineMode() ? realUUID : PlayerUUIDs.getOfflineUUID(username), username).object();
            optional = Optional.of(profile);
            MojangAPI.cacheProfile(profile);
        }
        return optional;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static Map<UUID, String> usernamesToUUIDs(@NotNull Collection<String> usernames, @Nullable ProfileRequestConfiguration config) {
        HashMap<String, KeyedLock<String, UUID>> pendingUsernames;
        HashMap<UUID, String> mapped;
        block15: {
            if (usernames == null || usernames.isEmpty()) {
                throw new IllegalArgumentException("Usernames are null or empty");
            }
            for (String username : usernames) {
                if (username != null && ProfileInputType.USERNAME.pattern.matcher(username).matches()) continue;
                throw new IllegalArgumentException("One of the requested usernames is invalid: " + username + " in " + usernames);
            }
            mapped = new HashMap<UUID, String>(usernames.size());
            pendingUsernames = new HashMap<String, KeyedLock<String, UUID>>(usernames.size());
            for (String string : usernames) {
                if (pendingUsernames.containsKey(string)) continue;
                KeyedLock<String, UUID> lock = MojangRequestQueue.USERNAME_REQUESTS.lock(string, PlayerUUIDs.USERNAME_TO_ONLINE::get);
                UUID cached = lock.getOrRetryValue();
                if (cached != null) {
                    mapped.put(cached, string);
                    lock.unlock();
                    continue;
                }
                pendingUsernames.put(string, lock);
            }
            if (!pendingUsernames.isEmpty()) break block15;
            HashMap<UUID, String> hashMap = mapped;
            for (KeyedLock<String, UUID> lock : pendingUsernames.values()) {
                lock.unlock();
            }
            return hashMap;
        }
        try {
            boolean onlineMode = PlayerUUIDs.isOnlineMode();
            Iterable iterable = Iterables.partition(pendingUsernames.keySet(), (int)10);
            for (List batch : iterable) {
                JsonArray response;
                try {
                    response = USERNAMES_TO_UUIDS.session(config).body(batch).request().getAsJsonArray();
                }
                catch (IOException ex) {
                    throw new IllegalStateException("Failed to request UUIDs for username batch: " + batch, ex);
                }
                for (JsonElement element : response) {
                    String prev;
                    JsonObject obj = element.getAsJsonObject();
                    String name = obj.get("name").getAsString();
                    UUID realId = PlayerUUIDs.UUIDFromDashlessString(obj.get("id").getAsString());
                    UUID offlineId = PlayerUUIDs.getOfflineUUID(name);
                    PlayerUUIDs.USERNAME_TO_ONLINE.put(name, realId);
                    PlayerUUIDs.ONLINE_TO_OFFLINE.put(realId, offlineId);
                    PlayerUUIDs.OFFLINE_TO_ONLINE.put(offlineId, realId);
                    if (!ProfilesCore.UserCache_profilesByName.containsKey(name)) {
                        MojangAPI.cacheProfile(PlayerProfiles.createGameProfile(onlineMode ? realId : offlineId, name).object());
                    }
                    if ((prev = mapped.put(realId, name)) == null) continue;
                    throw new IllegalArgumentException("Got duplicate usernames for UUID: " + realId + " (" + prev + " -> " + name + ')');
                }
            }
        }
        catch (Throwable throwable) {
            throw throwable;
        }
        finally {
            for (KeyedLock keyedLock : pendingUsernames.values()) {
                keyedLock.unlock();
            }
        }
        return mapped;
    }

    @NotNull
    public static GameProfile getCachedProfileByUUID(UUID uuid) {
        uuid = PlayerUUIDs.isOnlineMode() ? uuid : PlayerUUIDs.ONLINE_TO_OFFLINE.getOrDefault(uuid, uuid);
        try {
            @Nullable Object profile = ProfilesCore.GameProfileCache_get$profileByUUID$.invoke(ProfilesCore.USER_CACHE, uuid);
            if (profile instanceof Optional) {
                profile = ((Optional)profile).orElse(null);
            }
            if (ProfilesCore.NameAndId_name != null && profile != null) {
                String name = ProfilesCore.NameAndId_name.invoke(profile);
                UUID id = ProfilesCore.NameAndId_id.invoke(profile);
                profile = XGameProfile.create(id, name).object();
            }
            ProfileLogger.debug("The cached profile for {} -> {}", uuid, profile);
            return profile == null ? PlayerProfiles.createNamelessGameProfile(uuid).object() : PlayerProfiles.sanitizeProfile((GameProfile)profile);
        }
        catch (Throwable throwable) {
            ProfileLogger.LOGGER.error("Unable to get cached profile by UUID: {}", (Object)uuid, (Object)throwable);
            return PlayerProfiles.createNamelessGameProfile(uuid).object();
        }
    }

    private static void cacheProfile(GameProfile profile) {
        try {
            if (ProfilesCore.NameAndId$ctor_GameProfile == null) {
                ProfilesCore.CachedUserNameToIdResolver_add.invoke(ProfilesCore.USER_CACHE, profile);
            } else {
                Object nameAndId = ProfilesCore.NameAndId$ctor_GameProfile.invoke(profile);
                ProfilesCore.CachedUserNameToIdResolver_add.invoke(ProfilesCore.USER_CACHE, nameAndId);
            }
            ProfileLogger.debug("Profile is now cached: {}", profile);
        }
        catch (Throwable throwable) {
            ProfileLogger.LOGGER.error("Unable to cache profile {}", (Object)profile);
            throwable.printStackTrace();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @NotNull
    public static GameProfile getOrFetchProfile(@NotNull MojangGameProfile profile) throws UnknownPlayerException {
        UUID realUUID;
        if (profile.name().equals("XSeries")) {
            realUUID = profile.id();
        } else {
            realUUID = PlayerUUIDs.getRealUUIDOfPlayer(profile.name(), profile.id());
            if (realUUID == null) {
                throw new UnknownPlayerException((Object)profile.name(), "Player with the given properties not found: " + profile);
            }
        }
        try (KeyedLock<UUID, GameProfile> lock = MojangRequestQueue.UUID_REQUESTS.lock(realUUID, () -> MojangAPI.handleCache(profile.object(), realUUID));){
            GameProfile cached = lock.getOrRetryValue();
            if (cached != null) {
                GameProfile gameProfile = cached;
                return gameProfile;
            }
            JsonElement request = MojangAPI.requestProfile(profile.object(), realUUID);
            JsonObject profileData = request.getAsJsonObject();
            ArrayList<String> profileActions = new ArrayList<String>();
            GameProfile fetchedProfile = MojangAPI.createGameProfile(profileData, profileActions);
            fetchedProfile = PlayerProfiles.sanitizeProfile(fetchedProfile);
            MojangAPI.cacheProfile(fetchedProfile);
            INSECURE_PROFILES.put((Object)realUUID, Optional.of(fetchedProfile));
            MOJANG_PROFILE_CACHE.cache(new PlayerProfile(realUUID, profile.object(), fetchedProfile, profileActions));
            GameProfile gameProfile = fetchedProfile;
            return gameProfile;
        }
        catch (Throwable ex) {
            throw new IllegalStateException("Failed to fetch profile for " + profile, ex);
        }
    }

    @Nullable
    private static GameProfile handleCache(@NotNull GameProfile profile, UUID realUUID) {
        Optional cached = (Optional)INSECURE_PROFILES.getIfPresent((Object)realUUID);
        if (cached != null) {
            ProfileLogger.debug("Found cached profile from UUID ({}): {} -> {}", realUUID, profile, cached);
            if (cached.isPresent()) {
                return (GameProfile)cached.get();
            }
            throw new UnknownPlayerException(realUUID, "Player with the given properties not found: " + profile);
        }
        Optional<GameProfile> mojangCache = MOJANG_PROFILE_CACHE.get(realUUID, profile);
        if (mojangCache != null) {
            INSECURE_PROFILES.put((Object)realUUID, mojangCache);
            if (mojangCache.isPresent()) {
                return mojangCache.get();
            }
            throw new UnknownPlayerException(realUUID, "Player with the given properties not found: " + profile);
        }
        return null;
    }

    @NotNull
    private static JsonElement requestProfile(@NotNull GameProfile profile, UUID realUUID) {
        JsonElement request;
        try {
            request = UUID_TO_PROFILE.session(null).append(PlayerUUIDs.toUndashedUUID(realUUID) + "?unsigned=" + true).request();
        }
        catch (IOException e) {
            throw new IllegalStateException("Failed to request profile: " + profile + " with real UUID: " + realUUID, e);
        }
        if (request == null) {
            INSECURE_PROFILES.put((Object)realUUID, Optional.empty());
            MOJANG_PROFILE_CACHE.cache(new PlayerProfile(realUUID, profile, null, null));
            throw new UnknownPlayerException(realUUID, "Player with the given properties not found: " + profile);
        }
        return request;
    }

    @NotNull
    private static GameProfile createGameProfile(JsonObject profileData, List<String> profileActions) {
        JsonElement profileActionsElement;
        UUID id = PlayerUUIDs.UUIDFromDashlessString(profileData.get("id").getAsString());
        String name = profileData.get("name").getAsString();
        ListMultimap propertyMap = MultimapBuilder.hashKeys().arrayListValues().build();
        JsonElement propertiesEle = profileData.get("properties");
        if (propertiesEle != null) {
            JsonArray props = propertiesEle.getAsJsonArray();
            for (JsonElement prop : props) {
                JsonObject obj = prop.getAsJsonObject();
                String propName = obj.get("name").getAsString();
                String propValue = obj.get("value").getAsString();
                JsonElement sig = obj.get("signature");
                Property property = sig != null ? new Property(propName, propValue, sig.getAsString()) : new Property(propName, propValue);
                propertyMap.put((Object)propName, (Object)property);
            }
        }
        if ((profileActionsElement = profileData.get("profileActions")) != null) {
            for (JsonElement action : profileActionsElement.getAsJsonArray()) {
                profileActions.add(action.getAsString());
            }
        }
        PropertyMap properties = XProperty.createPropertyMap((Multimap<String, Property>)propertyMap);
        return PlayerProfiles.createGameProfile(id, name, properties).object();
    }
}

