/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Art
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.art;

import id.zentra.minigames.libs.com.cryptomorin.xseries.art.BukkitArt;
import id.zentra.minigames.libs.com.cryptomorin.xseries.art.NewArt;
import id.zentra.minigames.libs.com.cryptomorin.xseries.art.OldArt;
import org.bukkit.Art;

public class XArt {
    private static final boolean USE_INTERFACE = Art.class.isInterface();

    private XArt() {
    }

    public static BukkitArt of(Art art) {
        if (USE_INTERFACE) {
            return new NewArt(art);
        }
        return new OldArt(art);
    }
}

