/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;
import org.jetbrains.annotations.NotNull;

public final class InvalidProfileContainerException
extends ProfileException {
    private final Object container;

    public InvalidProfileContainerException(Object container, String message) {
        super(message);
        this.container = container;
    }

    @NotNull
    public Object getContainer() {
        return this.container;
    }
}

