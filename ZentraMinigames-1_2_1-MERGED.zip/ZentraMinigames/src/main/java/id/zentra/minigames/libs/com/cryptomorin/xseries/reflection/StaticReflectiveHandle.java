/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import org.jetbrains.annotations.NotNull;

public class StaticReflectiveHandle<T>
implements ReflectiveHandle<T> {
    private final T reflected;
    private final ReflectiveHandle<ReflectedObject> jvm;

    public StaticReflectiveHandle(T reflected, ReflectedObject jvm) {
        this.reflected = reflected;
        this.jvm = new StaticReflectiveHandle<ReflectedObject>(jvm);
    }

    private StaticReflectiveHandle(T reflected) {
        this.reflected = reflected;
        this.jvm = null;
    }

    @Override
    public ReflectiveHandle<T> copy() {
        return this;
    }

    @Override
    @NotNull
    public T reflect() throws ReflectiveOperationException {
        return this.reflected;
    }

    @Override
    @NotNull
    public ReflectiveHandle<ReflectedObject> jvm() {
        return this.jvm == null ? this : this.jvm;
    }
}

