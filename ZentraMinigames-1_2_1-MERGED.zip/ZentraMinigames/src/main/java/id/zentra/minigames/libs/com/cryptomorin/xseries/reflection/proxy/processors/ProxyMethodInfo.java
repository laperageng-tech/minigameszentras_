/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.processors;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.processors.MappedType;
import java.lang.reflect.Method;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class ProxyMethodInfo {
    public final ReflectiveHandle<?> handle;
    public final Method interfaceMethod;
    public final MappedType rType;
    public final MappedType[] pTypes;

    public ProxyMethodInfo(ReflectiveHandle<?> handle, Method interfaceMethod, MappedType rType, MappedType[] pTypes) {
        this.handle = handle;
        this.interfaceMethod = interfaceMethod;
        this.rType = rType;
        this.pTypes = pTypes;
    }

    public String toString() {
        return this.getClass().getSimpleName() + '(' + this.interfaceMethod + ')';
    }
}

