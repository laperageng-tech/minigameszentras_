/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Language
 *  org.intellij.lang.annotations.Pattern
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.ReflectiveNamespace;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.classes.DynamicClassHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftMapping;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftPackage;
import org.intellij.lang.annotations.Language;
import org.intellij.lang.annotations.Pattern;

public class MinecraftClassHandle
extends DynamicClassHandle {
    public MinecraftClassHandle(ReflectiveNamespace namespace) {
        super(namespace);
    }

    public MinecraftClassHandle inPackage(MinecraftPackage minecraftPackage) {
        super.inPackage(minecraftPackage);
        return this;
    }

    public MinecraftClassHandle inPackage(MinecraftPackage minecraftPackage, @Pattern(value="(\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*\\.)*\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String packageName) {
        super.inPackage(minecraftPackage, packageName);
        return this;
    }

    @Override
    public MinecraftClassHandle inner(@Language(value="Java", suffix="{}") String declaration) {
        return this.inner(this.namespace.ofMinecraft(declaration));
    }

    @Override
    public MinecraftClassHandle named(String ... clazzNames) {
        super.named(clazzNames);
        return this;
    }

    @Override
    public MinecraftClassHandle map(MinecraftMapping mapping, @Pattern(value="\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String className) {
        this.classNames.add(className);
        return this;
    }

    @Override
    public MinecraftClassHandle copy() {
        MinecraftClassHandle handle = new MinecraftClassHandle(this.namespace);
        handle.array = this.array;
        handle.parent = this.parent;
        handle.packageName = this.packageName;
        handle.classNames.addAll(this.classNames);
        return handle;
    }
}

