/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Experimental
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.builder;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.ProfileLogger;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.builder.ProfileFallback;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.builder.XSkull;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.InvalidProfileException;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileChangeException;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.gameprofile.MojangGameProfile;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.PlayerProfileFetcherThread;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang.ProfileRequestConfiguration;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.DelegateProfileable;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.ProfileContainer;
import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.objects.Profileable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class ProfileInstruction<T>
implements DelegateProfileable {
    private final ProfileContainer<T> profileContainer;
    private Profileable profileable;
    private final List<Profileable> fallbacks = new ArrayList<Profileable>();
    private Consumer<ProfileFallback<T>> onFallback;
    private ProfileRequestConfiguration profileRequestConfiguration;
    private boolean lenient = false;

    ProfileInstruction(ProfileContainer<T> profileContainer) {
        this.profileContainer = profileContainer;
    }

    @NotNull
    @Contract(mutates="this")
    public T removeProfile() {
        this.profileContainer.setProfile(null);
        return this.profileContainer.getObject();
    }

    @NotNull
    @Contract(value="_ -> this", mutates="this")
    @ApiStatus.Experimental
    public ProfileInstruction<T> profileRequestConfiguration(ProfileRequestConfiguration config) {
        this.profileRequestConfiguration = config;
        return this;
    }

    @NotNull
    @Contract(value="-> this", mutates="this")
    public ProfileInstruction<T> lenient() {
        this.lenient = true;
        return this;
    }

    @Override
    @Nullable
    @ApiStatus.Internal
    public MojangGameProfile getProfile() {
        return this.profileContainer.getProfile();
    }

    @Override
    @Contract(pure=true)
    @ApiStatus.Internal
    public Profileable getDelegateProfile() {
        return this.profileContainer;
    }

    @NotNull
    @Contract(value="_ -> this", mutates="this")
    public ProfileInstruction<T> profile(@NotNull Profileable profileable) {
        this.profileable = Objects.requireNonNull(profileable, "Profileable is null");
        return this;
    }

    @NotNull
    @Contract(value="_ -> this", mutates="this")
    public ProfileInstruction<T> fallback(Profileable ... fallbacks) {
        Objects.requireNonNull(fallbacks, "fallbacks array is null");
        this.fallbacks.addAll(Arrays.asList(fallbacks));
        return this;
    }

    @NotNull
    @Contract(value="_ -> this", mutates="this")
    public ProfileInstruction<T> onFallback(@Nullable Consumer<ProfileFallback<T>> onFallback) {
        this.onFallback = onFallback;
        return this;
    }

    @NotNull
    @Contract(value="_ -> this", mutates="this")
    public ProfileInstruction<T> onFallback(@NotNull Runnable onFallback) {
        Objects.requireNonNull(onFallback, "onFallback runnable is null");
        this.onFallback = fallback -> onFallback.run();
        return this;
    }

    @NotNull
    public T apply() {
        Objects.requireNonNull(this.profileable, "No profile was set");
        Throwable exception = null;
        ArrayList<Profileable> tries = new ArrayList<Profileable>(2 + this.fallbacks.size());
        tries.add(this.profileable);
        tries.addAll(this.fallbacks);
        if (this.lenient) {
            tries.add(XSkull.getDefaultProfile());
        }
        boolean success = false;
        boolean tryingFallbacks = false;
        for (Profileable profileable : tries) {
            try {
                MojangGameProfile gameProfile = profileable.getDisposableProfile();
                if (gameProfile != null) {
                    this.profileContainer.setProfile(gameProfile);
                    success = true;
                    break;
                }
                if (exception == null) {
                    exception = new ProfileChangeException("Could not set the profile for " + this.profileContainer);
                }
                exception.addSuppressed(new InvalidProfileException(profileable.toString(), "Profile doesn't have a value: " + profileable));
                tryingFallbacks = true;
            }
            catch (ProfileException ex) {
                if (exception == null) {
                    exception = new ProfileChangeException("Could not set the profile for " + this.profileContainer);
                }
                exception.addSuppressed(ex);
                tryingFallbacks = true;
            }
        }
        if (exception != null) {
            if (success || this.lenient) {
                ProfileLogger.debug("apply() silenced exception {}", exception);
            } else {
                throw exception;
            }
        }
        T object = this.profileContainer.getObject();
        if (tryingFallbacks && this.onFallback != null) {
            ProfileFallback<T> fallback = new ProfileFallback<T>(this, object, (ProfileChangeException)exception);
            this.onFallback.accept(fallback);
            object = fallback.getObject();
        }
        return object;
    }

    @NotNull
    public CompletableFuture<T> applyAsync() {
        return CompletableFuture.supplyAsync(this::apply, PlayerProfileFetcherThread.EXECUTOR);
    }
}

