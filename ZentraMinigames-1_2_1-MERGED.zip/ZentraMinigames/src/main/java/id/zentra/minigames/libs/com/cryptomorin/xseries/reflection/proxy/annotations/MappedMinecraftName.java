/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftMapping;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations.MappedMinecraftNames;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations.ReflectName;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.TYPE, ElementType.METHOD})
@Retention(value=RetentionPolicy.RUNTIME)
@Repeatable(value=MappedMinecraftNames.class)
public @interface MappedMinecraftName {
    public MinecraftMapping mapping();

    public ReflectName[] names();
}

