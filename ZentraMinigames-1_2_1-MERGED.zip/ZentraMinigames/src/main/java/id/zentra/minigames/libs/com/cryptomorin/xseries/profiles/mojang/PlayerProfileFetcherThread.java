/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.mojang;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.ProfileLogger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

@ApiStatus.Internal
public final class PlayerProfileFetcherThread
implements ThreadFactory {
    public static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(10, new PlayerProfileFetcherThread());
    private static final AtomicInteger COUNT = new AtomicInteger();

    @Override
    public Thread newThread(@NotNull Runnable run) {
        Thread thread = new Thread(run);
        thread.setName("Profile Lookup Executor #" + COUNT.getAndIncrement());
        thread.setUncaughtExceptionHandler((t, throwable) -> ProfileLogger.LOGGER.error("Uncaught exception in thread {}", (Object)t.getName(), (Object)throwable));
        return thread;
    }
}

