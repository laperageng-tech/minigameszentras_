/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Experimental
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.NamedReflectiveHandle;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Experimental
public interface ReflectiveMapping {
    public boolean shouldBeChecked();

    public String category();

    public String name();

    public String process(NamedReflectiveHandle var1, String var2);
}

