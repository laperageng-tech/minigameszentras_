/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.MojangAPIException;

public final class MojangAPIRetryException
extends MojangAPIException {
    private final Reason reason;

    public MojangAPIRetryException(Reason reason, String message) {
        super(message);
        this.reason = reason;
    }

    public MojangAPIRetryException(Reason reason, String message, Throwable cause) {
        super(message, cause);
        this.reason = reason;
    }

    public Reason getReason() {
        return this.reason;
    }

    public static enum Reason {
        CONNECTION_RESET,
        CONNECTION_TIMEOUT,
        RATELIMITED;

    }
}

