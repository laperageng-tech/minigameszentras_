/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.AbstractMemberReflectedObject;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import org.jspecify.annotations.NonNull;

final class ReflectedObjectField
extends AbstractMemberReflectedObject {
    private final Field delegate;

    ReflectedObjectField(Field delegate) {
        this.delegate = delegate;
    }

    @Override
    public @NonNull ReflectedObject.Type type() {
        return ReflectedObject.Type.FIELD;
    }

    @Override
    public @NonNull Field unreflect() {
        return this.delegate;
    }

    @Override
    protected Member member() {
        return this.delegate;
    }
}

