/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.lock.KeyedLock;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
final class FinalizedKeyedLock<K, V>
implements KeyedLock<K, V> {
    private final V value;

    protected FinalizedKeyedLock(V value) {
        this.value = value;
    }

    public String toString() {
        return this.getClass().getSimpleName() + '(' + this.value + ')';
    }

    @Override
    public V getOrRetryValue() {
        return this.value;
    }

    @Override
    public void lock() {
    }

    @Override
    public void unlock() {
    }

    @Override
    public void close() {
    }
}

