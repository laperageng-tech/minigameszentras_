/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.InventoryView
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.inventory;

import id.zentra.minigames.libs.com.cryptomorin.xseries.inventory.BukkitInventoryView;
import id.zentra.minigames.libs.com.cryptomorin.xseries.inventory.NewInventoryView;
import id.zentra.minigames.libs.com.cryptomorin.xseries.inventory.OldInventoryView;
import org.bukkit.inventory.InventoryView;

public final class XInventoryView {
    private static final boolean USE_INTERFACE = InventoryView.class.isInterface();

    private XInventoryView() {
    }

    public static BukkitInventoryView of(InventoryView inventoryView) {
        if (USE_INTERFACE) {
            return new NewInventoryView(inventoryView);
        }
        return new OldInventoryView(inventoryView);
    }
}

