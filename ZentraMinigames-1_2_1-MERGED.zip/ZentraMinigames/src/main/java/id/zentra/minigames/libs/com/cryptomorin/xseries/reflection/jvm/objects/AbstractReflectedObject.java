/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import org.jspecify.annotations.NonNull;

abstract class AbstractReflectedObject
implements ReflectedObject {
    AbstractReflectedObject() {
    }

    @Override
    public abstract @NonNull AnnotatedElement unreflect();

    public final <A extends Annotation> A getAnnotation(Class<A> annotationClass) {
        return this.unreflect().getAnnotation(annotationClass);
    }

    @Override
    public final boolean isAnnotationPresent(Class<? extends Annotation> annotationClass) {
        return this.unreflect().isAnnotationPresent(annotationClass);
    }

    public final <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationClass) {
        return this.unreflect().getAnnotationsByType(annotationClass);
    }

    @Override
    public final Annotation[] getAnnotations() {
        return this.unreflect().getAnnotations();
    }

    public final <A extends Annotation> A getDeclaredAnnotation(Class<A> annotationClass) {
        return this.unreflect().getDeclaredAnnotation(annotationClass);
    }

    public final <A extends Annotation> A[] getDeclaredAnnotationsByType(Class<A> annotationClass) {
        return this.unreflect().getDeclaredAnnotationsByType(annotationClass);
    }

    @Override
    public final Annotation[] getDeclaredAnnotations() {
        return this.unreflect().getDeclaredAnnotations();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof ReflectedObject) {
            return this.unreflect().equals(((ReflectedObject)obj).unreflect());
        }
        return this.unreflect().equals(obj);
    }

    public final int hashCode() {
        return this.unreflect().hashCode();
    }

    public final String toString() {
        return this.getClass().getSimpleName() + '(' + this.unreflect() + ')';
    }
}

