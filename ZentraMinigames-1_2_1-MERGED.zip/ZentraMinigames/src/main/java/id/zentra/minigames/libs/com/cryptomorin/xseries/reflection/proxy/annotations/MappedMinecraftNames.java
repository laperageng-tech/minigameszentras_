/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations.MappedMinecraftName;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.TYPE, ElementType.METHOD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface MappedMinecraftNames {
    public MappedMinecraftName[] value();
}

