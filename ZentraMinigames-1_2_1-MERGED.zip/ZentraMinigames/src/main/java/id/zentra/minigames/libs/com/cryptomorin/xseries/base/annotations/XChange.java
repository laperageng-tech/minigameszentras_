/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$Internal
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.base.annotations;

import id.zentra.minigames.libs.com.cryptomorin.xseries.base.annotations.XChanges;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jetbrains.annotations.ApiStatus;

@Target(value={ElementType.FIELD})
@Retention(value=RetentionPolicy.SOURCE)
@Repeatable(value=XChanges.class)
@Documented
@ApiStatus.Internal
public @interface XChange {
    public String version();

    public String from();

    public String to();
}

