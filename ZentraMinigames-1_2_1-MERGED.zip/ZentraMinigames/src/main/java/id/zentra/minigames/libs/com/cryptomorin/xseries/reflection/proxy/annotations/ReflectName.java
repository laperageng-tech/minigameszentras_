/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.proxy.annotations.ReflectNames;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.TYPE, ElementType.METHOD})
@Retention(value=RetentionPolicy.RUNTIME)
@Repeatable(value=ReflectNames.class)
public @interface ReflectName {
    public String[] value();

    public String version() default "";
}

