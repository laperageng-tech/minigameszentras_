/*
 * Decompiled with CFR 0.152.
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;

public class MojangAPIException
extends ProfileException {
    public MojangAPIException(String message) {
        super(message);
    }

    public MojangAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}

