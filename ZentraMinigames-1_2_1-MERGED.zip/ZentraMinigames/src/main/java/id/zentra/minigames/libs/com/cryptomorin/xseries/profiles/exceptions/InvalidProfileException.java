/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions;

import id.zentra.minigames.libs.com.cryptomorin.xseries.profiles.exceptions.ProfileException;
import org.jetbrains.annotations.NotNull;

public class InvalidProfileException
extends ProfileException {
    private final String value;

    public InvalidProfileException(String value, String message) {
        super(message);
        this.value = value;
    }

    public InvalidProfileException(String value, String message, Throwable cause) {
        super(message, cause);
        this.value = value;
    }

    @NotNull
    public String getValue() {
        return this.value;
    }
}

