/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.block.Block
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.TNTPrimed
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.util.Vector
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class PillarsGame
extends Game {
    private static final int N = 12;
    private static final int RAD = 14;
    private static final int TOP = 18;
    private static final Material[] COL = new Material[]{Material.RED_TERRACOTTA, Material.ORANGE_TERRACOTTA, Material.YELLOW_TERRACOTTA, Material.LIME_TERRACOTTA, Material.GREEN_TERRACOTTA, Material.CYAN_TERRACOTTA, Material.LIGHT_BLUE_TERRACOTTA, Material.BLUE_TERRACOTTA, Material.PURPLE_TERRACOTTA, Material.MAGENTA_TERRACOTTA, Material.PINK_TERRACOTTA, Material.WHITE_TERRACOTTA};
    private static final Material[] BLOCKS = new Material[]{Material.COBBLESTONE, Material.OAK_PLANKS, Material.STONE_BRICKS, Material.SANDSTONE, Material.WHITE_WOOL, Material.DEEPSLATE_BRICKS, Material.GLASS, Material.OAK_LOG, Material.NETHERRACK};
    private final int[] px = new int[12];
    private final int[] pz = new int[12];
    private final Set<Block> placed = new HashSet<Block>();
    private int itemEvery = 8;
    private boolean fullClear;

    public PillarsGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "pillars", "Pillars of Fortune", Material.QUARTZ_PILLAR, n, n2, n3, n4, 2, 12, List.of("Bertahan di atas pilar, rampas keberuntungan, tendang lawan ke void!", "Setiap 8 detik kamu menerima item acak. Susun jembatan atau serang lawan.", "Tiap 45 detik terjadi KEJADIAN KACAU: gravitasi rendah, hujan TNT, banjir item, dan lainnya.", "Setelah 5 menit item datang tiap 3 detik (Sudden Death). Orang terakhir menang."));
        this.voidY = n3 - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = true;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
        for (int i = 0; i < 12; ++i) {
            double d = Math.PI * 2 * (double)i / 12.0;
            this.px[i] = n2 + (int)Math.round(Math.cos(d) * 14.0);
            this.pz[i] = n4 + (int)Math.round(Math.sin(d) * 14.0);
        }
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        if (this.fullClear) {
            blueprint.fill(this.cx - 26, this.by - 13, this.cz - 26, this.cx + 26, this.by + 18 + 30, this.cz + 26, Material.AIR);
            this.fullClear = false;
        }
        blueprint.cone(this.cx, this.by - 14, this.cz, 18, 12, Material.OBSIDIAN);
        for (int i = 0; i < 12; ++i) {
            blueprint.fill(this.px[i], this.by - 8, this.pz[i], this.px[i], this.by + 18 - 1, this.pz[i], COL[i % COL.length]);
            blueprint.set(this.px[i], this.by + 18, this.pz[i], Material.GOLD_BLOCK);
            // single-block pillar top only (no flat platform)
        }
        blueprint.fill(this.cx - 1, this.by - 10, this.cz - 1, this.cx + 1, this.by + 18 + 4, this.cz + 1, Material.AMETHYST_BLOCK);
        blueprint.set(this.cx, this.by + 18 + 5, this.cz, Material.SEA_LANTERN);
        blueprint.fill(this.cx, this.by + 18 + 6, this.cz, this.cx, this.by + 18 + 9, this.cz, Material.END_ROD);
    }

    @Override
    protected void onStart() {
        this.placed.clear();
        this.itemEvery = 8;
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (int i = 0; i < 12; ++i) {
            arrayList.add(i);
        }
        Collections.shuffle(arrayList, this.rnd);
        List<Player> list = this.alivePlayers();
        for (int i = 0; i < list.size(); ++i) {
            int n = (Integer)arrayList.get(i);
            Location location = new Location(this.world, (double)this.px[n] + 0.5, (double)(this.by + 18 + 1), (double)this.pz[n] + 0.5);
            location.setDirection(new Vector(this.cx - this.px[n], 0, this.cz - this.pz[n]));
            list.get(i).teleport(location);
            list.get(i).getInventory().addItem(new ItemStack[]{new ItemStack(Material.COOKED_BEEF, 4)});
        }
        this.bc("&eItem pertama turun dalam 3 detik. Kejadian kacau tiap 45 detik!");
    }

    @Override
    protected void onSecond() {
        if (this.runSecs >= 3 && this.runSecs % this.itemEvery == 0) {
            for (Player player : this.alivePlayers()) {
                this.giveRandom(player);
            }
            this.sound(Sound.ENTITY_ITEM_PICKUP, 0.6f, 1.2f);
        }
        if (this.runSecs > 0 && this.runSecs % 45 == 0) {
            this.chaos();
        }
        if (this.runSecs == 300) {
            this.itemEvery = 3;
            this.bc("&4&lSUDDEN DEATH! &cItem datang tiap 3 detik dan semua pemain bercahaya!");
            for (Player player : this.alivePlayers()) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 12000, 0, false, false));
            }
        }
        if (this.runSecs >= 480) {
            this.end(this.alivePlayers());
        }
    }

    private void giveRandom(Player player) {
        HashMap<Integer,ItemStack> hashMap = player.getInventory().addItem(new ItemStack[]{this.randomItem()});
        for (ItemStack itemStack : hashMap.values()) {
            player.getWorld().dropItem(player.getLocation(), itemStack);
        }
    }

    private ItemStack randomItem() {
        int n = this.rnd.nextInt(100);
        if (n < 30) {
            return new ItemStack(BLOCKS[this.rnd.nextInt(BLOCKS.length)], 8 + this.rnd.nextInt(9));
        }
        if (n < 42) {
            Material[] materialArray = new Material[]{Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD, Material.STONE_AXE, Material.IRON_AXE, Material.DIAMOND_SWORD};
            return new ItemStack(materialArray[this.rnd.nextInt(materialArray.length)]);
        }
        if (n < 52) {
            Material[] materialArray = new Material[]{Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.CHAINMAIL_BOOTS, Material.IRON_HELMET, Material.IRON_LEGGINGS, Material.IRON_CHESTPLATE, Material.DIAMOND_BOOTS, Material.SHIELD};
            return new ItemStack(materialArray[this.rnd.nextInt(materialArray.length)]);
        }
        if (n < 60) {
            return this.rnd.nextInt(4) == 0 ? new ItemStack(Material.GOLDEN_APPLE) : new ItemStack(Material.COOKED_PORKCHOP, 4);
        }
        if (n < 66) {
            return this.rnd.nextBoolean() ? new ItemStack(Material.BOW) : new ItemStack(Material.ARROW, 10);
        }
        if (n < 72) {
            return new ItemStack(Material.ENDER_PEARL, 1 + this.rnd.nextInt(2));
        }
        if (n < 77) {
            return this.rnd.nextBoolean() ? new ItemStack(Material.TNT, 3) : new ItemStack(Material.FLINT_AND_STEEL);
        }
        if (n < 82) {
            return new ItemStack(Material.WATER_BUCKET);
        }
        if (n < 86) {
            ItemStack itemStack = this.item(Material.STICK, 1, "&e&lTongkat Tendang", new String[0]);
            itemStack.addUnsafeEnchantment(Enchantment.KNOCKBACK, 2);
            return itemStack;
        }
        if (n < 90) {
            return new ItemStack(Material.COBWEB, 4);
        }
        if (n < 94) {
            return new ItemStack(Material.WIND_CHARGE, 4);
        }
        if (n < 97) {
            return new ItemStack(Material.SNOWBALL, 12);
        }
        return new ItemStack(Material.LAVA_BUCKET);
    }

    private void chaos() {
        List<Player> list = this.alivePlayers();
        switch (this.rnd.nextInt(5)) {
            case 0: {
                this.bc("&d&l[KEJADIAN] &fGravitasi Rendah! &7(15 detik)");
                for (Player player : list) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 300, 3));
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 300, 0));
                }
                break;
            }
            case 1: {
                this.bc("&d&l[KEJADIAN] &fHujan TNT! &7Awas kepala!");
                for (Player player : list) {
                    Location location = player.getLocation().add((double)(this.rnd.nextInt(5) - 2), 8.0, (double)(this.rnd.nextInt(5) - 2));
                    TNTPrimed tNTPrimed = (TNTPrimed)this.world.spawn(location, TNTPrimed.class);
                    tNTPrimed.setFuseTicks(50);
                }
                break;
            }
            case 2: {
                this.bc("&d&l[KEJADIAN] &fSpeed Rush! &7(15 detik)");
                for (Player player : list) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 300, 2));
                }
                break;
            }
            case 3: {
                this.bc("&d&l[KEJADIAN] &fBanjir Item! &7Semua dapat 3 item.");
                for (Player player : list) {
                    for (int i = 0; i < 3; ++i) {
                        this.giveRandom(player);
                    }
                }
                break;
            }
            default: {
                this.bc("&d&l[KEJADIAN] &fSorotan! &7Semua pemain bercahaya 10 detik.");
                for (Player player : list) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 200, 0, false, false));
                }
            }
        }
        this.sound(Sound.ENTITY_WITHER_SPAWN, 0.4f, 1.6f);
    }

    @Override
    public boolean allowPlace(Block block, Player player) {
        if (this.state != Game.State.RUNNING || block.getY() > this.by + 18 + 40) {
            return false;
        }
        this.placed.add(block);
        return true;
    }

    @Override
    public boolean allowBreak(Block block, Player player) {
        return this.state == Game.State.RUNNING && this.placed.remove(block);
    }

    @Override
    public void onExplode(EntityExplodeEvent entityExplodeEvent) {
        entityExplodeEvent.blockList().removeIf(block -> !this.placed.contains(block));
        this.placed.removeAll(entityExplodeEvent.blockList());
    }

    @Override
    protected void onReset() {
        this.placed.clear();
        this.fullClear = true;
    }

    @Override
    protected String barText() {
        return "&bPillars of Fortune &8| &fHidup: &a" + this.alive.size() + " &8| &fItem tiap &e" + this.itemEvery + "s";
    }
}

