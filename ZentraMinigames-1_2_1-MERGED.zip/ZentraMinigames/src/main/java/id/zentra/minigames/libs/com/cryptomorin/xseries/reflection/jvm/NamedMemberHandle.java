/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.intellij.lang.annotations.Pattern
 *  org.jetbrains.annotations.NotNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.MemberHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.NameableReflectiveHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.classes.ClassHandle;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.minecraft.MinecraftMapping;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.intellij.lang.annotations.Pattern;
import org.jetbrains.annotations.NotNull;

public abstract class NamedMemberHandle
extends MemberHandle
implements NameableReflectiveHandle {
    protected final Set<String> names = new HashSet<String>(5);

    @Override
    @NotNull
    public Set<String> getPossibleNames() {
        return this.names;
    }

    protected NamedMemberHandle(ClassHandle clazz) {
        super(clazz);
    }

    @Override
    public NamedMemberHandle map(MinecraftMapping mapping, @Pattern(value="\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*") String name) {
        this.names.add(name);
        return this;
    }

    @Override
    public NamedMemberHandle named(String ... names) {
        this.names.addAll(Arrays.asList(names));
        return this;
    }

    @Override
    public abstract NamedMemberHandle copy();
}

