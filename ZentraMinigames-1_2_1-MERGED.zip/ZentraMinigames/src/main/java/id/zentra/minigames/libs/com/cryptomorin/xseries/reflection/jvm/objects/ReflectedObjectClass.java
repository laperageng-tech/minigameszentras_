/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.NonNull
 */
package id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects;

import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.AbstractReflectedObject;
import id.zentra.minigames.libs.com.cryptomorin.xseries.reflection.jvm.objects.ReflectedObject;
import org.jspecify.annotations.NonNull;

final class ReflectedObjectClass
extends AbstractReflectedObject {
    private final Class<?> delegate;

    ReflectedObjectClass(Class<?> delegate) {
        this.delegate = delegate;
    }

    @Override
    public @NonNull ReflectedObject.Type type() {
        return ReflectedObject.Type.CLASS;
    }

    @Override
    public @NonNull Class<?> unreflect() {
        return this.delegate;
    }

    @Override
    public @NonNull String name() {
        return this.delegate.getSimpleName();
    }

    @Override
    public Class<?> getDeclaringClass() {
        return this.delegate.getDeclaringClass();
    }

    @Override
    public int getModifiers() {
        return this.delegate.getModifiers();
    }
}

