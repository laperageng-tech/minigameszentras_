/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.ZentraMinigames;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public final class CrumbleRunGame
extends Game {
    private static final int R = 16;
    private static final Material[] L = new Material[]{Material.RED_TERRACOTTA, Material.ORANGE_TERRACOTTA, Material.YELLOW_TERRACOTTA, Material.LIME_TERRACOTTA, Material.WHITE_TERRACOTTA};
    private final Map<Block, Integer> pending = new HashMap<Block, Integer>();

    public CrumbleRunGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "crumble", "Crumble Run", Material.ORANGE_TERRACOTTA, n, n2, n3, n4, 2, 14, List.of("Terus bergerak! Lantai hancur di bawah kakimu!", "Ada 5 lapis lantai. Jatuh ke lapis bawah masih boleh, jatuh ke void berarti tersingkir.", "Kamu punya 3 Bulu Dash: klik kanan untuk melesat ke depan dan melompati celah.", "Pemain terakhir yang masih hidup menang."));
        this.voidY = n3 - 24;
    }

    private boolean isLayer(Material material) {
        for (Material material2 : L) {
            if (material2 != material) continue;
            return true;
        }
        return false;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        int n;
        blueprint.cone(this.cx, this.by - 26, this.cz, 15, 12, Material.SMOOTH_BASALT);
        for (n = 0; n < 5; ++n) {
            blueprint.disc(this.cx, this.by - 6 * n, this.cz, 16, L[n]);
            blueprint.ring(this.cx, this.by - 6 * n, this.cz, 15, 16, Material.RED_TERRACOTTA);
        }
        for (n = 0; n < 8; ++n) {
            double d = Math.PI * 2 * (double)n / 8.0;
            int n2 = this.cx + (int)Math.round(Math.cos(d) * 19.0);
            int n3 = this.cz + (int)Math.round(Math.sin(d) * 19.0);
            blueprint.fill(n2, this.by - 26, n3, n2, this.by + 8, n3, Material.CRYING_OBSIDIAN);
            blueprint.set(n2, this.by + 9, n3, Material.SHROOMLIGHT);
        }
    }

    @Override
    protected void onStart() {
        this.pending.clear();
        for (Player player : this.alivePlayers()) {
            double d = this.rnd.nextDouble() * Math.PI * 2.0;
            double d2 = this.rnd.nextDouble() * 12.0;
            player.teleport(new Location(this.world, (double)this.cx + 0.5 + Math.cos(d) * d2, (double)(this.by + 1), (double)this.cz + 0.5 + Math.sin(d) * d2));
            player.getInventory().setItem(0, this.item(Material.FEATHER, 3, "&b&lBulu Dash", "&7Klik kanan untuk melesat!"));
        }
        this.bc("&eLantai mulai hancur saat kamu menginjaknya. Lari!");
    }

    @Override
    protected void onFast() {
        Location location;
        for (Player object : this.alivePlayers()) {
            location = object.getLocation();
            for (double d : new double[]{-0.3, 0.3}) {
                for (double d2 : new double[]{-0.3, 0.3}) {
                    Block block = this.world.getBlockAt((int)Math.floor(location.getX() + d), (int)Math.floor(location.getY() - 0.1), (int)Math.floor(location.getZ() + d2));
                    if (!this.isLayer(block.getType()) || this.pending.containsKey(block)) continue;
                    this.pending.put(block, 8);
                }
            }
        }
        Iterator<Map.Entry<Block,Integer>> iterator = this.pending.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Block,Integer> entry = iterator.next();
            entry.setValue(entry.getValue() - 1);
            if (entry.getValue() > 0) continue;
            Block blk = entry.getKey();
            blk.setType(Material.AIR, false);
            this.world.spawnParticle(Particle.CLOUD, blk.getLocation().add(0.5, 0.8, 0.5), 2, 0.2, 0.1, 0.2, 0.01);
            iterator.remove();
        }
    }

    @Override
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        if (this.state != Game.State.RUNNING) {
            return;
        }
        Action action = playerInteractEvent.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack itemStack = playerInteractEvent.getItem();
        if (itemStack == null || itemStack.getType() != Material.FEATHER) {
            return;
        }
        Player player = playerInteractEvent.getPlayer();
        if (!this.alive.contains(player.getUniqueId())) {
            return;
        }
        playerInteractEvent.setCancelled(true);
        itemStack.setAmount(itemStack.getAmount() - 1);
        player.setVelocity(player.getLocation().getDirection().multiply(0.9).setY(0.75));
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.3f);
    }

    @Override
    protected void onReset() {
        this.pending.clear();
    }

    @Override
    protected String barText() {
        return "&6Crumble Run &8| &fHidup: &a" + this.alive.size();
    }
}

