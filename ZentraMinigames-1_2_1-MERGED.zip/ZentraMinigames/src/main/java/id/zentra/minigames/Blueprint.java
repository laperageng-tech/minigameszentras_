/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package id.zentra.minigames;

import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public final class Blueprint {
    private final List<Fill> fills = new ArrayList<Fill>();

    public Blueprint fill(int n, int n2, int n3, int n4, int n5, int n6, Material material) {
        this.fills.add(new Fill(Math.min(n, n4), Math.min(n2, n5), Math.min(n3, n6), Math.max(n, n4), Math.max(n2, n5), Math.max(n3, n6), material));
        return this;
    }

    public Blueprint set(int n, int n2, int n3, Material material) {
        return this.fill(n, n2, n3, n, n2, n3, material);
    }

    public Blueprint box(int n, int n2, int n3, int n4, int n5, int n6, Material material) {
        int n7 = Math.min(n, n4);
        int n8 = Math.min(n2, n5);
        int n9 = Math.min(n3, n6);
        int n10 = Math.max(n, n4);
        int n11 = Math.max(n2, n5);
        int n12 = Math.max(n3, n6);
        this.fill(n7, n8, n9, n10, n8, n12, material);
        this.fill(n7, n11, n9, n10, n11, n12, material);
        this.fill(n7, n8, n9, n7, n11, n12, material);
        this.fill(n10, n8, n9, n10, n11, n12, material);
        this.fill(n7, n8, n9, n10, n11, n9, material);
        this.fill(n7, n8, n12, n10, n11, n12, material);
        return this;
    }

    public static boolean inRing(int n, int n2, int n3, int n4) {
        int n5 = n * n + n2 * n2;
        return n5 <= n4 * n4 && (n3 < 0 || n5 > n3 * n3);
    }

    public Blueprint ring(int n, int n2, int n3, int n4, int n5, Material material) {
        for (int i = -n5; i <= n5; ++i) {
            int n6 = Integer.MIN_VALUE;
            for (int j = -n5; j <= n5 + 1; ++j) {
                boolean bl;
                boolean bl2 = bl = j <= n5 && Blueprint.inRing(j, i, n4, n5);
                if (bl && n6 == Integer.MIN_VALUE) {
                    n6 = j;
                    continue;
                }
                if (bl || n6 == Integer.MIN_VALUE) continue;
                this.fill(n + n6, n2, n3 + i, n + j - 1, n2, n3 + i, material);
                n6 = Integer.MIN_VALUE;
            }
        }
        return this;
    }

    public Blueprint disc(int n, int n2, int n3, int n4, Material material) {
        return this.ring(n, n2, n3, -1, n4, material);
    }

    public Blueprint cone(int n, int n2, int n3, int n4, int n5, Material material) {
        for (int i = 0; i < n5; ++i) {
            int n6 = Math.max(1, n4 * (n5 - i) / n5);
            this.disc(n, n2 - i, n3, n6, material);
        }
        return this;
    }

    public Blueprint cylinder(int n, int n2, int n3, int n4, int n5, Material material) {
        for (int i = n2; i <= n3; ++i) {
            this.disc(n, i, n4, n5, material);
        }
        return this;
    }

    public void build(ZentraMinigames zentraMinigames, World world, Runnable runnable) {
        this.build(zentraMinigames, world, () -> true, runnable);
    }

    public void build(ZentraMinigames zentraMinigames, final World world, final BooleanSupplier booleanSupplier, final Runnable runnable) {
        final int n = Math.max(500, zentraMinigames.getConfig().getInt("build.blocks-per-tick", 4000));
        Blueprint self = this;
        new BukkitRunnable(){
            int fi;
            long off;

            public void run() {
                if (!booleanSupplier.getAsBoolean()) {
                    return;
                }
                int n8 = n;
                while (n8 > 0 && this.fi < self.fills.size()) {
                    Fill fill = self.fills.get(this.fi);
                    int n2 = fill.x2() - fill.x1() + 1;
                    int n3 = fill.y2() - fill.y1() + 1;
                    int n4 = fill.z2() - fill.z1() + 1;
                    long l = (long)n2 * (long)n3 * (long)n4;
                    while (this.off < l && n8 > 0) {
                        int n5 = (int)(this.off % (long)n2);
                        int n6 = (int)(this.off / (long)n2 % (long)n3);
                        int n7 = (int)(this.off / ((long)n2 * (long)n3));
                        Block block = world.getBlockAt(fill.x1() + n5, fill.y1() + n6, fill.z1() + n7);
                        if (block.getType() != fill.m()) {
                            block.setType(fill.m(), false);
                        }
                        ++this.off;
                        --n8;
                    }
                    if (this.off < l) continue;
                    ++this.fi;
                    this.off = 0L;
                }
                if (this.fi >= self.fills.size()) {
                    this.cancel();
                    if (runnable != null) {
                        runnable.run();
                    }
                }
            }
        }.runTaskTimer((Plugin)zentraMinigames, 1L, 1L);
    }

    private record Fill(int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
    }
}

