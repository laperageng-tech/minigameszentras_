# ZentraMinigames 1.2.1 — SOURCE 1.2.0 + bagian yang belum ada, diambil dari partial 1.3.0

- pom.xml (Maven, Java 21, Paper API 1.21.4) + struktur src/main/java & src/main/resources
- Kit: semua gear sekarang unbreakable + enchant penuh (armor +Unbreaking III +Mending; pedang Sharpness V + Fire Aspect II + Looting III + Sweeping III; Mace +Breach IV +Wind Burst III; kapak Sharpness V + Efficiency V; shield Unbreaking III)
- Gamerule tambahan di world minigame: showDeathMessages, doInsomnia, doPatrolSpawning, doTraderSpawning, doEntityDrops, doTileDrops = false, waktu dikunci siang (6000)
- config.yml: hooks.on-init (list command console, dijalankan sekali saat world siap)
- Game: "last hit" kedaluwarsa setelah 12 detik (kill credit tidak nyasar ke pemukul lama)
- Tidak dibawa: README-STATUS.md, original-decompiled/ (SOURCE sudah berisi versi yang sudah diperbaiki)
