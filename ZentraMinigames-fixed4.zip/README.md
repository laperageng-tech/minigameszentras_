# ZentraMinigames

Plugin Minecraft minigames (arena melayang, auto-build). Paper/Purpur 1.21+, Java 21.

## Build otomatis lewat GitHub
1. Push semua file ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** -> workflow **Build Plugin** jalan otomatis.
3. Setelah hijau, buka run-nya -> bagian **Artifacts** -> download `ZentraMinigames` (isinya file `.jar`).
4. Masukkan jar ke folder `plugins/` server, restart.

## Rilis (opsional)
```
git tag v1.2.1
git push origin v1.2.1
```
Jar otomatis muncul di tab **Releases**.

## Build lokal
```
mvn -B clean package
```
Hasil: `target/ZentraMinigames-1.2.3.jar`
