package id.zentra.minigames;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;

/** Pengganti library XSeries: cukup untuk Material dan Sound yang dipakai plugin ini. */
public final class Compat {

    private Compat() {
    }

    public static Material mat(String name) {
        Material material = Material.matchMaterial(name);
        if (material == null) {
            throw new IllegalArgumentException("Material tidak dikenal: " + name);
        }
        return material;
    }

    /** Putar suara berdasarkan nama konstanta Sound (mis. ENTITY_PLAYER_LEVELUP). Diam saja kalau tidak ada. */
    public static void sound(String name, Entity entity) {
        try {
            Object value = Sound.class.getField(name).get(null);
            if (value instanceof Sound sound) {
                Location at = entity.getLocation();
                at.getWorld().playSound(at, sound, 1.0f, 1.0f);
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
    }
}
