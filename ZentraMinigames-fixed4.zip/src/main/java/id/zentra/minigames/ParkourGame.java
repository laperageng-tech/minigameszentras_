/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

public final class ParkourGame
extends Game {
    private static final int STEPS = 20;
    private final int variant;
    private final Map<UUID, Integer> checkpoints = new HashMap<UUID, Integer>();
    private final Map<UUID, Long> starts = new HashMap<UUID, Long>();
    private final Map<UUID, Mode> modes = new HashMap<UUID, Mode>();
    private final Map<UUID, Integer> falls = new HashMap<UUID, Integer>();
    private final Map<UUID, Map<Mode, Long>> records = new HashMap<UUID, Map<Mode, Long>>();

    private static Material material(String string) {
        return Compat.mat(string);
    }

    public ParkourGame(ZentraMinigames zentraMinigames, String string, String string2, int n, int n2, int n3, int n4, int n5) {
        super(zentraMinigames, string, string2, ParkourGame.material(n == 0 ? "FEATHER" : (n == 1 ? "ICE" : "BLAZE_POWDER")), n2, n3, n4, n5, 1, 20, List.of("Lompat dari platform ke platform dan capai garis akhir secepat mungkin.", "Injak checkpoint hijau secara berurutan. Jika jatuh, kamu kembali ke checkpoint terakhir.", "Tamat untuk melihat waktumu dan mulai lagi, atau gunakan /zm leave untuk keluar."));
        this.variant = n;
        this.continuous = true;
        this.voidY = n4 - 12;
    }

    private int x(int n) {
        return this.cx - 40 + n * 4;
    }

    private int z(int n) {
        return this.cz + (this.variant == 0 ? 0 : (this.variant == 1 ? (n % 2 == 0 ? -1 : 1) : (n % 4 < 2 ? -1 : 1)));
    }

    private int y(int n) {
        return this.by + (this.variant == 2 ? n / 4 : 0);
    }

    Location point(int n) {
        return new Location(this.world, (double)this.x(n) + 0.5, (double)(this.y(n) + 1), (double)this.z(n) + 0.5, -90.0f, 0.0f);
    }

    boolean atStep(Player player, int n) {
        if (player.getWorld() != this.world || !player.isOnGround()) {
            return false;
        }
        Location location = player.getLocation();
        int n2 = n == 20 ? 3 : 1;
        return Math.abs(location.getX() - ((double)this.x(n) + 0.5)) <= (double)n2 + 0.5 && Math.abs(location.getZ() - ((double)this.z(n) + 0.5)) <= (double)n2 + 0.5 && location.getY() >= (double)this.y(n) + 0.9 && location.getY() <= (double)this.y(n) + 1.5;
    }

    @Override
    protected boolean hasLobby() {
        return false;
    }

    @Override
    public Location specSpawn() {
        return this.point(0);
    }

    @Override
    public boolean joinable() {
        return this.open && (this.state == Game.State.WAITING || this.state == Game.State.RUNNING) && this.players.size() < this.max;
    }

    @Override
    public void forceStart() {
    }

    @Override
    protected void checkWin() {
    }

    @Override
    protected void onStart() {
    }

    /*
     * WARNING - void declaration
     */
    @Override
    protected void buildArena(Blueprint blueprint) {
        int n;
        int n2;
        int n32;
        int object;
        Material material = ParkourGame.material(this.variant == 0 ? "QUARTZ_BLOCK" : (this.variant == 1 ? "PACKED_ICE" : "RED_NETHER_BRICKS"));
        Material material2 = ParkourGame.material("LIME_CONCRETE");
        Material material3 = ParkourGame.material(this.variant == 2 ? "BLACKSTONE" : "POLISHED_DEEPSLATE");
        Material material4 = ParkourGame.material("SEA_LANTERN");
        for (object = 0; object <= 20; object++) {
            int n4 = this.x((int)object);
            int n5 = this.y((int)object);
            int n6 = this.z((int)object);
            n32 = object == 0 || object == 20 ? 3 : 1;
            blueprint.fill(n4 - n32, n5, n6 - n32, n4 + n32, n5, n6 + n32, object % 5 == 0 ? material2 : material);
            if (object % 5 == 0) {
                blueprint.fill(n4, n5 - 4, n6, n4, n5 - 1, n6, material3);
                blueprint.set(n4, n5 - 5, n6, material4);
            }
        }
        for (int n6 : new int[]{0, 20}) {
            n32 = this.x(n6);
            n2 = this.y(n6);
            n = this.z(n6);
            blueprint.fill(n32, n2 + 1, n - 3, n32, n2 + 5, n - 3, material3);
            blueprint.fill(n32, n2 + 1, n + 3, n32, n2 + 5, n + 3, material3);
            blueprint.fill(n32, n2 + 5, n - 3, n32, n2 + 5, n + 3, material4);
        }
        Material material5 = ParkourGame.material(this.variant == 0 ? "LIGHT_BLUE_CONCRETE" : (this.variant == 1 ? "BLUE_ICE" : "NETHER_BRICKS"));
        for (int n32b : new int[]{0, 5, 10, 15, 20}) {
            n2 = this.x(n32b);
            n = this.y(n32b);
            for (int n7 : new int[]{-1, 1}) {
                int n8 = this.cz + n7 * 8;
                blueprint.cone(n2, n - 2, n8, 3, 5, material3);
                blueprint.disc(n2, n - 1, n8, 3, material5);
                blueprint.fill(n2, n, n8, n2, n + 6, n8, material3);
                blueprint.set(n2, n + 7, n8, material4);
            }
        }
        for (int n32c : new int[]{0, 20}) {
            n2 = this.x(n32c);
            n = this.y(n32c);
            int n9 = this.z(n32c);
            blueprint.ring(n2, n - 1, n9, 4, 6, material5);
            blueprint.cone(n2, n - 2, n9, 4, 5, material3);
            blueprint.fill(n2, n + 6, n9 - 4, n2, n + 6, n9 + 4, material5);
        }
    }

    @Override
    public boolean join(Player player) {
        return this.joinWith(player, Mode.CLASSIC);
    }

    public boolean joinWith(Player player, Mode mode) {
        if (!this.joinable()) {
            return false;
        }
        if (this.state == Game.State.WAITING) {
            this.state = Game.State.RUNNING;
            this.runSecs = 0;
        }
        UUID uUID = player.getUniqueId();
        this.snapshot(player);
        this.players.add(uUID);
        this.alive.add(uUID);
        player.leaveVehicle();
        this.resetPlayer(player, GameMode.ADVENTURE);
        player.getInventory().setItem(0, this.plugin.lobbyItem(ParkourGame.material("COMPASS"), "&a&lKembali ke checkpoint", "parkour_checkpoint", "&7Kembali ke checkpoint di Classic", "&7Mode lain kembali ke awal"));
        player.getInventory().setItem(1, this.plugin.lobbyItem(ParkourGame.material("CLOCK"), "&e&lMulai ulang", "parkour_restart", "&7Mulai lintasan dan waktu dari awal"));
        player.getInventory().setItem(8, this.plugin.leaveItem());
        this.checkpoints.put(uUID, 0);
        this.starts.put(uUID, System.currentTimeMillis());
        this.modes.put(uUID, mode);
        this.falls.put(uUID, 0);
        player.teleport(this.point(0));
        this.bar.addPlayer(player);
        this.attachBoard(player);
        Msg.title(player, "&b&l" + this.name.toUpperCase(), "&e" + String.valueOf((Object)mode) + " &7| Capai garis akhir!", 5, 50, 10);
        Msg.send(player, mode == Mode.CLASSIC ? "&aCheckpoint aktif. Jatuh kembali ke checkpoint terakhir." : (mode == Mode.SPEEDRUN ? "&eTanpa checkpoint: jatuh kembali ke awal, waktu terus berjalan." : "&cHardcore: jatuh mengulang lintasan dan waktu!"));
        return true;
    }

    @Override
    public void lobbyAction(Player player, String string) {
        UUID uUID = player.getUniqueId();
        if (!this.players.contains(uUID) || this.state != Game.State.RUNNING) {
            return;
        }
        if (string.equals("parkour_checkpoint")) {
            this.onOut(player, null, "kembali");
        } else if (string.equals("parkour_restart")) {
            this.checkpoints.put(uUID, 0);
            this.starts.put(uUID, System.currentTimeMillis());
            this.falls.put(uUID, 0);
            player.setFallDistance(0.0f);
            player.teleport(this.point(0));
            Msg.bar(player, "&eLintasan dan waktu dimulai ulang!");
        } else {
            super.lobbyAction(player, string);
        }
    }

    @Override
    protected void onFast() {
        for (Player player : this.online()) {
            int n;
            UUID uUID2 = player.getUniqueId();
            int n2 = this.checkpoints.getOrDefault(uUID2, 0) + 5;
            if (n2 > 20 || player.getWorld() != this.world) continue;
            Location location = player.getLocation();
            int n3 = n = n2 == 20 ? 3 : 1;
            if (Math.abs(location.getX() - ((double)this.x(n2) + 0.5)) > (double)n + 0.5 || Math.abs(location.getZ() - ((double)this.z(n2) + 0.5)) > (double)n + 0.5 || location.getY() < (double)this.y(n2) + 0.9 || location.getY() > (double)this.y(n2) + 1.5 || !player.isOnGround()) continue;
            if (n2 == 20) {
                boolean bl;
                long l = System.currentTimeMillis() - this.starts.getOrDefault(uUID2, System.currentTimeMillis());
                Mode mode = this.modes.getOrDefault(uUID2, Mode.CLASSIC);
                Map map = this.records.computeIfAbsent(uUID2, uUID -> new HashMap());
                Long l2 = (Long)map.get((Object)mode);
                boolean bl2 = bl = l2 == null || l < l2;
                if (bl) {
                    map.put(mode, l);
                }
                String string = String.format(Locale.US, "%.2f", (double)l / 1000.0);
                Msg.title(player, "&6&lSELESAI!", "&fWaktu: &e" + string + "s" + (bl ? " &aREKOR!" : ""), 5, 60, 10);
                Msg.send(player, "&6" + this.name + " &8| &e" + String.valueOf((Object)mode) + " &8| &f" + string + "s &8| &cJatuh: " + String.valueOf(this.falls.getOrDefault(uUID2, 0)) + (bl ? " &aRekor pribadi baru!" : ""));
                Compat.sound("UI_TOAST_CHALLENGE_COMPLETE", (Entity)player);
                this.checkpoints.put(uUID2, 0);
                this.starts.put(uUID2, System.currentTimeMillis());
                this.falls.put(uUID2, 0);
                player.teleport(this.point(0));
                continue;
            }
            this.checkpoints.put(uUID2, n2);
            Msg.bar(player, this.modes.getOrDefault(uUID2, Mode.CLASSIC) == Mode.CLASSIC ? "&aCheckpoint " + n2 / 5 + "/3 tersimpan!" : "&bTahap " + n2 / 5 + "/3 tercapai!");
            Compat.sound("ENTITY_EXPERIENCE_ORB_PICKUP", (Entity)player);
        }
    }

    @Override
    protected void onOut(Player player, Player player2, String string) {
        int n;
        UUID uUID = player.getUniqueId();
        Mode mode = this.modes.getOrDefault(uUID, Mode.CLASSIC);
        this.falls.merge(uUID, 1, Integer::sum);
        int n2 = n = mode == Mode.CLASSIC ? this.checkpoints.getOrDefault(uUID, 0) : 0;
        if (mode != Mode.CLASSIC) {
            this.checkpoints.put(uUID, 0);
        }
        if (mode == Mode.HARDCORE) {
            this.starts.put(uUID, System.currentTimeMillis());
        }
        player.setFallDistance(0.0f);
        player.teleport(this.point(n));
        Msg.bar(player, mode == Mode.CLASSIC ? "&eKembali ke checkpoint!" : (mode == Mode.SPEEDRUN ? "&eKembali ke awal, waktu terus berjalan!" : "&cGagal! Waktu diulang."));
    }

    @Override
    public void onDamage(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setCancelled(true);
        if (entityDamageEvent.getCause() == EntityDamageEvent.DamageCause.VOID) {
            this.onOut(player, null, "jatuh");
        }
    }

    @Override
    protected void onLeave(Player player, boolean bl) {
        this.checkpoints.remove(player.getUniqueId());
        this.starts.remove(player.getUniqueId());
        this.modes.remove(player.getUniqueId());
        this.falls.remove(player.getUniqueId());
    }

    @Override
    protected String barText() {
        return "&b&l" + this.name + " &8| &fCapai garis akhir &8| &7/zm leave";
    }

    @Override
    protected List<String> sidebar(Player player) {
        UUID uUID = player.getUniqueId();
        Mode mode = this.modes.getOrDefault(uUID, Mode.CLASSIC);
        Long l = (Long)this.records.getOrDefault(uUID, Map.of()).get((Object)mode);
        return List.of("&8" + this.id(), " ", "&fMode &8\u00bb &b" + String.valueOf((Object)mode), "&fTahap &8\u00bb &a" + this.checkpoints.getOrDefault(uUID, 0) / 5 + "&7/3", "&fWaktu &8\u00bb &e" + (System.currentTimeMillis() - this.starts.getOrDefault(player.getUniqueId(), System.currentTimeMillis())) / 1000L + "s", "&fJatuh &8\u00bb &c" + String.valueOf(this.falls.getOrDefault(uUID, 0)), "&fRekor &8\u00bb &6" + (l == null ? "-" : String.format(Locale.US, "%.2fs", (double)l.longValue() / 1000.0)), " ", "&b/zm leave &7= keluar");
    }

    public static enum Mode {
        CLASSIC,
        SPEEDRUN,
        HARDCORE;

    }
}

