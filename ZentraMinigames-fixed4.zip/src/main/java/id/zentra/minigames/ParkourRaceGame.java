/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.plugin.Plugin
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ParkourGame;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.Plugin;

public final class ParkourRaceGame
extends Game {
    private static final String[] MAPS = new String[]{"Sky", "Ice", "Nether"};
    private static final String[] MODES = new String[]{"CLASSIC", "SPEEDRUN", "HARDCORE"};
    private final ParkourGame[] courses;
    private final Map<UUID, String> mapVotes = new HashMap<UUID, String>();
    private final Map<UUID, String> modeVotes = new HashMap<UUID, String>();
    private final Map<UUID, Integer> checkpoints = new HashMap<UUID, Integer>();
    private ParkourGame course;
    private String selectedMap;
    private ParkourGame.Mode mode;

    public ParkourRaceGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4) {
        super(zentraMinigames, "parkourrace", "Parkour 1v1", Compat.mat("FEATHER"), n, n2, n3, n4, 2, 2, List.of("Balapan menuju garis akhir; pemain pertama yang sampai menang.", "Setelah lawan ditemukan, vote map dan mode di ruang tunggu.", "Jika tidak ada suara atau seri, pilihan diacak."));
        this.courses = new ParkourGame[]{new ParkourGame(zentraMinigames, "race-sky", "Sky Parkour", 0, n, n2, n3, n4 - 28), new ParkourGame(zentraMinigames, "race-ice", "Ice Parkour", 1, n, n2, n3, n4), new ParkourGame(zentraMinigames, "race-nether", "Nether Parkour", 2, n, n2, n3, n4 + 28)};
        this.voidY = n3 - 12;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        for (ParkourGame parkourGame : this.courses) {
            parkourGame.buildArena(blueprint);
        }
    }

    @Override
    public boolean join(Player player) {
        if (!super.join(player)) {
            return false;
        }
        if (this.players.size() == 2) {
            this.bc("&aLawan ditemukan! Gunakan item Vote untuk memilih map dan mode.");
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
                if (this.players.size() == 2 && (this.state == Game.State.WAITING || this.state == Game.State.COUNTDOWN)) {
                    for (Player p2 : this.online()) {
                        this.plugin.manager().openRaceVote(p2, this);
                    }
                }
            });
        }
        return true;
    }

    public boolean canVote(Player player) {
        return this.players.size() == 2 && this.players.contains(player.getUniqueId()) && (this.state == Game.State.WAITING || this.state == Game.State.COUNTDOWN);
    }

    public void vote(Player player, boolean bl, String string) {
        if (!this.canVote(player)) {
            return;
        }
        for (String string2 : bl ? MAPS : MODES) {
            if (!string2.equals(string)) continue;
            (bl ? this.mapVotes : this.modeVotes).put(player.getUniqueId(), string);
            Msg.send(player, "&aVote " + (bl ? "map" : "mode") + ": &e" + string);
            return;
        }
    }

    public int mapVotes(String string) {
        return (int)this.mapVotes.values().stream().filter(string::equals).count();
    }

    public int modeVotes(String string) {
        return (int)this.modeVotes.values().stream().filter(string::equals).count();
    }

    private String pick(String[] stringArray, Map<UUID, String> map) {
        map.keySet().retainAll(this.players);
        int n = -1;
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string : stringArray) {
            int n2 = (int)map.values().stream().filter(string::equals).count();
            if (n2 > n) {
                n = n2;
                arrayList.clear();
            }
            if (n2 != n) continue;
            arrayList.add(string);
        }
        return (String)arrayList.get(this.rnd.nextInt(arrayList.size()));
    }

    @Override
    public void forceStart() {
        if (this.players.size() >= 2) {
            super.forceStart();
        }
    }

    @Override
    protected void onStart() {
        this.selectedMap = this.pick(MAPS, this.mapVotes);
        this.mode = ParkourGame.Mode.valueOf(this.pick(MODES, this.modeVotes));
        int n = Arrays.asList(MAPS).indexOf(this.selectedMap);
        this.course = this.courses[n];
        this.mapVotes.clear();
        this.modeVotes.clear();
        this.checkpoints.clear();
        for (Player player : this.online()) {
            player.closeInventory();
            this.checkpoints.put(player.getUniqueId(), 0);
            player.teleport(this.course.point(0));
            player.getInventory().setItem(0, this.plugin.lobbyItem(Compat.mat("COMPASS"), "&aKembali ke checkpoint", "parkour_checkpoint", "&7Kembali ke checkpoint atau awal"));
            player.getInventory().setItem(8, this.plugin.leaveItem());
            Msg.title(player, "&b&lPARKOUR 1v1", "&f" + this.selectedMap + " &8| &e" + String.valueOf((Object)this.mode), 5, 50, 10);
        }
        this.bc("&eMap: &f" + this.selectedMap + " &8| &eMode: &f" + String.valueOf((Object)this.mode) + " &8| &7Pertama sampai garis akhir menang!");
    }

    @Override
    protected void onFast() {
        for (Player player : this.online()) {
            int n = this.checkpoints.getOrDefault(player.getUniqueId(), 0) + 5;
            if (n > 20 || !this.course.atStep(player, n)) continue;
            if (n == 20) {
                this.end(List.of(player));
                return;
            }
            this.checkpoints.put(player.getUniqueId(), n);
            Msg.bar(player, "&aTahap " + n / 5 + "/3 tercapai!");
            Compat.sound("ENTITY_EXPERIENCE_ORB_PICKUP", (Entity)player);
        }
    }

    @Override
    protected void onOut(Player player, Player player2, String string) {
        int n;
        int n2 = n = this.mode == ParkourGame.Mode.CLASSIC ? this.checkpoints.getOrDefault(player.getUniqueId(), 0) : 0;
        if (this.mode != ParkourGame.Mode.CLASSIC) {
            this.checkpoints.put(player.getUniqueId(), 0);
        }
        player.setFallDistance(0.0f);
        player.teleport(this.course.point(n));
        Msg.bar(player, n == 0 ? "&eKembali ke awal!" : "&aKembali ke checkpoint!");
    }

    @Override
    public void onDamage(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        entityDamageEvent.setCancelled(true);
        if (this.state == Game.State.RUNNING && entityDamageEvent.getCause() == EntityDamageEvent.DamageCause.VOID) {
            this.onOut(player, null, "jatuh");
        }
    }

    @Override
    public void lobbyAction(Player player, String string) {
        if (string.equals("parkour_checkpoint") && this.state == Game.State.RUNNING) {
            this.onOut(player, null, "kembali");
        } else {
            super.lobbyAction(player, string);
        }
    }

    @Override
    public void leave(Player player) {
        this.mapVotes.remove(player.getUniqueId());
        this.modeVotes.remove(player.getUniqueId());
        this.checkpoints.remove(player.getUniqueId());
        super.leave(player);
    }

    @Override
    protected void onReset() {
        this.mapVotes.clear();
        this.modeVotes.clear();
        this.checkpoints.clear();
        this.course = null;
    }

    @Override
    protected String barText() {
        return "&bParkour 1v1 &8| &f" + this.selectedMap + " &8| &e" + String.valueOf((Object)this.mode) + " &8| &7" + ParkourRaceGame.fmtTime(this.runSecs);
    }
}

