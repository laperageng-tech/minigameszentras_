/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Difficulty
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Registry
 *  org.bukkit.Sound
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.entity.EnderCrystal
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Husk
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Mob
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityDeathEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.inventory.EntityEquipment
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package id.zentra.minigames;

import id.zentra.minigames.Blueprint;
import id.zentra.minigames.Game;
import id.zentra.minigames.Kit;
import id.zentra.minigames.Msg;
import id.zentra.minigames.ZentraMinigames;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Husk;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class PracticeGame
extends Game {
    private static final int R = 38;
    private final Map<UUID, int[]> stats = new HashMap<UUID, int[]>();
    private final Map<UUID, Kit> kits = new HashMap<UUID, Kit>();
    private final Map<UUID, Long> shield = new HashMap<UUID, Long>();
    private final Map<UUID, Long> hitTime = new HashMap<UUID, Long>();
    private final Map<Block, Long> placed = new HashMap<Block, Long>();
    private final Map<Block, BlockState> damagedGround = new HashMap<Block, BlockState>();
    private long restoreGroundAt;
    private final Map<UUID, String> names = new HashMap<UUID, String>();
    private final Map<UUID, Integer> botLevel = new HashMap<UUID, Integer>();
    private final Map<UUID, Mob> bots = new HashMap<UUID, Mob>();
    public static final String[] LEVELS = new String[]{"Mati", "Mudah", "Sedang", "Sulit"};
    public static final String[] LEVEL_COLORS = new String[]{"&7", "&a", "&e", "&c"};
    private static final double[] BOT_HP = new double[]{0.0, 20.0, 30.0, 40.0};
    private static final double[] BOT_DMG = new double[]{0.0, 4.0, 7.0, 10.0};
    private static final double[] BOT_SPEED = new double[]{0.0, 0.21, 0.26, 0.3};

    public PracticeGame(ZentraMinigames zentraMinigames, int n, int n2, int n3, int n4, boolean bl) {
        super(zentraMinigames, bl ? "practicebot" : "practice", bl ? "Practice Bot" : "Practice PvP", Material.END_CRYSTAL, n, n2, n3, n4, 1, bl ? 1 : Math.max(2, zentraMinigames.getConfig().getInt("games.practice.max", 40)), List.of("Arena datar luas untuk latihan PvP bersama banyak pemain.", "Pilih kit lewat menu: Crystal PvP, Mace, Sword, atau NoDebuff.", "Mati = respawn instan dengan kit yang sama (proteksi singkat). Kill beruntun menambah streak.", "Klik item Ganti Kit di hotbar untuk pindah kit, atau Keluar untuk pergi kapan saja."));
        this.voidY = n3 - 12;
        this.pvp = true;
        this.envDamage = true;
        this.fallDamage = false;
        this.canBuild = true;
        this.allowBuildBlocks = true;
        this.lockInv = false;
        this.continuous = true;
    }

    @Override
    protected boolean hasLobby() {
        return false;
    }

    @Override
    public Location specSpawn() {
        return this.randomSpawn();
    }

    @Override
    public void forceStart() {
    }

    @Override
    protected void checkWin() {
    }

    @Override
    protected void onStart() {
    }

    @Override
    public boolean joinable() {
        return this.open && (this.state == Game.State.WAITING || this.state == Game.State.RUNNING) && this.players.size() < this.max;
    }

    @Override
    protected void buildArena(Blueprint blueprint) {
        int n;
        blueprint.cone(this.cx, this.by - 4, this.cz, 38, 10, Material.DEEPSLATE);
        blueprint.cylinder(this.cx, this.by - 3, this.by - 1, this.cz, 38, Material.DEEPSLATE_TILES);
        blueprint.disc(this.cx, this.by, this.cz, 38, Material.LIGHT_GRAY_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 33, 38, Material.GRAY_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 32, 33, Material.CYAN_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 20, 21, Material.CYAN_CONCRETE);
        blueprint.disc(this.cx, this.by, this.cz, 8, Material.WHITE_CONCRETE);
        blueprint.ring(this.cx, this.by, this.cz, 6, 7, Material.CYAN_CONCRETE);
        blueprint.disc(this.cx, this.by, this.cz, 2, Material.SEA_LANTERN);
        for (n = 1; n <= 7; ++n) {
            blueprint.ring(this.cx, this.by + n, this.cz, 37, 38, Material.LIGHT_BLUE_STAINED_GLASS);
        }
        blueprint.ring(this.cx, this.by + 8, this.cz, 37, 38, Material.SEA_LANTERN);
        for (n = 0; n < 8; ++n) {
            double d = (double)n * Math.PI / 4.0;
            int n2 = this.cx + (int)Math.round(Math.cos(d) * 24.0);
            int n3 = this.cz + (int)Math.round(Math.sin(d) * 24.0);
            blueprint.fill(n2, this.by + 1, n3, n2, this.by + 4, n3, Material.POLISHED_DEEPSLATE);
            blueprint.set(n2, this.by + 5, n3, Material.SEA_LANTERN);
        }
    }

    private Location randomSpawn() {
        double d = this.rnd.nextDouble() * Math.PI * 2.0;
        double d2 = Math.sqrt(this.rnd.nextDouble()) * 32.0;
        Location location = new Location(this.world, (double)this.cx + 0.5 + Math.cos(d) * d2, (double)(this.by + 1), (double)this.cz + 0.5 + Math.sin(d) * d2);
        location.setYaw(this.rnd.nextFloat() * 360.0f);
        return location;
    }

    @Override
    public boolean join(Player player) {
        return this.joinWith(player, Kit.SWORD);
    }

    public boolean joinWith(Player player, Kit kit) {
        if (!this.joinable()) {
            return false;
        }
        if (this.state == Game.State.WAITING) {
            this.state = Game.State.RUNNING;
            this.runSecs = 0;
        }
        UUID uUID = player.getUniqueId();
        this.snapshot(player);
        this.players.add(uUID);
        this.alive.add(uUID);
        this.kits.put(uUID, kit);
        this.names.put(uUID, player.getName());
        this.stats.put(uUID, new int[4]);
        this.botLevel.put(uUID, this.plugin.manager().botLevel(uUID));
        player.leaveVehicle();
        this.bar.addPlayer(player);
        this.attachBoard(player);
        this.ensureHolo();
        this.spawnWithKit(player);
        this.bc("&a" + player.getName() + " &7masuk dengan kit " + kit.colored() + " &8(" + this.players.size() + ")");
        Msg.title(player, "&c&lPRACTICE PVP", "&7Kit: " + kit.colored(), 5, 40, 10);
        return true;
    }

    public void changeKit(Player player, Kit kit) {
        UUID uUID = player.getUniqueId();
        if (!this.players.contains(uUID)) {
            return;
        }
        this.kits.put(uUID, kit);
        this.spawnWithKit(player);
        Msg.send(player, "&7Kit diganti ke " + kit.colored() + "&7.");
    }

    private void spawnWithKit(Player player) {
        UUID uUID = player.getUniqueId();
        Kit kit = this.kits.getOrDefault(uUID, Kit.SWORD);
        this.resetPlayer(player, GameMode.SURVIVAL);
        kit.give(player);
        player.getInventory().setItem(7, this.plugin.lobbyItem(Material.NETHER_STAR, "&d&lGanti Kit &7(klik kanan)", "kit", "&7Pilih kit lain (respawn)"));
        player.getInventory().setItem(8, this.plugin.leaveItem());
        player.getInventory().setHeldItemSlot(0);
        player.teleport(this.randomSpawn());
        this.reassertMode(player, GameMode.SURVIVAL);
        int n = Math.max(0, this.plugin.getConfig().getInt("games.practice.respawn-protection", 3));
        if (n > 0) {
            this.shield.put(uUID, System.currentTimeMillis() + (long)n * 1000L);
            Msg.bar(player, "&a\u2714 Proteksi spawn &f" + n + "s &8| &7serang untuk mencabutnya");
        }
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.4f);
        this.respawnBot(player);
    }

    public void setBotLevel(Player player, int n) {
        UUID uUID = player.getUniqueId();
        if (!this.players.contains(uUID)) {
            return;
        }
        this.botLevel.put(uUID, n);
        this.respawnBot(player);
        Msg.send(player, (String)(n == 0 ? "&7Bot dimatikan." : "&7Bot latihan: " + LEVEL_COLORS[n] + LEVELS[n] + "&7."));
    }

    private static void attr(LivingEntity livingEntity, String string, double d) {
        Attribute attribute = (Attribute)Registry.ATTRIBUTE.get(NamespacedKey.minecraft((String)string));
        if (attribute == null) {
            return;
        }
        AttributeInstance attributeInstance = livingEntity.getAttribute(attribute);
        if (attributeInstance != null) {
            attributeInstance.setBaseValue(d);
        }
    }

    private void removeBot(UUID uUID) {
        Mob mob = this.bots.remove(uUID);
        if (mob != null && mob.isValid()) {
            mob.remove();
        }
    }

    private Location botSpawn(Location location) {
        double d;
        double d2;
        double d3;
        double d4 = this.rnd.nextDouble() * Math.PI * 2.0;
        double d5 = location.getX() + Math.cos(d4) * 9.0;
        double d6 = d5 - ((double)this.cx + 0.5);
        double d7 = Math.sqrt(d6 * d6 + (d3 = (d2 = location.getZ() + Math.sin(d4) * 9.0) - ((double)this.cz + 0.5)) * d3);
        if (d7 > (d = 34.0)) {
            d5 = (double)this.cx + 0.5 + d6 / d7 * d;
            d2 = (double)this.cz + 0.5 + d3 / d7 * d;
        }
        return new Location(this.world, d5, (double)(this.by + 1), d2);
    }

    private void respawnBot(Player player) {
        UUID uUID = player.getUniqueId();
        this.removeBot(uUID);
        int n = this.botLevel.getOrDefault(uUID, 0);
        if (n <= 0 || !this.players.contains(uUID)) {
            return;
        }
        if (this.world.getDifficulty() == Difficulty.PEACEFUL) {
            Msg.send(player, "&cBot membutuhkan difficulty world PvP EASY, NORMAL, atau HARD (bukan PEACEFUL).");
            return;
        }
        Kit kit = this.kits.getOrDefault(uUID, Kit.SWORD);
        Husk husk2 = (Husk)this.world.spawn(this.botSpawn(player.getLocation()), Husk.class, husk -> {
            husk.setPersistent(false);
            husk.setRemoveWhenFarAway(false);
            husk.setCanPickupItems(false);
            husk.setBaby(false);
            husk.customName(Msg.c("&c&lBot &8[" + kit.colored() + "&8] " + LEVEL_COLORS[n] + LEVELS[n]));
            husk.setCustomNameVisible(true);
            String string = kit == Kit.CRYSTAL || kit == Kit.MACE ? "NETHERITE" : "DIAMOND";
            EntityEquipment entityEquipment = husk.getEquipment();
            entityEquipment.setHelmet(new ItemStack(Material.valueOf((String)(string + "_HELMET"))));
            entityEquipment.setChestplate(new ItemStack(Material.valueOf((String)(string + "_CHESTPLATE"))));
            entityEquipment.setLeggings(new ItemStack(Material.valueOf((String)(string + "_LEGGINGS"))));
            entityEquipment.setBoots(new ItemStack(Material.valueOf((String)(string + "_BOOTS"))));
            entityEquipment.setItemInMainHand(new ItemStack(kit == Kit.MACE ? Material.MACE : (kit == Kit.CRYSTAL ? Material.NETHERITE_SWORD : Material.DIAMOND_SWORD)));
            PracticeGame.attr((LivingEntity)husk, "max_health", BOT_HP[n]);
            PracticeGame.attr((LivingEntity)husk, "attack_damage", BOT_DMG[n]);
            PracticeGame.attr((LivingEntity)husk, "movement_speed", BOT_SPEED[n]);
            PracticeGame.attr((LivingEntity)husk, "follow_range", 48.0);
            PracticeGame.attr((LivingEntity)husk, "spawn_reinforcements", 0.0);
            husk.setHealth(BOT_HP[n]);
        });
        this.bots.put(uUID, (Mob)husk2);
        husk2.setAware(true);
        husk2.setTarget((LivingEntity)player);
    }

    public boolean allowTarget(Entity entity, LivingEntity livingEntity) {
        if (livingEntity == null) {
            return true;
        }
        for (Map.Entry<UUID, Mob> entry : this.bots.entrySet()) {
            if (!entry.getValue().getUniqueId().equals(entity.getUniqueId())) continue;
            return livingEntity.getUniqueId().equals(entry.getKey());
        }
        return true;
    }

    public boolean isOwnBot(Entity entity, Player player) {
        Mob mob = this.bots.get(player.getUniqueId());
        return mob != null && mob.getUniqueId().equals(entity.getUniqueId());
    }

    public void onBotDeath(EntityDeathEvent entityDeathEvent) {
        UUID uUID2 = null;
        for (Map.Entry<UUID, Mob> entry2 : this.bots.entrySet()) {
            if (!entry2.getValue().getUniqueId().equals(entityDeathEvent.getEntity().getUniqueId())) continue;
            uUID2 = entry2.getKey();
        }
        if (uUID2 == null) {
            return;
        }
        entityDeathEvent.getDrops().clear();
        entityDeathEvent.setDroppedExp(0);
        this.bots.remove(uUID2);
        Player player = entityDeathEvent.getEntity().getKiller();
        if (player != null && this.players.contains(player.getUniqueId())) {
            int[] st = this.stats.computeIfAbsent(player.getUniqueId(), uUID -> new int[4]);
            st[0] = st[0] + 1;
            st[2] = st[2] + 1;
            st[3] = Math.max(st[3], st[2]);
            player.setHealth(player.getMaxHealth());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            Msg.bar(player, "&a+1 Kill (bot) &8| &7Streak: &6" + st[2] + " &8| &7Total: &f" + st[0]);
        }
        UUID deadOwner = uUID2;
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.lambda$onBotDeath$1(deadOwner), 40L);
    }

    @Override
    public void shutdown() {
        this.restoreGround();
        for (UUID uUID : new ArrayList<UUID>(this.bots.keySet())) {
            this.removeBot(uUID);
        }
        super.shutdown();
    }

    @Override
    public void onExplode(EntityExplodeEvent entityExplodeEvent) {
        if (!(entityExplodeEvent.getEntity() instanceof EnderCrystal)) {
            super.onExplode(entityExplodeEvent);
            return;
        }
        Location location = entityExplodeEvent.getLocation();
        entityExplodeEvent.blockList().removeIf(block -> {
            boolean bl;
            int n = block.getX() - location.getBlockX();
            int n2 = block.getZ() - location.getBlockZ();
            boolean bl2 = bl = block.getY() <= this.by && Math.abs(n) <= 5 && Math.abs(n2) <= 5 && Math.pow(block.getX() - this.cx, 2.0) + Math.pow(block.getZ() - this.cz, 2.0) < 1369.0;
            if (bl && !this.placed.containsKey(block)) {
                this.damagedGround.putIfAbsent((Block)block, block.getState());
            }
            if (bl) {
                this.placed.remove(block);
            }
            return !bl;
        });
        entityExplodeEvent.setYield(0.0f);
        this.restoreGroundAt = System.currentTimeMillis() + 10000L;
    }

    private void restoreGround() {
        for (BlockState blockState : this.damagedGround.values()) {
            blockState.update(true, false);
        }
        this.damagedGround.clear();
        this.restoreGroundAt = 0L;
    }

    @Override
    public void lobbyAction(Player player, String string) {
        if (string.equals("kit")) {
            this.plugin.manager().openKitMenu(player);
            return;
        }
        super.lobbyAction(player, string);
    }

    @Override
    protected void onLeave(Player player, boolean bl) {
        UUID uUID = player.getUniqueId();
        this.kits.remove(uUID);
        this.shield.remove(uUID);
        this.hitTime.remove(uUID);
        this.botLevel.remove(uUID);
        this.removeBot(uUID);
    }

    @Override
    public void onDamage(EntityDamageEvent entityDamageEvent, Player player, Player player2) {
        UUID uUID = player.getUniqueId();
        long l = System.currentTimeMillis();
        if (entityDamageEvent instanceof EntityDamageByEntityEvent && this.isOwnBot(((EntityDamageByEntityEvent)entityDamageEvent).getDamager(), player)) {
            if (this.state != Game.State.RUNNING || !this.alive.contains(uUID)) {
                entityDamageEvent.setCancelled(true);
            }
            return;
        }
        Long shieldUntil = this.shield.get(uUID);
        if (shieldUntil != null) {
            if (l < shieldUntil) {
                entityDamageEvent.setCancelled(true);
                return;
            }
            this.shield.remove(uUID);
        }
        if (player2 != null) {
            this.shield.remove(player2.getUniqueId());
        }
        if (this.state != Game.State.RUNNING || !this.alive.contains(uUID)) {
            entityDamageEvent.setCancelled(true);
            return;
        }
        EntityDamageEvent.DamageCause damageCause = entityDamageEvent.getCause();
        if (player2 == null && (damageCause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION || damageCause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION)) {
            player2 = this.nearest(player, 12.0);
        }
        if (player2 != null && !player2.equals((Object)player) && this.alive.contains(player2.getUniqueId())) {
            this.lastHit.put(uUID, player2.getUniqueId());
            this.hitTime.put(uUID, l);
        }
        if (damageCause == EntityDamageEvent.DamageCause.VOID) {
            entityDamageEvent.setCancelled(true);
            this.onOut(player, this.lastHitter(player), "jatuh ke void");
            return;
        }
        if (damageCause == EntityDamageEvent.DamageCause.FALL) {
            entityDamageEvent.setCancelled(true);
            return;
        }
        if (player.getHealth() - entityDamageEvent.getFinalDamage() <= 0.0) {
            if (this.hasTotem(player)) {
                return;
            }
            entityDamageEvent.setCancelled(true);
            this.onOut(player, this.lastHitter(player), damageCause == EntityDamageEvent.DamageCause.ENTITY_ATTACK ? "dikalahkan bot" : "tewas");
        }
    }

    private boolean hasTotem(Player player) {
        return player.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING || player.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private Player nearest(Player player, double d) {
        Player player2 = null;
        double d2 = d * d;
        for (Player player3 : this.online()) {
            double d3;
            if (player3.equals((Object)player) || !this.alive.contains(player3.getUniqueId()) || player3.getWorld() != player.getWorld() || !((d3 = player3.getLocation().distanceSquared(player.getLocation())) < d2)) continue;
            d2 = d3;
            player2 = player3;
        }
        return player2;
    }

    @Override
    protected Player lastHitter(Player player) {
        Long l = this.hitTime.get(player.getUniqueId());
        if (l == null || System.currentTimeMillis() - l > 12000L) {
            return null;
        }
        return super.lastHitter(player);
    }

    @Override
    protected void onOut(Player player, Player player2, String string) {
        UUID uUID2 = player.getUniqueId();
        if (!this.alive.contains(uUID2)) {
            return;
        }
        int[] nArray = this.stats.computeIfAbsent(uUID2, uUID -> new int[4]);
        nArray[1] = nArray[1] + 1;
        int n = nArray[2];
        nArray[2] = 0;
        if (player2 != null && !player2.equals((Object)player)) {
            int[] nArray2 = this.stats.computeIfAbsent(player2.getUniqueId(), uUID -> new int[4]);
            nArray2[0] = nArray2[0] + 1;
            nArray2[2] = nArray2[2] + 1;
            nArray2[3] = Math.max(nArray2[3], nArray2[2]);
            Kit kit = this.kits.getOrDefault(player2.getUniqueId(), Kit.SWORD);
            this.bc("&c" + player.getName() + " &7dikalahkan &e" + player2.getName() + " &8[" + kit.colored() + "&8]" + (String)(n >= 3 ? " &6(streak " + n + " putus!)" : ""));
            player2.setHealth(player2.getMaxHealth());
            player2.playSound(player2.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            Msg.bar(player2, "&a+1 Kill &8| &7Streak: &6" + nArray2[2] + " &8| &7Total: &f" + nArray2[0]);
            if (nArray2[2] >= 3 && nArray2[2] % 3 == 0) {
                this.bc("&6\u2605 " + player2.getName() + " &emendapat streak &6" + nArray2[2] + " &ekill!");
            }
        } else {
            this.bc("&c" + player.getName() + " &7" + string);
        }
        this.lastHit.remove(uUID2);
        this.hitTime.remove(uUID2);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_DEATH, 0.7f, 1.0f);
        Msg.bar(player, "&cKamu mati &8| &7respawn instan...");
        this.spawnWithKit(player);
    }

    @Override
    public boolean allowPlace(Block block, Player player) {
        if (this.state != Game.State.RUNNING) return false;
        if (block.getY() < by - 20 || block.getY() > by + 60) return false;
        if (Math.abs(block.getX() - cx) > 60 || Math.abs(block.getZ() - cz) > 60) return false;
        this.placed.put(block, System.currentTimeMillis() + 20000L);
        return true;
    }

    @Override
    public boolean allowBreak(Block block, Player player) {
        return this.placed.containsKey(block);
    }

    @Override
    protected void onSecond() {
        long l = System.currentTimeMillis();
        if (this.restoreGroundAt > 0L && l >= this.restoreGroundAt) {
            this.restoreGround();
        }
        Iterator<Map.Entry<Block, Long>> iterator = this.placed.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Block, Long> entry = iterator.next();
            if (l < entry.getValue()) continue;
            if (((Block)entry.getKey()).getType() == Material.OBSIDIAN) {
                ((Block)entry.getKey()).setType(Material.AIR, false);
            }
            iterator.remove();
        }
        for (Map.Entry entry : new ArrayList<Map.Entry<UUID, Mob>>(this.bots.entrySet())) {
            Player player = Bukkit.getPlayer((UUID)((UUID)entry.getKey()));
            Mob mob = (Mob)entry.getValue();
            if (player == null || !mob.isValid() || mob.getTarget() != null && mob.getTarget().equals((Object)player)) continue;
            mob.setTarget((LivingEntity)player);
        }
        if (this.players.isEmpty()) {
            return;
        }
        for (Entity entity : this.world.getNearbyEntities(new Location(this.world, (double)this.cx, (double)(this.by + 5), (double)this.cz), 40.0, 30.0, 40.0)) {
            if (entity instanceof EnderCrystal && entity.getTicksLived() > 1200) {
                entity.remove();
                continue;
            }
            if (!(entity instanceof Item)) continue;
            entity.remove();
        }
    }

    @Override
    protected void onReset() {
        this.restoreGround();
        for (UUID uUID : new ArrayList<UUID>(this.bots.keySet())) {
            this.removeBot(uUID);
        }
        this.placed.clear();
        this.stats.clear();
        this.kits.clear();
    }

    @Override
    protected String barText() {
        return "&c&lPRACTICE PVP &8| &fPemain: &a" + this.players.size() + " &8| &7/zm leave untuk keluar";
    }

    @Override
    protected String sidebarTitle() {
        return "&c&lPRACTICE PVP";
    }

    @Override
    protected List<String> sidebar(Player player) {
        UUID uUID = player.getUniqueId();
        int[] nArray = this.stats.getOrDefault(uUID, new int[4]);
        Kit kit = this.kits.getOrDefault(uUID, Kit.SWORD);
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("&8" + this.id());
        arrayList.add(" ");
        arrayList.add("&fKit &8\u00bb " + kit.colored());
        arrayList.add("&fKill &8\u00bb &a" + nArray[0] + " &8| &fMati &8\u00bb &c" + nArray[1]);
        arrayList.add("&fK/D &8\u00bb &e" + String.format("%.2f", nArray[1] == 0 ? (double)nArray[0] : (double)nArray[0] / (double)nArray[1]));
        arrayList.add("&fStreak &8\u00bb &6" + nArray[2] + " &8(terbaik " + nArray[3] + ")");
        arrayList.add(" ");
        int n = this.botLevel.getOrDefault(uUID, 0);
        if (n > 0) {
            arrayList.add("&fBot &8\u00bb " + LEVEL_COLORS[n] + LEVELS[n]);
        }
        arrayList.add("&fPemain &8\u00bb &a" + this.players.size());
        arrayList.add(" ");
        arrayList.add("&b/zm leave &7= keluar");
        return arrayList;
    }

    @Override
    protected Location holoLoc() {
        return new Location(this.world, (double)this.cx + 0.5, (double)this.by + 5.5, (double)this.cz + 0.5);
    }

    @Override
    protected Component holoText() {
        ArrayList<Map.Entry<UUID, int[]>> arrayList = new ArrayList<Map.Entry<UUID, int[]>>(this.stats.entrySet());
        arrayList.removeIf(entry -> !this.players.contains(entry.getKey()));
        arrayList.sort((entry, entry2) -> Integer.compare(((int[])entry2.getValue())[0], ((int[])entry.getValue())[0]));
        StringBuilder stringBuilder = new StringBuilder("&c&lPRACTICE PVP\n&8&m               \n&fTop Kill\n");
        if (arrayList.isEmpty()) {
            stringBuilder.append("&7Belum ada pemain\n");
        }
        for (int i = 0; i < Math.min(3, arrayList.size()); ++i) {
            Map.Entry entry3 = (Map.Entry)arrayList.get(i);
            stringBuilder.append(i == 0 ? "&6" : (i == 1 ? "&f" : "&c")).append(i + 1).append(". &f").append(this.names.getOrDefault(entry3.getKey(), "?")).append(" &8- &a").append(((int[])entry3.getValue())[0]).append("\n");
        }
        stringBuilder.append("&7").append(this.players.size()).append(" pemain berlatih");
        return Msg.c(stringBuilder.toString());
    }

    private /* synthetic */ void lambda$onBotDeath$1(UUID uUID) {
        Player player = Bukkit.getPlayer((UUID)uUID);
        if (player != null && this.players.contains(uUID)) {
            this.respawnBot(player);
        }
    }
}

